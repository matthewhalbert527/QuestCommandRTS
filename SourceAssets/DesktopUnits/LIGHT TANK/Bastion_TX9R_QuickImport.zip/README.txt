Drag the Meshes and Textures folders into Unity together. Use Bastion_Tank_Static.obj for a non-articulated one-piece model.
