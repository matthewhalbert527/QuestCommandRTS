from __future__ import annotations

import json
import math
import shutil
import textwrap
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import trimesh
from trimesh.transformations import rotation_matrix, translation_matrix


OUTPUT_ROOT = Path('/mnt/data/Bastion_TX9R_Unity_Package')
ASSET_ROOT = OUTPUT_ROOT / 'Assets' / 'BastionTankR'
MESH_DIR = ASSET_ROOT / 'Meshes'
TEXTURE_DIR = ASSET_ROOT / 'Textures'
SCRIPT_DIR = ASSET_ROOT / 'Scripts'
EDITOR_DIR = ASSET_ROOT / 'Editor'
EXTRAS_DIR = ASSET_ROOT / 'Extras'
PREVIEW_DIR = OUTPUT_ROOT / 'Preview'
SOURCE_DIR = OUTPUT_ROOT / 'Source'

PALETTE = {
    'Armor': (98, 97, 73, 255),
    'Secondary': (72, 71, 63, 255),
    'Track': (28, 30, 29, 255),
    'Accent': (126, 117, 82, 255),
    'Optic': (70, 91, 92, 255),
}
PALETTE_ORDER = list(PALETTE)
SWATCH_WIDTH = 32
TEXTURE_HEIGHT = 32


@dataclass(frozen=True)
class Piece:
    name: str
    mesh: trimesh.Trimesh
    palette: str


def clean_mesh(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    mesh = mesh.copy()
    mesh.remove_unreferenced_vertices()
    try:
        mesh.remove_duplicate_faces()
    except Exception:
        pass
    try:
        mesh.fix_normals(multibody=True)
    except TypeError:
        mesh.fix_normals()
    return mesh


def merge(meshes: Iterable[trimesh.Trimesh]) -> trimesh.Trimesh:
    items = [clean_mesh(m) for m in meshes]
    if not items:
        raise ValueError('Cannot merge an empty mesh list')
    return clean_mesh(trimesh.util.concatenate(items))


def box(extents: Sequence[float], center=(0.0, 0.0, 0.0), euler_deg=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    mesh = trimesh.creation.box(extents=np.asarray(extents, dtype=float))
    rx, ry, rz = [math.radians(v) for v in euler_deg]
    matrix = trimesh.transformations.euler_matrix(rx, ry, rz, axes='sxyz')
    matrix[:3, 3] = np.asarray(center, dtype=float)
    mesh.apply_transform(matrix)
    return clean_mesh(mesh)


def cylinder(radius: float, height: float, axis: str = 'z', center=(0.0, 0.0, 0.0), sections=12) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    if axis == 'x':
        mesh.apply_transform(rotation_matrix(math.pi / 2.0, [0, 1, 0]))
    elif axis == 'y':
        mesh.apply_transform(rotation_matrix(-math.pi / 2.0, [1, 0, 0]))
    elif axis != 'z':
        raise ValueError(f'Unsupported axis {axis}')
    mesh.apply_translation(np.asarray(center, dtype=float))
    return clean_mesh(mesh)


def cone(radius: float, height: float, axis: str = 'y', center=(0.0, 0.0, 0.0), sections=10) -> trimesh.Trimesh:
    mesh = trimesh.creation.cone(radius=radius, height=height, sections=sections)
    if axis == 'x':
        mesh.apply_transform(rotation_matrix(math.pi / 2.0, [0, 1, 0]))
    elif axis == 'y':
        mesh.apply_transform(rotation_matrix(-math.pi / 2.0, [1, 0, 0]))
    elif axis != 'z':
        raise ValueError(f'Unsupported axis {axis}')
    mesh.apply_translation(np.asarray(center, dtype=float))
    return clean_mesh(mesh)


def layered_prism(footprints: Sequence[np.ndarray], heights: Sequence[float]) -> trimesh.Trimesh:
    if len(footprints) != len(heights) or len(footprints) < 2:
        raise ValueError('Need matching footprint and height layers')
    n = len(footprints[0])
    if any(len(p) != n for p in footprints):
        raise ValueError('All footprints must have the same vertex count')

    vertices: list[list[float]] = []
    for poly, y in zip(footprints, heights):
        for x, z in poly:
            vertices.append([float(x), float(y), float(z)])

    faces: list[list[int]] = []
    layers = len(footprints)
    for layer in range(layers - 1):
        a0 = layer * n
        b0 = (layer + 1) * n
        for i in range(n):
            j = (i + 1) % n
            faces.append([a0 + i, a0 + j, b0 + j])
            faces.append([a0 + i, b0 + j, b0 + i])

    bottom_center = len(vertices)
    vertices.append([float(np.mean(footprints[0][:, 0])), float(heights[0]), float(np.mean(footprints[0][:, 1]))])
    top_center = len(vertices)
    vertices.append([float(np.mean(footprints[-1][:, 0])), float(heights[-1]), float(np.mean(footprints[-1][:, 1]))])

    for i in range(n):
        j = (i + 1) % n
        faces.append([bottom_center, j, i])
        top0 = (layers - 1) * n
        faces.append([top_center, top0 + i, top0 + j])

    mesh = trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=True)
    return clean_mesh(mesh)


def transformed(mesh: trimesh.Trimesh, translation=(0.0, 0.0, 0.0), euler_deg=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    out = mesh.copy()
    rx, ry, rz = [math.radians(v) for v in euler_deg]
    matrix = trimesh.transformations.euler_matrix(rx, ry, rz, axes='sxyz')
    matrix[:3, 3] = np.asarray(translation, dtype=float)
    out.apply_transform(matrix)
    return clean_mesh(out)



def extrude_ring_profile_x(
    outer_yz: Sequence[Sequence[float]],
    inner_yz: Sequence[Sequence[float]],
    thickness: float,
) -> trimesh.Trimesh:
    """Extrude a hollow track-band profile along X."""
    outer = np.asarray(outer_yz, dtype=float)
    inner = np.asarray(inner_yz, dtype=float)
    if outer.shape != inner.shape or outer.ndim != 2 or outer.shape[1] != 2:
        raise ValueError('outer and inner profiles must be matching N x 2 arrays')
    n = len(outer)
    half = thickness * 0.5
    vertices = []
    for x, loop in ((-half, outer), (half, outer), (-half, inner), (half, inner)):
        vertices.extend([[x, y, z] for y, z in loop])

    faces: list[list[int]] = []
    o_back, o_front, i_back, i_front = 0, n, 2 * n, 3 * n
    for i in range(n):
        j = (i + 1) % n
        # Outer perimeter wall.
        faces.extend([
            [o_back + i, o_back + j, o_front + j],
            [o_back + i, o_front + j, o_front + i],
        ])
        # Inner perimeter wall (reversed winding).
        faces.extend([
            [i_back + i, i_front + j, i_back + j],
            [i_back + i, i_front + i, i_front + j],
        ])
        # Visible ring faces on the two X sides.
        faces.extend([
            [o_front + i, o_front + j, i_front + j],
            [o_front + i, i_front + j, i_front + i],
            [o_back + i, i_back + j, o_back + j],
            [o_back + i, i_back + i, i_back + j],
        ])
    return clean_mesh(trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=True))


def ellipsoid(extents: Sequence[float], center=(0.0, 0.0, 0.0), subdivisions=1) -> trimesh.Trimesh:
    mesh = trimesh.creation.icosphere(subdivisions=subdivisions, radius=1.0)
    mesh.apply_scale(np.asarray(extents, dtype=float) * 0.5)
    mesh.apply_translation(np.asarray(center, dtype=float))
    return clean_mesh(mesh)


def radial_footprint(
    radius_x: float,
    radius_z: float,
    z_shift: float = 0.0,
    sectors: int = 18,
    front_taper: float = 0.10,
    rear_taper: float = 0.03,
) -> np.ndarray:
    points = []
    for theta in np.linspace(0.0, math.tau, sectors, endpoint=False):
        c = math.cos(theta)
        s = math.sin(theta)
        taper = 1.0 - front_taper * max(c, 0.0) - rear_taper * max(-c, 0.0)
        points.append([radius_x * s * taper, z_shift + radius_z * c])
    return np.asarray(points, dtype=float)


def tapered_cylinder_z(
    rear_radius: float,
    front_radius: float,
    length: float,
    center=(0.0, 0.0, 0.0),
    sections: int = 12,
) -> trimesh.Trimesh:
    cx, cy, cz = center
    z0 = cz - length * 0.5
    z1 = cz + length * 0.5
    vertices = []
    for z, radius in ((z0, rear_radius), (z1, front_radius)):
        for theta in np.linspace(0.0, math.tau, sections, endpoint=False):
            vertices.append([cx + radius * math.cos(theta), cy + radius * math.sin(theta), z])
    faces = []
    for i in range(sections):
        j = (i + 1) % sections
        faces.extend([[i, j, sections + j], [i, sections + j, sections + i]])
    rear_center = len(vertices)
    vertices.append([cx, cy, z0])
    front_center = len(vertices)
    vertices.append([cx, cy, z1])
    for i in range(sections):
        j = (i + 1) % sections
        faces.append([rear_center, j, i])
        faces.append([front_center, sections + i, sections + j])
    return clean_mesh(trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=True))


def build_hull() -> list[Piece]:
    # Low-slung hull with a sharply sloped glacis, broad fenders, and a raised rear engine deck.
    lower_bottom = np.array([
        [-1.10, -2.25], [1.10, -2.25], [1.27, -1.72], [1.27, 1.50],
        [1.03, 1.88], [-1.03, 1.88], [-1.27, 1.50], [-1.27, -1.72],
    ])
    lower_top = np.array([
        [-1.18, -2.18], [1.18, -2.18], [1.34, -1.66], [1.34, 1.62],
        [1.08, 2.30], [-1.08, 2.30], [-1.34, 1.62], [-1.34, -1.66],
    ])
    lower_shell = layered_prism([lower_bottom, lower_top], [-0.62, -0.02])

    upper_base = np.array([
        [-1.27, -2.02], [1.27, -2.02], [1.31, -1.42], [1.31, 1.58],
        [1.03, 2.31], [-1.03, 2.31], [-1.31, 1.58], [-1.31, -1.42],
    ])
    upper_mid = np.array([
        [-1.15, -1.86], [1.15, -1.86], [1.19, -1.30], [1.15, 1.25],
        [0.82, 1.98], [-0.82, 1.98], [-1.15, 1.25], [-1.19, -1.30],
    ])
    upper_top = np.array([
        [-0.94, -1.55], [0.94, -1.55], [1.00, -1.08], [0.92, 0.70],
        [0.60, 1.30], [-0.60, 1.30], [-0.92, 0.70], [-1.00, -1.08],
    ])
    upper_shell = layered_prism([upper_base, upper_mid, upper_top], [-0.05, 0.28, 0.58])

    armor: list[trimesh.Trimesh] = [lower_shell, upper_shell]
    # Flat fender shelves; their curved end segments visually wrap around the track ends.
    for side in (-1, 1):
        armor.append(box((0.30, 0.12, 4.52), center=(side * 1.43, 0.44, -0.04)))
        front_segments = [
            (1.86, 0.42, -10), (2.08, 0.34, -24), (2.27, 0.20, -40), (2.40, 0.02, -56),
        ]
        rear_segments = [
            (-1.84, 0.42, 10), (-2.05, 0.34, 24), (-2.22, 0.20, 40), (-2.34, 0.04, 54),
        ]
        for z, y, angle in front_segments + rear_segments:
            armor.append(box((0.32, 0.10, 0.42), center=(side * 1.43, y, z), euler_deg=(angle, 0, 0)))

    # Rear engine-deck shoulders and front splash guard.
    armor.extend([
        box((2.05, 0.18, 1.12), center=(0, 0.62, -1.33)),
        box((2.54, 0.12, 0.20), center=(0, 0.13, 2.31), euler_deg=(-15, 0, 0)),
        box((1.82, 0.12, 0.36), center=(0, 0.58, -0.62)),
    ])

    secondary: list[trimesh.Trimesh] = []
    # Engine louvers.
    for x in (-0.72, -0.36, 0.0, 0.36, 0.72):
        secondary.append(box((0.24, 0.06, 0.76), center=(x, 0.73, -1.34)))
    # Rear deck stowage rolls and retaining bands.
    for side in (-1, 1):
        secondary.append(cylinder(0.18, 0.82, axis='z', center=(side * 1.10, 0.66, -1.62), sections=12))
        for z in (-1.86, -1.62, -1.38):
            secondary.append(cylinder(0.205, 0.045, axis='z', center=(side * 1.10, 0.66, z), sections=12))
    # Exhaust and tow bar.
    secondary.extend([
        cylinder(0.11, 0.76, axis='z', center=(0.82, 0.72, -1.74), sections=10),
        box((1.36, 0.10, 0.14), center=(0, -0.48, -2.31)),
    ])

    # Ribbed fender ends, echoing the curved sheet-metal guards in the reference.
    for side in (-1, 1):
        for z, y, angle in ((1.98, 0.46, -17), (2.18, 0.35, -32), (2.34, 0.18, -49),
                            (-1.96, 0.46, 17), (-2.14, 0.36, 31), (-2.29, 0.20, 47)):
            armor.append(box((0.34, 0.045, 0.075), center=(side * 1.43, y + 0.055, z), euler_deg=(angle, 0, 0)))

    # Muted recognition strips on the fender sides.
    accent: list[trimesh.Trimesh] = [
        box((0.045, 0.16, 0.86), center=(-1.595, 0.35, 0.36)),
        box((0.045, 0.16, 0.86), center=(1.595, 0.35, 0.36)),
    ]

    optic = [
        cylinder(0.12, 0.10, axis='z', center=(-0.73, 0.26, 2.24), sections=12),
        cylinder(0.12, 0.10, axis='z', center=(0.73, 0.26, 2.24), sections=12),
    ]

    return [
        Piece('Hull_Armor', merge(armor), 'Armor'),
        Piece('Hull_Secondary', merge(secondary), 'Secondary'),
        Piece('Hull_Accent', merge(accent), 'Accent'),
        Piece('Hull_Lights', merge(optic), 'Optic'),
    ]


def build_track(side: int) -> list[Piece]:
    if side not in (-1, 1):
        raise ValueError('side must be -1 or 1')

    outer = [
        (-0.55, -2.10), (-0.55, 1.92), (-0.44, 2.25), (-0.20, 2.45),
        (0.12, 2.47), (0.43, 2.28), (0.62, 1.78), (0.64, -1.70),
        (0.50, -2.12), (0.22, -2.38), (-0.18, -2.35), (-0.44, -2.18),
    ]
    inner = [
        (-0.36, -1.84), (-0.36, 1.68), (-0.27, 1.97), (-0.05, 2.15),
        (0.14, 2.12), (0.33, 1.94), (0.46, 1.54), (0.47, -1.48),
        (0.35, -1.86), (0.12, -2.08), (-0.10, -2.05), (-0.29, -1.91),
    ]
    track_meshes: list[trimesh.Trimesh] = [extrude_ring_profile_x(outer, inner, thickness=0.48)]

    # Tread shoes along straight runs.
    for z in np.linspace(-1.88, 1.82, 15):
        track_meshes.append(box((0.56, 0.09, 0.19), center=(0, -0.60, float(z))))
    for z in np.linspace(-1.48, 1.52, 12):
        track_meshes.append(box((0.56, 0.08, 0.19), center=(0, 0.69, float(z))))
    # Tread shoes around the front and rear arcs.
    front_arc = [
        (2.10, -0.47, -12), (2.27, -0.34, -27), (2.40, -0.12, -45),
        (2.41, 0.13, -64), (2.31, 0.37, -78), (2.13, 0.56, -88),
    ]
    rear_arc = [
        (-2.11, -0.47, 12), (-2.27, -0.33, 27), (-2.37, -0.10, 45),
        (-2.34, 0.15, 64), (-2.22, 0.38, 78), (-2.05, 0.56, 88),
    ]
    for z, y, angle in front_arc + rear_arc:
        track_meshes.append(box((0.56, 0.09, 0.20), center=(0, y, z), euler_deg=(angle, 0, 0)))

    tire_meshes: list[trimesh.Trimesh] = []
    wheel_meshes: list[trimesh.Trimesh] = []
    hub_meshes: list[trimesh.Trimesh] = []
    outward = side * 0.12
    hub_outward = side * 0.27

    # Five main road wheels define the classic light/medium-tank silhouette.
    for z in (-1.48, -0.74, 0.0, 0.74, 1.48):
        tire_meshes.append(cylinder(0.405, 0.38, axis='x', center=(outward, -0.08, z), sections=14))
        wheel_meshes.append(cylinder(0.315, 0.42, axis='x', center=(outward + side * 0.025, -0.08, z), sections=14))
        hub_meshes.append(cylinder(0.105, 0.47, axis='x', center=(hub_outward, -0.08, z), sections=12))

    # End wheels and small return rollers.
    for z, y, radius in ((-2.01, 0.02, 0.34), (2.04, 0.03, 0.35)):
        tire_meshes.append(cylinder(radius, 0.36, axis='x', center=(outward, y, z), sections=14))
        wheel_meshes.append(cylinder(radius * 0.72, 0.41, axis='x', center=(outward + side * 0.025, y, z), sections=12))
        hub_meshes.append(cylinder(0.09, 0.46, axis='x', center=(hub_outward, y, z), sections=10))
    for z in (-1.02, -0.28, 0.48, 1.20):
        tire_meshes.append(cylinder(0.145, 0.32, axis='x', center=(outward, 0.45, z), sections=10))

    name = 'LeftTrack' if side < 0 else 'RightTrack'
    return [
        Piece(f'{name}_Band', merge(track_meshes), 'Track'),
        Piece(f'{name}_Tires', merge(tire_meshes), 'Track'),
        Piece(f'{name}_Wheels', merge(wheel_meshes), 'Secondary'),
        Piece(f'{name}_Hubs', merge(hub_meshes), 'Accent'),
    ]


def build_turret() -> list[Piece]:
    # Multi-ring cast turret: broad shoulder, rounded crown, and a subtle rearward bias.
    footprints = [
        radial_footprint(0.92, 0.82, z_shift=-0.08, sectors=18, front_taper=0.12),
        radial_footprint(1.10, 0.98, z_shift=-0.10, sectors=18, front_taper=0.10),
        radial_footprint(1.16, 1.03, z_shift=-0.12, sectors=18, front_taper=0.09),
        radial_footprint(1.00, 0.88, z_shift=-0.14, sectors=18, front_taper=0.08),
        radial_footprint(0.72, 0.62, z_shift=-0.17, sectors=18, front_taper=0.06),
    ]
    shell = layered_prism(footprints, [-0.28, -0.14, 0.08, 0.30, 0.50])

    armor: list[trimesh.Trimesh] = [
        shell,
        # Rounded mantlet and low rear stowage bustle.
        ellipsoid((1.30, 0.76, 0.62), center=(0, 0.00, 0.91), subdivisions=2),
        box((1.26, 0.20, 0.28), center=(0, 0.12, -1.01)),
        # Cast cupolas/hatches.
        cylinder(0.31, 0.14, axis='y', center=(-0.31, 0.57, -0.17), sections=16),
        cylinder(0.27, 0.10, axis='y', center=(0.37, 0.55, 0.02), sections=14),
        cylinder(0.29, 0.06, axis='y', center=(-0.31, 0.68, -0.17), sections=16),
        cylinder(0.25, 0.055, axis='y', center=(0.37, 0.63, 0.02), sections=14),
    ]

    secondary: list[trimesh.Trimesh] = [
        # Gun collar and rear rolled tarp.
        cylinder(0.31, 0.30, axis='z', center=(0, -0.01, 1.12), sections=14),
        cylinder(0.125, 1.16, axis='x', center=(0, 0.27, -1.05), sections=12),
        cylinder(0.145, 0.045, axis='x', center=(-0.36, 0.27, -1.05), sections=12),
        cylinder(0.145, 0.045, axis='x', center=(0.36, 0.27, -1.05), sections=12),
        # Antenna mast and commander's periscope block.
        cylinder(0.022, 0.72, axis='y', center=(-0.72, 0.78, -0.47), sections=6),
        cylinder(0.06, 0.11, axis='y', center=(-0.72, 0.45, -0.47), sections=8),
        box((0.20, 0.14, 0.18), center=(-0.12, 0.71, -0.02)),
    ]
    # Compact smoke dischargers, kept subordinate to the rounded silhouette.
    for side in (-1, 1):
        for i, z in enumerate((0.12, 0.34)):
            launcher = cylinder(0.07, 0.27, axis='z', center=(side * (0.91 + 0.03 * i), 0.05 + 0.06 * i, z), sections=8)
            secondary.append(transformed(launcher, euler_deg=(-10, side * 9, 0)))

    accent = [
        # Restrained identification bars and hatch handles.
        box((0.045, 0.22, 0.54), center=(-1.12, 0.04, -0.12)),
        box((0.045, 0.22, 0.54), center=(1.12, 0.04, -0.12)),
        box((0.42, 0.035, 0.07), center=(-0.31, 0.73, -0.17)),
        box((0.36, 0.035, 0.065), center=(0.37, 0.68, 0.02)),
    ]

    optic = [
        # Searchlight body face and small periscope glass.
        cylinder(0.17, 0.08, axis='z', center=(0.57, 0.15, 1.14), sections=14),
        box((0.18, 0.10, 0.055), center=(-0.12, 0.73, 0.09)),
        box((0.15, 0.09, 0.05), center=(0.38, 0.66, 0.26)),
    ]

    return [
        Piece('Turret_Armor', merge(armor), 'Armor'),
        Piece('Turret_Secondary', merge(secondary), 'Secondary'),
        Piece('Turret_Accent', merge(accent), 'Accent'),
        Piece('Turret_Optics', merge(optic), 'Optic'),
    ]


def build_cannon() -> list[Piece]:
    armor = [
        cylinder(0.22, 0.38, axis='z', center=(0, 0, 0.20), sections=14),
        tapered_cylinder_z(0.155, 0.115, 0.86, center=(0, 0, 0.79), sections=14),
        cylinder(0.112, 2.76, axis='z', center=(0, 0, 2.60), sections=14),
        cylinder(0.145, 0.32, axis='z', center=(0, 0, 1.23), sections=14),
    ]
    secondary = [
        cylinder(0.145, 0.24, axis='z', center=(0, 0, 4.10), sections=14),
        cylinder(0.082, 0.032, axis='z', center=(0, 0, 4.235), sections=14),
    ]
    return [
        Piece('Cannon_Armor', merge(armor), 'Armor'),
        Piece('Cannon_Muzzle', merge(secondary), 'Secondary'),
    ]


def build_lod1_local() -> dict[str, list[Piece]]:
    # Simplified silhouettes retain articulation and the recognizable five-wheel/rounded-turret read.
    hull_base = np.array([
        [-1.20, -2.12], [1.20, -2.12], [1.30, -1.55], [1.30, 1.55],
        [1.00, 2.24], [-1.00, 2.24], [-1.30, 1.55], [-1.30, -1.55],
    ])
    hull_top = np.array([
        [-0.92, -1.54], [0.92, -1.54], [1.00, -1.04], [0.90, 0.72],
        [0.58, 1.28], [-0.58, 1.28], [-0.90, 0.72], [-1.00, -1.04],
    ])
    hull = [
        Piece('Hull_LOD1_Armor', layered_prism([hull_base, hull_top], [-0.55, 0.56]), 'Armor'),
        Piece('Hull_LOD1_Accent', box((1.22, 0.045, 0.16), center=(0, 0.58, 1.12)), 'Accent'),
    ]
    left = [Piece('LeftTrack_LOD1', box((0.50, 1.18, 4.65), center=(0, 0.02, 0)), 'Track')]
    right = [Piece('RightTrack_LOD1', box((0.50, 1.18, 4.65), center=(0, 0.02, 0)), 'Track')]
    turret_shell = layered_prism([
        radial_footprint(1.05, 0.94, z_shift=-0.11, sectors=10),
        radial_footprint(0.70, 0.60, z_shift=-0.16, sectors=10),
    ], [-0.25, 0.48])
    turret = [
        Piece('Turret_LOD1_Armor', merge([
            turret_shell,
            ellipsoid((1.12, 0.62, 0.55), center=(0, 0.02, 0.86), subdivisions=1),
        ]), 'Armor'),
        Piece('Turret_LOD1_Optic', cylinder(0.14, 0.05, axis='z', center=(0.55, 0.14, 1.10), sections=8), 'Optic'),
    ]
    cannon = [
        Piece('Cannon_LOD1', merge([
            cylinder(0.19, 0.36, axis='z', center=(0, 0, 0.20), sections=8),
            tapered_cylinder_z(0.13, 0.105, 3.90, center=(0, 0, 2.15), sections=8),
        ]), 'Armor')
    ]
    return {'Hull': hull, 'LeftTrack': left, 'RightTrack': right, 'Turret': turret, 'Cannon': cannon}


def palette_uv(name: str) -> tuple[float, float]:
    index = PALETTE_ORDER.index(name)
    return ((index + 0.5) / len(PALETTE_ORDER), 0.5)


def write_obj(path: Path, object_name: str, pieces: Sequence[Piece], mtl_reference='Bastion_Tank.mtl') -> None:
    lines = [
        '# Bastion TX-9R low-poly tank — generated original asset',
        '# Coordinates: meters, +Y up, +Z forward',
        f'mtllib {mtl_reference}',
        f'o {object_name}',
        f'g {object_name}',
        'usemtl BastionPalette',
        's off',
    ]
    for palette_name in PALETTE_ORDER:
        u, v = palette_uv(palette_name)
        lines.append(f'vt {u:.8f} {v:.8f}')

    vertex_offset = 1
    normal_offset = 1
    face_records: list[tuple[np.ndarray, int, int]] = []
    # Write all vertices first, keeping semantic sections as comments.
    for piece in pieces:
        mesh = clean_mesh(piece.mesh)
        lines.append(f'# piece {piece.name} palette={piece.palette}')
        for vertex in mesh.vertices:
            lines.append(f'v {vertex[0]:.8f} {vertex[1]:.8f} {vertex[2]:.8f}')
        for face_index, face in enumerate(mesh.faces):
            face_records.append((face + vertex_offset, PALETTE_ORDER.index(piece.palette) + 1, normal_offset))
            normal = mesh.face_normals[face_index]
            lines.append(f'vn {normal[0]:.8f} {normal[1]:.8f} {normal[2]:.8f}')
            normal_offset += 1
        vertex_offset += len(mesh.vertices)

    for face, uv_idx, normal_idx in face_records:
        a, b, c = [int(i) for i in face]
        lines.append(f'f {a}/{uv_idx}/{normal_idx} {b}/{uv_idx}/{normal_idx} {c}/{uv_idx}/{normal_idx}')

    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')


def write_mtl(path: Path) -> None:
    path.write_text(textwrap.dedent('''\
        # Single palette material. The Unity builder replaces this with a URP/Built-in compatible material.
        newmtl BastionPalette
        Ka 0.120000 0.120000 0.120000
        Kd 1.000000 1.000000 1.000000
        Ks 0.120000 0.120000 0.120000
        Ns 32.000000
        d 1.000000
        illum 2
        map_Kd ../Textures/Bastion_Palette.png
    '''), encoding='utf-8')


def create_textures() -> tuple[Image.Image, Image.Image]:
    width = SWATCH_WIDTH * len(PALETTE_ORDER)
    base = Image.new('RGBA', (width, TEXTURE_HEIGHT), (255, 255, 255, 255))
    emission = Image.new('RGBA', (width, TEXTURE_HEIGHT), (0, 0, 0, 255))
    draw = ImageDraw.Draw(base)
    emit_draw = ImageDraw.Draw(emission)
    for i, name in enumerate(PALETTE_ORDER):
        x0 = i * SWATCH_WIDTH
        x1 = (i + 1) * SWATCH_WIDTH - 1
        draw.rectangle((x0, 0, x1, TEXTURE_HEIGHT - 1), fill=PALETTE[name])
        if name == 'Optic':
            emit_draw.rectangle((x0, 0, x1, TEXTURE_HEIGHT - 1), fill=(80, 225, 255, 255))
    base.save(TEXTURE_DIR / 'Bastion_Palette.png', optimize=True)
    emission.save(TEXTURE_DIR / 'Bastion_Emission.png', optimize=True)
    return base, emission


def flatten_for_glb(pieces: Sequence[Piece], image: Image.Image) -> trimesh.Trimesh:
    vertices: list[np.ndarray] = []
    faces: list[list[int]] = []
    uvs: list[list[float]] = []
    cursor = 0
    for piece in pieces:
        mesh = clean_mesh(piece.mesh)
        uv = palette_uv(piece.palette)
        for face in mesh.faces:
            tri = mesh.vertices[face]
            vertices.extend(tri)
            uvs.extend([uv, uv, uv])
            faces.append([cursor, cursor + 1, cursor + 2])
            cursor += 3
    flat = trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=False)
    material = trimesh.visual.material.SimpleMaterial(image=image, name='BastionPalette')
    flat.visual = trimesh.visual.texture.TextureVisuals(uv=np.asarray(uvs), image=image, material=material)
    return flat


def export_glb(path: Path, nodes: dict[str, tuple[list[Piece], tuple[float, float, float], str | None]], image: Image.Image) -> None:
    scene = trimesh.Scene()
    # Add parent frames first.
    scene.graph.update(frame_to='TankRoot', frame_from='world', matrix=np.eye(4))
    for node_name, (pieces, translation, parent) in nodes.items():
        parent_name = parent or 'TankRoot'
        mesh = flatten_for_glb(pieces, image)
        matrix = translation_matrix(translation)
        scene.add_geometry(mesh, node_name=node_name, geom_name=f'{node_name}_Mesh', parent_node_name=parent_name, transform=matrix)
    path.write_bytes(scene.export(file_type='glb'))


def transform_pieces(pieces: Sequence[Piece], translation=(0.0, 0.0, 0.0), euler_deg=(0.0, 0.0, 0.0), prefix='') -> list[Piece]:
    return [Piece(prefix + p.name, transformed(p.mesh, translation=translation, euler_deg=euler_deg), p.palette) for p in pieces]


def combine_all(parts: dict[str, list[Piece]]) -> list[Piece]:
    world: list[Piece] = []
    world.extend(transform_pieces(parts['Hull'], translation=(0, 1.00, 0), prefix='Static_'))
    world.extend(transform_pieces(parts['LeftTrack'], translation=(-1.43, 0.65, 0), prefix='Static_'))
    world.extend(transform_pieces(parts['RightTrack'], translation=(1.43, 0.65, 0), prefix='Static_'))
    world.extend(transform_pieces(parts['Turret'], translation=(0, 1.70, -0.10), prefix='Static_'))
    world.extend(transform_pieces(parts['Cannon'], translation=(0, 1.82, 0.72), prefix='Static_'))
    return world


def render_preview(pieces: Sequence[Piece], path: Path, view: str = 'perspective') -> None:
    """Render an antialiased asset card with a lightweight software triangle painter."""
    scale_factor = 2
    width, height = 1600 * scale_factor, 900 * scale_factor

    # Vertical background gradient.
    top = np.array([229, 235, 235], dtype=float)
    bottom = np.array([246, 244, 236], dtype=float)
    gradient = np.linspace(top, bottom, height, dtype=np.uint8)[:, None, :]
    background = np.repeat(gradient, width, axis=1)
    image = Image.fromarray(background, mode='RGB')

    draw = ImageDraw.Draw(image, 'RGBA')
    if view == 'top':
        eye = np.array([0.01, 10.0, 0.01])
        target = np.array([0.0, 0.8, 0.4])
        camera_up = np.array([0.0, 0.0, 1.0])
        viewport = (160, 105, 1440, 815)
        label = 'TOP VIEW'
    elif view == 'side':
        eye = np.array([9.0, 2.7, 0.0])
        target = np.array([0.0, 1.05, 0.45])
        camera_up = np.array([0.0, 1.0, 0.0])
        viewport = (120, 105, 1480, 815)
        label = 'SIDE VIEW'
    else:
        eye = np.array([6.7, 4.2, 7.5])
        target = np.array([0.0, 1.05, 0.55])
        camera_up = np.array([0.0, 1.0, 0.0])
        viewport = (440, 90, 1530, 830)
        label = 'CLASSIC CAST-TURRET REVISION'

    forward = target - eye
    forward /= np.linalg.norm(forward)
    right = np.cross(forward, camera_up)
    right /= np.linalg.norm(right)
    up = np.cross(right, forward)
    up /= np.linalg.norm(up)

    all_vertices = np.vstack([p.mesh.vertices for p in pieces])
    rel = all_vertices - eye[None, :]
    cam_x = rel @ right
    cam_y = rel @ up
    cam_z = rel @ forward
    perspective = view == 'perspective'
    if perspective:
        px = cam_x / np.maximum(cam_z, 1e-4)
        py = cam_y / np.maximum(cam_z, 1e-4)
    else:
        px, py = cam_x, cam_y

    vx0, vy0, vx1, vy1 = [v * scale_factor for v in viewport]
    margin = 20 * scale_factor
    span_x = max(float(px.max() - px.min()), 1e-6)
    span_y = max(float(py.max() - py.min()), 1e-6)
    fit_scale = min((vx1 - vx0 - 2 * margin) / span_x, (vy1 - vy0 - 2 * margin) / span_y)
    center_px = float((px.min() + px.max()) * 0.5)
    center_py = float((py.min() + py.max()) * 0.5)
    center_screen_x = (vx0 + vx1) * 0.5
    center_screen_y = (vy0 + vy1) * 0.5

    # Ground shadow for the perspective card.
    if perspective:
        shadow_box = (500 * scale_factor, 660 * scale_factor, 1490 * scale_factor, 850 * scale_factor)
        shadow = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow, 'RGBA')
        shadow_draw.ellipse(shadow_box, fill=(20, 26, 25, 55))
        shadow = shadow.filter(ImageFilter.GaussianBlur(24 * scale_factor))
        image = Image.alpha_composite(image.convert('RGBA'), shadow).convert('RGB')
        draw = ImageDraw.Draw(image, 'RGBA')

    light = np.array([-0.45, 0.80, 0.58], dtype=float)
    light /= np.linalg.norm(light)
    camera_dir = -forward
    triangles = []
    vertex_cursor = 0
    for piece in pieces:
        mesh = clean_mesh(piece.mesh)
        base = np.array(PALETTE[piece.palette][:3], dtype=float)
        rel_piece = mesh.vertices - eye[None, :]
        cx = rel_piece @ right
        cy = rel_piece @ up
        cz = rel_piece @ forward
        if perspective:
            qx = cx / np.maximum(cz, 1e-4)
            qy = cy / np.maximum(cz, 1e-4)
        else:
            qx, qy = cx, cy
        sx = center_screen_x + (qx - center_px) * fit_scale
        sy = center_screen_y - (qy - center_py) * fit_scale
        projected = np.column_stack([sx, sy])
        for face_idx, face in enumerate(mesh.faces):
            depth = float(np.mean(cz[face]))
            normal = mesh.face_normals[face_idx]
            diffuse = max(0.0, float(np.dot(normal, light)))
            rim = (1.0 - abs(float(np.dot(normal, camera_dir)))) ** 2
            intensity = np.clip(0.43 + 0.50 * diffuse + 0.08 * rim, 0.28, 1.08)
            rgb = tuple(np.clip(base * intensity, 0, 255).astype(np.uint8))
            points = [tuple(projected[i]) for i in face]
            triangles.append((depth, points, rgb))

    # Painter's algorithm: far to near.
    triangles.sort(key=lambda item: item[0], reverse=True)
    for _, points, rgb in triangles:
        draw.polygon(points, fill=(*rgb, 255))
        draw.line(points + [points[0]], fill=(25, 28, 26, 72), width=max(1, scale_factor))

    title_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 56 * scale_factor)
    sub_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 25 * scale_factor)
    label_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20 * scale_factor)
    spec_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 21 * scale_factor)

    if perspective:
        draw.text((58 * scale_factor, 74 * scale_factor), 'BASTION TX-9R', font=title_font, fill=(23, 28, 27, 255))
        draw.text((61 * scale_factor, 147 * scale_factor), 'Unity / Meta Quest low-poly RTS tank', font=sub_font, fill=(66, 72, 69, 255))
        draw.rounded_rectangle((61 * scale_factor, 210 * scale_factor, 470 * scale_factor, 252 * scale_factor),
                               radius=12 * scale_factor, fill=(62, 65, 52, 220))
        draw.text((78 * scale_factor, 217 * scale_factor), label, font=label_font, fill=(239, 235, 214, 255))
        specs = [
            'Rounded cast turret',
            'Five main road wheels',
            'Low sloped hull + ribbed fenders',
            'Articulated turret and cannon',
            'One palette material',
        ]
        y = 298 * scale_factor
        for spec in specs:
            draw.ellipse((66 * scale_factor, y + 8 * scale_factor, 76 * scale_factor, y + 18 * scale_factor), fill=(151, 128, 76, 255))
            draw.text((91 * scale_factor, y), spec, font=spec_font, fill=(55, 61, 58, 255))
            y += 47 * scale_factor
        draw.text((61 * scale_factor, 820 * scale_factor), 'Original geometry • classic Cold War visual language • not an exact replica',
                  font=spec_font, fill=(76, 80, 76, 235))
    else:
        draw.text((58 * scale_factor, 48 * scale_factor), f'BASTION TX-9R — {label}', font=sub_font, fill=(33, 39, 37, 255))

    image = image.resize((1600, 900), Image.Resampling.LANCZOS)
    image.save(path, optimize=True)


def write_controller_script() -> None:
    code = r'''using UnityEngine;

namespace BastionTankR
{
    [DisallowMultipleComponent]
    public sealed class BastionTankRController : MonoBehaviour
    {
        [Header("Articulation")]
        [SerializeField] private Transform turretYaw;
        [SerializeField] private Transform cannonPitch;

        [Header("Traverse")]
        [SerializeField, Min(0f)] private float turretSpeedDegrees = 100f;
        [SerializeField, Min(0f)] private float cannonSpeedDegrees = 70f;
        [SerializeField] private float minimumElevation = -7f;
        [SerializeField] private float maximumElevation = 32f;

        private bool hasAimPoint;
        private Vector3 aimPoint;

        public Transform TurretYaw => turretYaw;
        public Transform CannonPitch => cannonPitch;

        private void Reset()
        {
            ResolveTransforms();
        }

        private void Awake()
        {
            ResolveTransforms();
        }

        private void LateUpdate()
        {
            if (hasAimPoint)
            {
                RotateToward(aimPoint, Time.deltaTime);
            }
        }

        public void SetAimPoint(Vector3 worldPoint)
        {
            aimPoint = worldPoint;
            hasAimPoint = true;
        }

        public void ClearAimPoint()
        {
            hasAimPoint = false;
        }

        public void SnapAimAt(Vector3 worldPoint)
        {
            if (!ResolveTransforms())
            {
                return;
            }

            ApplyAim(worldPoint, 1f, true);
        }

        private void RotateToward(Vector3 worldPoint, float deltaTime)
        {
            if (!ResolveTransforms())
            {
                return;
            }

            ApplyAim(worldPoint, deltaTime, false);
        }

        private void ApplyAim(Vector3 worldPoint, float deltaTime, bool snap)
        {
            Vector3 flatDirection = worldPoint - turretYaw.position;
            flatDirection.y = 0f;
            if (flatDirection.sqrMagnitude > 0.0001f)
            {
                Quaternion desiredWorldYaw = Quaternion.LookRotation(flatDirection.normalized, transform.up);
                Quaternion desiredLocalYaw = Quaternion.Inverse(turretYaw.parent.rotation) * desiredWorldYaw;
                float targetYaw = desiredLocalYaw.eulerAngles.y;
                float currentYaw = turretYaw.localEulerAngles.y;
                float nextYaw = snap
                    ? targetYaw
                    : Mathf.MoveTowardsAngle(currentYaw, targetYaw, turretSpeedDegrees * deltaTime);
                turretYaw.localRotation = Quaternion.Euler(0f, nextYaw, 0f);
            }

            Vector3 localDirection = turretYaw.InverseTransformDirection(worldPoint - cannonPitch.position);
            float elevation = Mathf.Atan2(localDirection.y, Mathf.Max(0.0001f, localDirection.z)) * Mathf.Rad2Deg;
            elevation = Mathf.Clamp(elevation, minimumElevation, maximumElevation);

            // Unity's positive X rotation tips +Z downward, so elevation uses a negative local X angle.
            float targetPitch = -elevation;
            float currentPitch = NormalizeAngle(cannonPitch.localEulerAngles.x);
            float nextPitch = snap
                ? targetPitch
                : Mathf.MoveTowardsAngle(currentPitch, targetPitch, cannonSpeedDegrees * deltaTime);
            cannonPitch.localRotation = Quaternion.Euler(nextPitch, 0f, 0f);
        }

        private bool ResolveTransforms()
        {
            if (turretYaw == null)
            {
                turretYaw = transform.Find("TurretYaw");
            }

            if (cannonPitch == null && turretYaw != null)
            {
                cannonPitch = turretYaw.Find("CannonPitch");
            }

            return turretYaw != null && cannonPitch != null;
        }

        private static float NormalizeAngle(float angle)
        {
            return angle > 180f ? angle - 360f : angle;
        }
    }
}
'''
    (SCRIPT_DIR / 'BastionTankRController.cs').write_text(code, encoding='utf-8')


def write_importer_script() -> None:
    code = r'''using UnityEditor;
using UnityEngine;

namespace BastionTankR.Editor
{
    internal sealed class BastionTankImportPostprocessor : AssetPostprocessor
    {
        private const string MeshPath = "Assets/BastionTankR/Meshes/";
        private const string TexturePath = "Assets/BastionTankR/Textures/";

        private void OnPreprocessModel()
        {
            if (!assetPath.StartsWith(MeshPath, System.StringComparison.Ordinal))
            {
                return;
            }

            ModelImporter importer = (ModelImporter)assetImporter;
            importer.globalScale = 1f;
            importer.importAnimation = false;
            importer.importBlendShapes = false;
            importer.importCameras = false;
            importer.importLights = false;
            importer.isReadable = false;
            importer.meshCompression = ModelImporterMeshCompression.Medium;
            importer.normalImportMode = ModelImporterNormals.Import;
        }

        private void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith(TexturePath, System.StringComparison.Ordinal))
            {
                return;
            }

            TextureImporter importer = (TextureImporter)assetImporter;
            importer.textureType = TextureImporterType.Default;
            importer.sRGBTexture = true;
            importer.mipmapEnabled = false;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Point;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
        }
    }
}
'''
    (EDITOR_DIR / 'BastionTankImportPostprocessor.cs').write_text(code, encoding='utf-8')


def write_builder_script() -> None:
    code = r'''using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace BastionTankR.Editor
{
    internal static class BastionTankPrefabBuilder
    {
        private const string Root = "Assets/BastionTankR";
        private const string Meshes = Root + "/Meshes";
        private const string Textures = Root + "/Textures";
        private const string Materials = Root + "/Materials";
        private const string Prefabs = Root + "/Prefabs";
        private const string PrefabPath = Prefabs + "/Bastion_TX9R.prefab";
        private const string MaterialPath = Materials + "/Bastion_Palette.mat";

        private static readonly string[] RequiredModels =
        {
            Meshes + "/Bastion_Hull.obj",
            Meshes + "/Bastion_LeftTrack.obj",
            Meshes + "/Bastion_RightTrack.obj",
            Meshes + "/Bastion_Turret.obj",
            Meshes + "/Bastion_Cannon.obj",
            Meshes + "/Bastion_Tank_LOD1.obj"
        };

        [InitializeOnLoadMethod]
        private static void QueueAutomaticBuild()
        {
            EditorApplication.delayCall += () =>
            {
                if (AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath) == null && AssetsReady())
                {
                    Build(false);
                }
            };
        }

        [MenuItem("Tools/Bastion TX-9R/Create or Rebuild Prefab")]
        private static void BuildFromMenu()
        {
            Build(true);
        }

        private static bool AssetsReady()
        {
            foreach (string path in RequiredModels)
            {
                if (AssetDatabase.LoadAssetAtPath<GameObject>(path) == null)
                {
                    return false;
                }
            }

            return AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_Palette.png") != null;
        }

        private static void Build(bool selectResult)
        {
            if (!AssetsReady())
            {
                Debug.LogWarning("Bastion TX-9R: model imports are not ready yet. Re-run Tools > Bastion TX-9R > Create or Rebuild Prefab after Unity finishes importing.");
                return;
            }

            EnsureFolder(Materials);
            EnsureFolder(Prefabs);
            Material material = CreateOrUpdateMaterial();

            GameObject root = new GameObject("Bastion_TX9R");
            root.transform.position = Vector3.zero;
            root.transform.rotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;

            GameObject hull = InstantiateModel("Bastion_Hull", RequiredModels[0], root.transform, new Vector3(0f, 1.00f, 0f), material);
            GameObject leftTrack = InstantiateModel("LeftTrack", RequiredModels[1], root.transform, new Vector3(-1.43f, 0.65f, 0f), material);
            GameObject rightTrack = InstantiateModel("RightTrack", RequiredModels[2], root.transform, new Vector3(1.43f, 0.65f, 0f), material);

            GameObject turretYaw = new GameObject("TurretYaw");
            turretYaw.transform.SetParent(root.transform, false);
            turretYaw.transform.localPosition = new Vector3(0f, 1.70f, -0.10f);
            InstantiateModel("Bastion_Turret", RequiredModels[3], turretYaw.transform, Vector3.zero, material);

            GameObject cannonPitch = new GameObject("CannonPitch");
            cannonPitch.transform.SetParent(turretYaw.transform, false);
            cannonPitch.transform.localPosition = new Vector3(0f, 0.12f, 0.82f);
            InstantiateModel("Bastion_Cannon", RequiredModels[4], cannonPitch.transform, Vector3.zero, material);

            GameObject lod1 = InstantiateModel("Bastion_LOD1", RequiredModels[5], root.transform, Vector3.zero, material);
            lod1.SetActive(true);

            ConfigureLODGroup(root, new[] { hull, leftTrack, rightTrack, turretYaw }, lod1);

            BoxCollider collider = root.AddComponent<BoxCollider>();
            collider.center = new Vector3(0f, 1.05f, -0.02f);
            collider.size = new Vector3(3.45f, 2.20f, 5.10f);

            BastionTankRController controller = root.AddComponent<BastionTankRController>();
            SerializedObject serializedController = new SerializedObject(controller);
            serializedController.FindProperty("turretYaw").objectReferenceValue = turretYaw.transform;
            serializedController.FindProperty("cannonPitch").objectReferenceValue = cannonPitch.transform;
            serializedController.ApplyModifiedPropertiesWithoutUndo();

            PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
            UnityEngine.Object.DestroyImmediate(root);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            if (selectResult && prefab != null)
            {
                Selection.activeObject = prefab;
                EditorGUIUtility.PingObject(prefab);
            }

            Debug.Log("Bastion TX-9R: created " + PrefabPath);
        }

        private static GameObject InstantiateModel(string name, string path, Transform parent, Vector3 localPosition, Material material)
        {
            GameObject source = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(source);
            instance.name = name;
            instance.transform.SetParent(parent, false);
            instance.transform.localPosition = localPosition;
            instance.transform.localRotation = Quaternion.identity;
            instance.transform.localScale = Vector3.one;

            foreach (Renderer renderer in instance.GetComponentsInChildren<Renderer>(true))
            {
                int materialCount = Mathf.Max(1, renderer.sharedMaterials.Length);
                Material[] shared = new Material[materialCount];
                for (int i = 0; i < shared.Length; i++)
                {
                    shared[i] = material;
                }
                renderer.sharedMaterials = shared;
                renderer.shadowCastingMode = ShadowCastingMode.On;
                renderer.receiveShadows = true;
                renderer.lightProbeUsage = LightProbeUsage.BlendProbes;
            }

            return instance;
        }

        private static void ConfigureLODGroup(GameObject root, IEnumerable<GameObject> lod0Roots, GameObject lod1Root)
        {
            List<Renderer> lod0Renderers = new List<Renderer>();
            foreach (GameObject item in lod0Roots)
            {
                lod0Renderers.AddRange(item.GetComponentsInChildren<Renderer>(true));
            }

            Renderer[] lod1Renderers = lod1Root.GetComponentsInChildren<Renderer>(true);
            LODGroup group = root.AddComponent<LODGroup>();
            group.fadeMode = LODFadeMode.CrossFade;
            group.animateCrossFading = false;
            LOD high = new LOD(0.18f, lod0Renderers.ToArray());
            high.fadeTransitionWidth = 0.08f;
            LOD low = new LOD(0.045f, lod1Renderers);
            low.fadeTransitionWidth = 0.10f;
            LOD culled = new LOD(0.008f, Array.Empty<Renderer>());
            group.SetLODs(new[] { high, low, culled });
            group.RecalculateBounds();
        }

        private static Material CreateOrUpdateMaterial()
        {
            Material material = AssetDatabase.LoadAssetAtPath<Material>(MaterialPath);
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null)
            {
                shader = Shader.Find("Standard");
            }
            if (shader == null)
            {
                throw new InvalidOperationException("Bastion TX-9R: neither URP/Lit nor Standard shader could be found.");
            }

            if (material == null)
            {
                material = new Material(shader) { name = "Bastion_Palette" };
                AssetDatabase.CreateAsset(material, MaterialPath);
            }
            else if (material.shader != shader)
            {
                material.shader = shader;
            }

            Texture2D palette = AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_Palette.png");
            Texture2D emission = AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_Emission.png");

            SetTextureIfPresent(material, "_BaseMap", palette);
            SetTextureIfPresent(material, "_MainTex", palette);
            SetColorIfPresent(material, "_BaseColor", Color.white);
            SetColorIfPresent(material, "_Color", Color.white);
            SetFloatIfPresent(material, "_Metallic", 0.12f);
            SetFloatIfPresent(material, "_Smoothness", 0.34f);
            SetFloatIfPresent(material, "_Glossiness", 0.34f);

            if (emission != null)
            {
                SetTextureIfPresent(material, "_EmissionMap", emission);
                SetColorIfPresent(material, "_EmissionColor", Color.white * 1.25f);
                material.EnableKeyword("_EMISSION");
            }

            material.enableInstancing = true;
            EditorUtility.SetDirty(material);
            return material;
        }

        private static void SetTextureIfPresent(Material material, string property, Texture texture)
        {
            if (material.HasProperty(property))
            {
                material.SetTexture(property, texture);
            }
        }

        private static void SetColorIfPresent(Material material, string property, Color value)
        {
            if (material.HasProperty(property))
            {
                material.SetColor(property, value);
            }
        }

        private static void SetFloatIfPresent(Material material, string property, float value)
        {
            if (material.HasProperty(property))
            {
                material.SetFloat(property, value);
            }
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path))
            {
                return;
            }

            string parent = Path.GetDirectoryName(path)?.Replace('\\', '/');
            string name = Path.GetFileName(path);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent))
            {
                EnsureFolder(parent);
            }
            AssetDatabase.CreateFolder(parent, name);
        }
    }
}
'''
    (EDITOR_DIR / 'BastionTankPrefabBuilder.cs').write_text(code, encoding='utf-8')


def write_readme(stats: dict) -> None:
    readme = f'''# Bastion TX-9R — Unity / Meta Quest tank asset

This is an original, low-poly RTS tank revised around a classic Cold War silhouette: a rounded cast turret, five large road wheels, a low sloped hull, curved ribbed fenders, and a long plain gun tube. It uses that broad historical visual language without reproducing a specific game vehicle, logo, faction mark, or texture.

## Import

1. Close Unity or leave it open.
2. Copy the included `Assets/BastionTankR` folder into your Unity project’s `Assets` folder.
3. Let Unity import and compile. The editor script creates `Assets/BastionTankR/Prefabs/Bastion_TX9R.prefab` automatically.
4. If the prefab is not created, run **Tools > Bastion TX-9R > Create or Rebuild Prefab**.
5. Drag `Bastion_TX9R.prefab` into a scene.

The OBJ files are Unity-native import assets. The optional GLB files in `Extras` require a glTF importer package and are not used by the prefab builder.

## Coordinate and scale conventions

- 1 Unity unit = 1 meter
- +Y = up
- +Z = forward / gun direction
- Root origin = ground-center of the vehicle
- Turret yaw pivot = `TurretYaw`
- Cannon elevation pivot = `TurretYaw/CannonPitch`

## Runtime aiming

`BastionTankRController` exposes:

```csharp
controller.SetAimPoint(targetPosition);
controller.ClearAimPoint();
controller.SnapAimAt(targetPosition);
```

The controller only articulates the turret and cannon. Connect movement, firing, audio, damage, and networking to your own gameplay systems.

## Technical profile

- LOD0 triangles: {stats['lod0_triangles']:,}
- LOD1 triangles: {stats['lod1_triangles']:,}
- LOD0 articulated model roots: 5
- Shared materials: 1
- Palette textures: 2 × {stats['texture_width']}×{stats['texture_height']} RGBA PNG
- Approximate bounds, cannon forward: {stats['bounds_m'][0]:.2f} m wide × {stats['bounds_m'][1]:.2f} m high × {stats['bounds_m'][2]:.2f} m long
- Collision: one inexpensive BoxCollider
- LOD culling included
- GPU instancing enabled on the generated material

## Files

- `Meshes/Bastion_Hull.obj`
- `Meshes/Bastion_LeftTrack.obj`
- `Meshes/Bastion_RightTrack.obj`
- `Meshes/Bastion_Turret.obj`
- `Meshes/Bastion_Cannon.obj`
- `Meshes/Bastion_Tank_Static.obj` — one-piece quick-import model
- `Meshes/Bastion_Tank_LOD1.obj`
- `Extras/Bastion_Tank_Articulated.glb`
- `Extras/Bastion_Tank_Static.glb`

## Quest-oriented notes

The package deliberately uses flat-shaded geometry, small uncompressed palette textures, one shared material, no transparency, no normal map, a simplified collider, and a low-detail distant mesh. Validate the final unit count and target frame rate on the specific Quest headset using Unity Profiler and Meta’s performance tools.
'''
    (ASSET_ROOT / 'README.md').write_text(readme, encoding='utf-8')

    root_readme = '''Bastion TX-9R Unity Asset\n\nQUICK START\n1. Copy the Assets folder into the root of your Unity project.\n2. Unity creates Assets/BastionTankR/Prefabs/Bastion_TX9R.prefab.\n3. See Assets/BastionTankR/README.md for controls and technical details.\n'''
    (OUTPUT_ROOT / 'README_FIRST.txt').write_text(root_readme, encoding='utf-8')


def write_license() -> None:
    text = '''Bastion TX-9R asset notice\n\nThis package contains original geometry, textures, and source code generated for the recipient. No third-party logos, trademarked faction marks, or copied game assets are included. Use, modify, and integrate the package subject to the terms that govern your use of the AI service through which it was generated.\n\nNo warranty is provided. Test performance, collision behavior, shader compatibility, and platform compliance in your own Unity project before shipping.\n'''
    (ASSET_ROOT / 'ASSET_NOTICE.txt').write_text(text, encoding='utf-8')


def write_spec(stats: dict) -> None:
    (PREVIEW_DIR / 'Bastion_TX9R_Spec.json').write_text(json.dumps(stats, indent=2), encoding='utf-8')


def zip_folder(source: Path, destination: Path) -> None:
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(source))


def main() -> None:
    if OUTPUT_ROOT.exists():
        shutil.rmtree(OUTPUT_ROOT)
    for directory in (MESH_DIR, TEXTURE_DIR, SCRIPT_DIR, EDITOR_DIR, EXTRAS_DIR, PREVIEW_DIR, SOURCE_DIR):
        directory.mkdir(parents=True, exist_ok=True)

    base_image, _ = create_textures()
    write_mtl(MESH_DIR / 'Bastion_Tank.mtl')

    parts = {
        'Hull': build_hull(),
        'LeftTrack': build_track(-1),
        'RightTrack': build_track(1),
        'Turret': build_turret(),
        'Cannon': build_cannon(),
    }

    write_obj(MESH_DIR / 'Bastion_Hull.obj', 'Bastion_Hull', parts['Hull'])
    write_obj(MESH_DIR / 'Bastion_LeftTrack.obj', 'Bastion_LeftTrack', parts['LeftTrack'])
    write_obj(MESH_DIR / 'Bastion_RightTrack.obj', 'Bastion_RightTrack', parts['RightTrack'])
    write_obj(MESH_DIR / 'Bastion_Turret.obj', 'Bastion_Turret', parts['Turret'])
    write_obj(MESH_DIR / 'Bastion_Cannon.obj', 'Bastion_Cannon', parts['Cannon'])

    static_pieces = combine_all(parts)
    write_obj(MESH_DIR / 'Bastion_Tank_Static.obj', 'Bastion_Tank_Static', static_pieces)

    lod_local = build_lod1_local()
    lod_static = combine_all(lod_local)
    write_obj(MESH_DIR / 'Bastion_Tank_LOD1.obj', 'Bastion_Tank_LOD1', lod_static)

    export_glb(
        EXTRAS_DIR / 'Bastion_Tank_Articulated.glb',
        {
            'Hull': (parts['Hull'], (0, 1.00, 0), None),
            'LeftTrack': (parts['LeftTrack'], (-1.43, 0.65, 0), None),
            'RightTrack': (parts['RightTrack'], (1.43, 0.65, 0), None),
            'TurretYaw': (parts['Turret'], (0, 1.70, -0.10), None),
            'CannonPitch': (parts['Cannon'], (0, 0.12, 0.82), 'TurretYaw'),
        },
        base_image,
    )
    static_glb_mesh = flatten_for_glb(static_pieces, base_image)
    (EXTRAS_DIR / 'Bastion_Tank_Static.glb').write_bytes(static_glb_mesh.export(file_type='glb'))

    write_controller_script()
    write_importer_script()
    write_builder_script()
    write_license()

    lod0_triangles = sum(len(piece.mesh.faces) for group in parts.values() for piece in group)
    lod1_triangles = sum(len(piece.mesh.faces) for piece in lod_static)
    all_vertices = np.vstack([piece.mesh.vertices for piece in static_pieces])
    mins = all_vertices.min(axis=0)
    maxs = all_vertices.max(axis=0)
    bounds = maxs - mins
    stats = {
        'asset_name': 'Bastion TX-9R',
        'coordinate_system': 'Y-up, Z-forward, meters',
        'lod0_triangles': int(lod0_triangles),
        'lod1_triangles': int(lod1_triangles),
        'articulated_renderers': 5,
        'materials': 1,
        'texture_width': SWATCH_WIDTH * len(PALETTE_ORDER),
        'texture_height': TEXTURE_HEIGHT,
        'bounds_m': [float(bounds[0]), float(bounds[1]), float(bounds[2])],
        'bounds_min': [float(v) for v in mins],
        'bounds_max': [float(v) for v in maxs],
        'pivot_positions': {
            'Hull': [0.0, 1.00, 0.0],
            'LeftTrack': [-1.43, 0.65, 0.0],
            'RightTrack': [1.43, 0.65, 0.0],
            'TurretYaw': [0.0, 1.70, -0.10],
            'CannonPitch_local': [0.0, 0.12, 0.82],
        },
    }
    write_readme(stats)
    write_spec(stats)
    render_preview(static_pieces, PREVIEW_DIR / 'Bastion_TX9R_Preview.png', view='perspective')
    render_preview(static_pieces, PREVIEW_DIR / 'Bastion_TX9R_Side.png', view='side')
    render_preview(static_pieces, PREVIEW_DIR / 'Bastion_TX9R_Top.png', view='top')

    # Preserve the exact generator used for reproducibility.
    shutil.copy2(Path(__file__), SOURCE_DIR / 'generate_bastion_tx9r.py')

    zip_folder(OUTPUT_ROOT, Path('/mnt/data/Bastion_TX9R_Unity_Asset.zip'))

    # A minimal quick-import bundle for users who only need the single static mesh.
    quick = Path('/mnt/data/Bastion_TX9R_QuickImport')
    if quick.exists():
        shutil.rmtree(quick)
    (quick / 'Meshes').mkdir(parents=True)
    (quick / 'Textures').mkdir(parents=True)
    for filename in ('Bastion_Tank_Static.obj', 'Bastion_Tank.mtl'):
        shutil.copy2(MESH_DIR / filename, quick / 'Meshes' / filename)
    for filename in ('Bastion_Palette.png', 'Bastion_Emission.png'):
        shutil.copy2(TEXTURE_DIR / filename, quick / 'Textures' / filename)
    (quick / 'README.txt').write_text('Drag the Meshes and Textures folders into Unity together. Use Bastion_Tank_Static.obj for a non-articulated one-piece model.\n', encoding='utf-8')
    zip_folder(quick, Path('/mnt/data/Bastion_TX9R_QuickImport.zip'))

    print(json.dumps(stats, indent=2))


if __name__ == '__main__':
    main()
