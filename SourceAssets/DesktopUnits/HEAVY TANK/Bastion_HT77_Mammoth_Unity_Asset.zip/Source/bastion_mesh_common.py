from __future__ import annotations

import json
import math
import shutil
import textwrap
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import trimesh
from trimesh.transformations import rotation_matrix, translation_matrix


OUTPUT_ROOT = Path('/mnt/data/Bastion_MT12_Rider_Unity_Package')
ASSET_ROOT = OUTPUT_ROOT / 'Assets' / 'BastionMediumTank'
MESH_DIR = ASSET_ROOT / 'Meshes'
TEXTURE_DIR = ASSET_ROOT / 'Textures'
SCRIPT_DIR = ASSET_ROOT / 'Scripts'
EDITOR_DIR = ASSET_ROOT / 'Editor'
EXTRAS_DIR = ASSET_ROOT / 'Extras'
PREVIEW_DIR = OUTPUT_ROOT / 'Preview'
SOURCE_DIR = OUTPUT_ROOT / 'Source'

ASSET_NAME = 'Bastion MT-12 Rider'
ASSET_SLUG = 'Bastion_MT12_Rider'
MTL_NAME = 'Bastion_MT12.mtl'

PALETTE = {
    'Armor': (88, 96, 76, 255),
    'Secondary': (60, 64, 60, 255),
    'Track': (25, 28, 27, 255),
    'Weapon': (45, 49, 48, 255),
    'Accent': (178, 68, 38, 255),
    'Optic': (56, 116, 124, 255),
    'Crew': (157, 164, 151, 255),
}
PALETTE_ORDER = list(PALETTE)
SWATCH_WIDTH = 32
TEXTURE_HEIGHT = 32


@dataclass(frozen=True)
class Piece:
    name: str
    mesh: trimesh.Trimesh
    palette: str


def clean_mesh(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    mesh = mesh.copy()
    mesh.remove_unreferenced_vertices()
    try:
        mesh.remove_duplicate_faces()
    except Exception:
        pass
    try:
        mesh.fix_normals(multibody=True)
    except TypeError:
        mesh.fix_normals()
    return mesh


def merge(meshes: Iterable[trimesh.Trimesh]) -> trimesh.Trimesh:
    items = [clean_mesh(m) for m in meshes]
    if not items:
        raise ValueError('Cannot merge an empty mesh list')
    return clean_mesh(trimesh.util.concatenate(items))


def box(extents: Sequence[float], center=(0.0, 0.0, 0.0), euler_deg=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    mesh = trimesh.creation.box(extents=np.asarray(extents, dtype=float))
    rx, ry, rz = [math.radians(v) for v in euler_deg]
    matrix = trimesh.transformations.euler_matrix(rx, ry, rz, axes='sxyz')
    matrix[:3, 3] = np.asarray(center, dtype=float)
    mesh.apply_transform(matrix)
    return clean_mesh(mesh)


def cylinder(radius: float, height: float, axis: str = 'z', center=(0.0, 0.0, 0.0), sections=12) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    if axis == 'x':
        mesh.apply_transform(rotation_matrix(math.pi / 2.0, [0, 1, 0]))
    elif axis == 'y':
        mesh.apply_transform(rotation_matrix(-math.pi / 2.0, [1, 0, 0]))
    elif axis != 'z':
        raise ValueError(f'Unsupported axis {axis}')
    mesh.apply_translation(np.asarray(center, dtype=float))
    return clean_mesh(mesh)


def cone(radius: float, height: float, axis: str = 'y', center=(0.0, 0.0, 0.0), sections=10) -> trimesh.Trimesh:
    mesh = trimesh.creation.cone(radius=radius, height=height, sections=sections)
    if axis == 'x':
        mesh.apply_transform(rotation_matrix(math.pi / 2.0, [0, 1, 0]))
    elif axis == 'y':
        mesh.apply_transform(rotation_matrix(-math.pi / 2.0, [1, 0, 0]))
    elif axis != 'z':
        raise ValueError(f'Unsupported axis {axis}')
    mesh.apply_translation(np.asarray(center, dtype=float))
    return clean_mesh(mesh)


def ellipsoid(extents: Sequence[float], center=(0.0, 0.0, 0.0), subdivisions=1) -> trimesh.Trimesh:
    mesh = trimesh.creation.icosphere(subdivisions=subdivisions, radius=1.0)
    mesh.apply_scale(np.asarray(extents, dtype=float) * 0.5)
    mesh.apply_translation(np.asarray(center, dtype=float))
    return clean_mesh(mesh)


def transformed(mesh: trimesh.Trimesh, translation=(0.0, 0.0, 0.0), euler_deg=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    out = mesh.copy()
    rx, ry, rz = [math.radians(v) for v in euler_deg]
    matrix = trimesh.transformations.euler_matrix(rx, ry, rz, axes='sxyz')
    matrix[:3, 3] = np.asarray(translation, dtype=float)
    out.apply_transform(matrix)
    return clean_mesh(out)


def cylinder_between(p0: Sequence[float], p1: Sequence[float], radius: float, sections: int = 8) -> trimesh.Trimesh:
    a = np.asarray(p0, dtype=float)
    b = np.asarray(p1, dtype=float)
    direction = b - a
    length = float(np.linalg.norm(direction))
    if length <= 1e-6:
        raise ValueError('Cylinder endpoints must differ')
    mesh = trimesh.creation.cylinder(radius=radius, height=length, sections=sections)
    align = trimesh.geometry.align_vectors([0.0, 0.0, 1.0], direction / length)
    if align is None:
        align = np.eye(4)
    align[:3, 3] = (a + b) * 0.5
    mesh.apply_transform(align)
    return clean_mesh(mesh)


def layered_prism(footprints: Sequence[np.ndarray], heights: Sequence[float]) -> trimesh.Trimesh:
    if len(footprints) != len(heights) or len(footprints) < 2:
        raise ValueError('Need matching footprint and height layers')
    n = len(footprints[0])
    if any(len(p) != n for p in footprints):
        raise ValueError('All footprints must have the same vertex count')

    vertices: list[list[float]] = []
    for poly, y in zip(footprints, heights):
        for x, z in poly:
            vertices.append([float(x), float(y), float(z)])

    faces: list[list[int]] = []
    layers = len(footprints)
    for layer in range(layers - 1):
        a0 = layer * n
        b0 = (layer + 1) * n
        for i in range(n):
            j = (i + 1) % n
            faces.append([a0 + i, a0 + j, b0 + j])
            faces.append([a0 + i, b0 + j, b0 + i])

    bottom_center = len(vertices)
    vertices.append([
        float(np.mean(footprints[0][:, 0])),
        float(heights[0]),
        float(np.mean(footprints[0][:, 1])),
    ])
    top_center = len(vertices)
    vertices.append([
        float(np.mean(footprints[-1][:, 0])),
        float(heights[-1]),
        float(np.mean(footprints[-1][:, 1])),
    ])

    for i in range(n):
        j = (i + 1) % n
        faces.append([bottom_center, j, i])
        top0 = (layers - 1) * n
        faces.append([top_center, top0 + i, top0 + j])

    return clean_mesh(trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=True))


def extrude_ring_profile_x(
    outer_yz: Sequence[Sequence[float]],
    inner_yz: Sequence[Sequence[float]],
    thickness: float,
) -> trimesh.Trimesh:
    outer = np.asarray(outer_yz, dtype=float)
    inner = np.asarray(inner_yz, dtype=float)
    if outer.shape != inner.shape or outer.ndim != 2 or outer.shape[1] != 2:
        raise ValueError('outer and inner profiles must be matching N x 2 arrays')
    n = len(outer)
    half = thickness * 0.5
    vertices = []
    for x, loop in ((-half, outer), (half, outer), (-half, inner), (half, inner)):
        vertices.extend([[x, y, z] for y, z in loop])

    faces: list[list[int]] = []
    o_back, o_front, i_back, i_front = 0, n, 2 * n, 3 * n
    for i in range(n):
        j = (i + 1) % n
        faces.extend([
            [o_back + i, o_back + j, o_front + j],
            [o_back + i, o_front + j, o_front + i],
            [i_back + i, i_front + j, i_back + j],
            [i_back + i, i_front + i, i_front + j],
            [o_front + i, o_front + j, i_front + j],
            [o_front + i, i_front + j, i_front + i],
            [o_back + i, i_back + j, o_back + j],
            [o_back + i, i_back + i, i_back + j],
        ])
    return clean_mesh(trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=True))


def radial_footprint(
    radius_x: float,
    radius_z: float,
    z_shift: float = 0.0,
    sectors: int = 14,
    front_taper: float = 0.08,
    rear_taper: float = 0.04,
) -> np.ndarray:
    points = []
    for theta in np.linspace(0.0, math.tau, sectors, endpoint=False):
        c = math.cos(theta)
        s = math.sin(theta)
        taper = 1.0 - front_taper * max(c, 0.0) - rear_taper * max(-c, 0.0)
        points.append([radius_x * s * taper, z_shift + radius_z * c])
    return np.asarray(points, dtype=float)


def tapered_cylinder_z(
    rear_radius: float,
    front_radius: float,
    length: float,
    center=(0.0, 0.0, 0.0),
    sections: int = 12,
) -> trimesh.Trimesh:
    cx, cy, cz = center
    z0 = cz - length * 0.5
    z1 = cz + length * 0.5
    vertices = []
    for z, radius in ((z0, rear_radius), (z1, front_radius)):
        for theta in np.linspace(0.0, math.tau, sections, endpoint=False):
            vertices.append([cx + radius * math.cos(theta), cy + radius * math.sin(theta), z])
    faces = []
    for i in range(sections):
        j = (i + 1) % sections
        faces.extend([[i, j, sections + j], [i, sections + j, sections + i]])
    rear_center = len(vertices)
    vertices.append([cx, cy, z0])
    front_center = len(vertices)
    vertices.append([cx, cy, z1])
    for i in range(sections):
        j = (i + 1) % sections
        faces.append([rear_center, j, i])
        faces.append([front_center, sections + i, sections + j])
    return clean_mesh(trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=True))


def build_hull() -> list[Piece]:
    lower_bottom = np.array([
        [-1.32, -2.72], [1.32, -2.72], [1.47, -2.30], [1.47, 1.88],
        [1.18, 2.55], [-1.18, 2.55], [-1.47, 1.88], [-1.47, -2.30],
    ])
    lower_top = np.array([
        [-1.42, -2.62], [1.42, -2.62], [1.54, -2.14], [1.54, 1.96],
        [1.20, 2.78], [-1.20, 2.78], [-1.54, 1.96], [-1.54, -2.14],
    ])
    lower_shell = layered_prism([lower_bottom, lower_top], [-0.72, -0.08])

    upper_base = np.array([
        [-1.32, -2.35], [1.32, -2.35], [1.36, -1.72], [1.36, 1.74],
        [1.08, 2.58], [-1.08, 2.58], [-1.36, 1.74], [-1.36, -1.72],
    ])
    upper_mid = np.array([
        [-1.18, -2.18], [1.18, -2.18], [1.24, -1.55], [1.16, 1.28],
        [0.84, 2.16], [-0.84, 2.16], [-1.16, 1.28], [-1.24, -1.55],
    ])
    upper_top = np.array([
        [-0.98, -1.72], [0.98, -1.72], [1.02, -1.25], [0.94, 0.86],
        [0.62, 1.54], [-0.62, 1.54], [-0.94, 0.86], [-1.02, -1.25],
    ])
    upper_shell = layered_prism([upper_base, upper_mid, upper_top], [-0.06, 0.32, 0.67])

    armor: list[trimesh.Trimesh] = [lower_shell, upper_shell]
    # Broad fenders and deliberately chunky applique panels create a readable RTS silhouette.
    for side in (-1, 1):
        armor.append(box((0.34, 0.13, 5.28), center=(side * 1.60, 0.48, -0.02)))
        for z, y, angle in ((2.25, 0.46, -18), (2.49, 0.31, -36), (2.66, 0.10, -55),
                            (-2.26, 0.46, 18), (-2.48, 0.32, 35), (-2.64, 0.12, 53)):
            armor.append(box((0.36, 0.11, 0.48), center=(side * 1.60, y, z), euler_deg=(angle, 0, 0)))
        # Three-part armored side skirt, leaving wheel detail visible below.
        for z in (-1.72, -0.42, 0.88):
            armor.append(box((0.12, 0.48, 1.06), center=(side * 1.72, 0.28, z), euler_deg=(0, 0, side * 2)))

    armor.extend([
        box((2.16, 0.20, 1.34), center=(0, 0.72, -1.63)),
        box((2.46, 0.16, 0.24), center=(0, 0.20, 2.65), euler_deg=(-17, 0, 0)),
        box((1.92, 0.12, 0.40), center=(0, 0.68, -0.74)),
        box((2.22, 0.13, 0.34), center=(0, 0.20, 2.30), euler_deg=(-21, 0, 0)),
    ])

    secondary: list[trimesh.Trimesh] = []
    # Engine deck louvers.
    for x in np.linspace(-0.82, 0.82, 6):
        secondary.append(box((0.24, 0.06, 0.94), center=(float(x), 0.84, -1.64)))
    secondary.extend([
        cylinder(0.13, 0.92, axis='z', center=(0.94, 0.82, -1.95), sections=10),
        cylinder(0.13, 0.92, axis='z', center=(-0.94, 0.82, -1.95), sections=10),
        box((1.52, 0.12, 0.16), center=(0, -0.53, -2.76)),
        box((0.58, 0.18, 0.32), center=(0, 0.10, 2.68), euler_deg=(-15, 0, 0)),
    ])
    # Tow hooks, handholds, and a boarding step on the right side.
    for side in (-1, 1):
        secondary.extend([
            cylinder_between((side * 0.76, -0.32, 2.66), (side * 0.76, -0.02, 2.66), 0.045, 8),
            cylinder_between((side * 0.76, -0.02, 2.66), (side * 0.98, 0.04, 2.52), 0.045, 8),
        ])
    secondary.extend([
        box((0.52, 0.10, 0.30), center=(1.82, -0.02, -0.82)),
        cylinder_between((1.69, 0.05, -0.96), (1.69, 0.66, -0.96), 0.035, 7),
        cylinder_between((1.69, 0.05, -0.64), (1.69, 0.66, -0.64), 0.035, 7),
        cylinder_between((1.69, 0.30, -0.96), (1.69, 0.30, -0.64), 0.035, 7),
        cylinder_between((1.69, 0.55, -0.96), (1.69, 0.55, -0.64), 0.035, 7),
    ])

    accent: list[trimesh.Trimesh] = [
        box((0.045, 0.20, 1.10), center=(-1.785, 0.36, 0.45)),
        box((0.045, 0.20, 1.10), center=(1.785, 0.36, 0.45)),
        box((1.10, 0.05, 0.16), center=(0, 0.76, 1.43)),
        box((0.32, 0.10, 0.16), center=(-0.66, 0.22, 2.64), euler_deg=(-15, 0, 0)),
        box((0.32, 0.10, 0.16), center=(0.66, 0.22, 2.64), euler_deg=(-15, 0, 0)),
    ]

    optic = [
        cylinder(0.14, 0.09, axis='z', center=(-0.76, 0.31, 2.61), sections=12),
        cylinder(0.14, 0.09, axis='z', center=(0.76, 0.31, 2.61), sections=12),
    ]

    return [
        Piece('Hull_Armor', merge(armor), 'Armor'),
        Piece('Hull_Secondary', merge(secondary), 'Secondary'),
        Piece('Hull_Accent', merge(accent), 'Accent'),
        Piece('Hull_Optics', merge(optic), 'Optic'),
    ]


def build_track(side: int) -> list[Piece]:
    if side not in (-1, 1):
        raise ValueError('side must be -1 or 1')

    outer = [
        (-0.66, -2.42), (-0.66, 2.20), (-0.54, 2.54), (-0.28, 2.72),
        (0.10, 2.76), (0.46, 2.56), (0.66, 2.00), (0.68, -2.00),
        (0.54, -2.45), (0.25, -2.70), (-0.22, -2.68), (-0.52, -2.50),
    ]
    inner = [
        (-0.45, -2.15), (-0.45, 1.94), (-0.35, 2.26), (-0.13, 2.43),
        (0.11, 2.44), (0.34, 2.27), (0.48, 1.78), (0.49, -1.77),
        (0.37, -2.15), (0.14, -2.39), (-0.10, -2.38), (-0.36, -2.23),
    ]
    track_meshes: list[trimesh.Trimesh] = [extrude_ring_profile_x(outer, inner, thickness=0.54)]

    for z in np.linspace(-2.18, 2.02, 18):
        track_meshes.append(box((0.63, 0.10, 0.20), center=(0, -0.71, float(z))))
    for z in np.linspace(-1.76, 1.78, 15):
        track_meshes.append(box((0.63, 0.09, 0.20), center=(0, 0.72, float(z))))
    front_arc = [
        (2.30, -0.57, -12), (2.49, -0.43, -27), (2.64, -0.20, -45),
        (2.67, 0.08, -63), (2.57, 0.36, -78), (2.38, 0.58, -88),
    ]
    rear_arc = [
        (-2.31, -0.57, 12), (-2.50, -0.42, 27), (-2.63, -0.18, 45),
        (-2.61, 0.10, 63), (-2.50, 0.38, 78), (-2.32, 0.59, 88),
    ]
    for z, y, angle in front_arc + rear_arc:
        track_meshes.append(box((0.63, 0.10, 0.21), center=(0, y, z), euler_deg=(angle, 0, 0)))

    tire_meshes: list[trimesh.Trimesh] = []
    wheel_meshes: list[trimesh.Trimesh] = []
    hub_meshes: list[trimesh.Trimesh] = []
    outward = side * 0.13
    hub_outward = side * 0.30

    for z in (-1.88, -1.13, -0.38, 0.38, 1.13, 1.88):
        tire_meshes.append(cylinder(0.42, 0.43, axis='x', center=(outward, -0.11, z), sections=14))
        wheel_meshes.append(cylinder(0.325, 0.47, axis='x', center=(outward + side * 0.025, -0.11, z), sections=14))
        hub_meshes.append(cylinder(0.105, 0.52, axis='x', center=(hub_outward, -0.11, z), sections=12))

    for z, y, radius in ((-2.38, -0.01, 0.37), (2.40, 0.00, 0.38)):
        tire_meshes.append(cylinder(radius, 0.41, axis='x', center=(outward, y, z), sections=14))
        wheel_meshes.append(cylinder(radius * 0.72, 0.46, axis='x', center=(outward + side * 0.025, y, z), sections=12))
        hub_meshes.append(cylinder(0.10, 0.51, axis='x', center=(hub_outward, y, z), sections=10))

    for z in (-1.47, -0.66, 0.16, 0.98, 1.70):
        tire_meshes.append(cylinder(0.15, 0.35, axis='x', center=(outward, 0.50, z), sections=10))

    name = 'LeftTrack' if side < 0 else 'RightTrack'
    return [
        Piece(f'{name}_Band', merge(track_meshes), 'Track'),
        Piece(f'{name}_Tires', merge(tire_meshes), 'Track'),
        Piece(f'{name}_Wheels', merge(wheel_meshes), 'Secondary'),
        Piece(f'{name}_Hubs', merge(hub_meshes), 'Accent'),
    ]


def build_turret() -> list[Piece]:
    footprints = [
        radial_footprint(1.12, 0.95, z_shift=-0.06, sectors=14, front_taper=0.10),
        radial_footprint(1.38, 1.16, z_shift=-0.08, sectors=14, front_taper=0.08),
        radial_footprint(1.44, 1.19, z_shift=-0.10, sectors=14, front_taper=0.07),
        radial_footprint(1.21, 0.98, z_shift=-0.13, sectors=14, front_taper=0.05),
        radial_footprint(0.88, 0.67, z_shift=-0.17, sectors=14, front_taper=0.04),
    ]
    shell = layered_prism(footprints, [-0.30, -0.12, 0.12, 0.46, 0.64])

    armor: list[trimesh.Trimesh] = [
        shell,
        ellipsoid((1.52, 0.80, 0.72), center=(0, 0.02, 1.02), subdivisions=1),
        box((1.70, 0.30, 0.44), center=(0, 0.10, -1.10)),
        box((0.34, 0.36, 0.94), center=(-1.28, 0.10, -0.05), euler_deg=(0, 0, -7)),
        box((0.34, 0.36, 0.94), center=(1.28, 0.10, -0.05), euler_deg=(0, 0, 7)),
        cylinder(0.33, 0.14, axis='y', center=(-0.38, 0.69, -0.18), sections=14),
        cylinder(0.31, 0.07, axis='y', center=(-0.38, 0.79, -0.18), sections=14),
    ]

    # Gunner platform on the rear-right turret roof.
    armor.extend([
        box((1.08, 0.11, 1.10), center=(0.78, 0.65, -0.78)),
        box((0.14, 0.32, 0.94), center=(1.30, 0.45, -0.80)),
        box((0.96, 0.18, 0.18), center=(0.78, 0.47, -1.24)),
    ])

    secondary: list[trimesh.Trimesh] = [
        cylinder(0.35, 0.32, axis='z', center=(0, 0.02, 1.25), sections=14),
        cylinder(0.13, 1.28, axis='x', center=(0, 0.36, -1.16), sections=12),
        cylinder(0.15, 0.05, axis='x', center=(-0.42, 0.36, -1.16), sections=12),
        cylinder(0.15, 0.05, axis='x', center=(0.42, 0.36, -1.16), sections=12),
        cylinder(0.025, 0.88, axis='y', center=(-0.91, 0.90, -0.58), sections=6),
        box((0.24, 0.16, 0.20), center=(-0.10, 0.81, 0.00)),
    ]

    # Non-slip grate slats.
    for z in np.linspace(-1.15, -0.40, 5):
        secondary.append(box((0.90, 0.035, 0.07), center=(0.78, 0.72, float(z))))

    # Safety rail: rear and right side, front left open for entry/use.
    posts = [
        ((0.30, 0.70, -1.25), (0.30, 1.36, -1.25)),
        ((1.26, 0.70, -1.25), (1.26, 1.36, -1.25)),
        ((1.26, 0.70, -0.36), (1.26, 1.36, -0.36)),
    ]
    for p0, p1 in posts:
        secondary.append(cylinder_between(p0, p1, 0.035, 7))
    for y in (1.08, 1.36):
        secondary.extend([
            cylinder_between((0.30, y, -1.25), (1.26, y, -1.25), 0.035, 7),
            cylinder_between((1.26, y, -1.25), (1.26, y, -0.36), 0.035, 7),
        ])

    # Turret-side ladder rungs leading to the platform.
    for y in (0.05, 0.28, 0.51):
        secondary.append(cylinder_between((1.48, y, -1.08), (1.48, y, -0.62), 0.035, 7))
    secondary.extend([
        cylinder_between((1.48, 0.02, -1.08), (1.48, 0.57, -1.08), 0.035, 7),
        cylinder_between((1.48, 0.02, -0.62), (1.48, 0.57, -0.62), 0.035, 7),
    ])

    # Smoke launchers and sensor blocks.
    for side in (-1, 1):
        for i, z in enumerate((0.10, 0.34, 0.58)):
            launcher = cylinder(0.075, 0.30, axis='z', center=(side * (1.08 + 0.04 * i), 0.10 + 0.05 * i, z), sections=8)
            secondary.append(transformed(launcher, euler_deg=(-10, side * 10, 0)))

    accent = [
        box((0.045, 0.25, 0.72), center=(-1.46, 0.08, -0.12)),
        box((0.045, 0.25, 0.72), center=(1.46, 0.08, -0.12)),
        box((0.72, 0.05, 0.10), center=(0.78, 0.75, -1.18)),
        box((0.42, 0.035, 0.07), center=(-0.38, 0.84, -0.18)),
    ]

    optic = [
        cylinder(0.18, 0.08, axis='z', center=(0.68, 0.18, 1.28), sections=12),
        box((0.18, 0.11, 0.06), center=(-0.10, 0.84, 0.12)),
        box((0.16, 0.10, 0.06), center=(-0.54, 0.76, 0.20)),
    ]

    return [
        Piece('Turret_Armor', merge(armor), 'Armor'),
        Piece('Turret_Secondary', merge(secondary), 'Secondary'),
        Piece('Turret_Accent', merge(accent), 'Accent'),
        Piece('Turret_Optics', merge(optic), 'Optic'),
    ]


def build_cannon() -> list[Piece]:
    armor = [
        cylinder(0.27, 0.44, axis='z', center=(0, 0, 0.24), sections=14),
        tapered_cylinder_z(0.20, 0.145, 0.92, center=(0, 0, 0.90), sections=14),
        cylinder(0.142, 2.92, axis='z', center=(0, 0, 2.75), sections=14),
        cylinder(0.19, 0.40, axis='z', center=(0, 0, 1.46), sections=14),
    ]
    weapon = [
        cylinder(0.21, 0.40, axis='z', center=(0, 0, 4.40), sections=12),
        box((0.50, 0.18, 0.34), center=(0, 0, 4.42)),
        box((0.18, 0.50, 0.34), center=(0, 0, 4.42)),
        cylinder(0.095, 0.08, axis='z', center=(0, 0, 4.66), sections=12),
    ]
    accent = [box((0.30, 0.04, 0.30), center=(0, 0.19, 1.48))]
    return [
        Piece('Cannon_Armor', merge(armor), 'Armor'),
        Piece('Cannon_MuzzleBrake', merge(weapon), 'Weapon'),
        Piece('Cannon_Accent', merge(accent), 'Accent'),
    ]


def build_minigun_base() -> list[Piece]:
    secondary = [
        cylinder(0.19, 0.32, axis='y', center=(0, 0.16, 0), sections=12),
        cylinder(0.13, 0.52, axis='y', center=(0, 0.50, 0), sections=10),
        box((0.56, 0.12, 0.34), center=(0, 0.78, 0.10)),
        box((0.12, 0.34, 0.26), center=(-0.23, 0.77, 0.13)),
        box((0.12, 0.34, 0.26), center=(0.23, 0.77, 0.13)),
    ]
    weapon = [
        box((0.38, 0.44, 0.40), center=(0.42, 0.55, -0.05)),
        box((0.10, 0.30, 0.26), center=(0.20, 0.66, 0.03)),
    ]
    accent = [box((0.34, 0.045, 0.13), center=(0.42, 0.79, -0.05))]
    return [
        Piece('MinigunBase_Secondary', merge(secondary), 'Secondary'),
        Piece('MinigunBase_Weapon', merge(weapon), 'Weapon'),
        Piece('MinigunBase_Accent', merge(accent), 'Accent'),
    ]


def build_minigun_body() -> list[Piece]:
    weapon = [
        box((0.46, 0.34, 0.70), center=(0, 0.00, 0.17)),
        cylinder(0.16, 0.34, axis='z', center=(0, 0.00, 0.55), sections=10),
        box((0.52, 0.12, 0.18), center=(0, 0.10, -0.25)),
        cylinder_between((-0.20, 0.03, -0.30), (-0.20, 0.03, -0.52), 0.035, 8),
        cylinder_between((0.20, 0.03, -0.30), (0.20, 0.03, -0.52), 0.035, 8),
        cylinder_between((-0.20, 0.03, -0.52), (0.20, 0.03, -0.52), 0.035, 8),
        cylinder_between((-0.20, -0.08, -0.52), (-0.20, 0.14, -0.52), 0.045, 8),
        cylinder_between((0.20, -0.08, -0.52), (0.20, 0.14, -0.52), 0.045, 8),
    ]
    secondary = [
        box((0.16, 0.24, 0.28), center=(0.31, -0.02, 0.06)),
        box((0.12, 0.20, 0.22), center=(0.33, 0.00, 0.31)),
    ]
    optic = [box((0.10, 0.10, 0.14), center=(-0.22, 0.22, 0.24))]
    return [
        Piece('MinigunBody_Weapon', merge(weapon), 'Weapon'),
        Piece('MinigunBody_Secondary', merge(secondary), 'Secondary'),
        Piece('MinigunBody_Optic', merge(optic), 'Optic'),
    ]


def build_minigun_barrels() -> list[Piece]:
    weapon: list[trimesh.Trimesh] = []
    barrel_radius = 0.095
    for i in range(6):
        angle = math.tau * i / 6.0
        x = barrel_radius * math.cos(angle)
        y = barrel_radius * math.sin(angle)
        weapon.append(cylinder(0.032, 1.38, axis='z', center=(x, y, 1.14), sections=8))
    weapon.extend([
        cylinder(0.18, 0.09, axis='z', center=(0, 0, 0.55), sections=12),
        cylinder(0.18, 0.09, axis='z', center=(0, 0, 1.70), sections=12),
        cylinder(0.07, 1.28, axis='z', center=(0, 0, 1.12), sections=10),
    ])
    secondary = [cylinder(0.20, 0.08, axis='z', center=(0, 0, 1.78), sections=12)]
    accent = [cylinder(0.205, 0.035, axis='z', center=(0, 0, 0.50), sections=12)]
    return [
        Piece('MinigunBarrels_Weapon', merge(weapon), 'Weapon'),
        Piece('MinigunBarrels_Muzzle', merge(secondary), 'Secondary'),
        Piece('MinigunBarrels_Accent', merge(accent), 'Accent'),
    ]


def build_gunner_reference() -> list[Piece]:
    # Non-rigged 1.80 m scale guide, authored around feet at origin and facing +Z.
    crew: list[trimesh.Trimesh] = [
        box((0.46, 0.62, 0.28), center=(0, 1.16, 0.00), euler_deg=(4, 0, 0)),
        cylinder(0.16, 0.30, axis='y', center=(0, 1.66, 0.02), sections=10),
        box((0.40, 0.20, 0.30), center=(0, 0.83, 0.00)),
    ]
    # Legs.
    crew.extend([
        cylinder_between((-0.13, 0.82, 0.00), (-0.16, 0.08, -0.02), 0.105, 8),
        cylinder_between((0.13, 0.82, 0.00), (0.16, 0.08, -0.02), 0.105, 8),
        box((0.23, 0.10, 0.40), center=(-0.16, 0.06, 0.12)),
        box((0.23, 0.10, 0.40), center=(0.16, 0.06, 0.12)),
    ])
    # Arms reaching the twin handles.
    crew.extend([
        cylinder_between((-0.22, 1.43, 0.02), (-0.18, 1.10, 0.34), 0.085, 8),
        cylinder_between((0.22, 1.43, 0.02), (0.18, 1.10, 0.34), 0.085, 8),
        cylinder(0.095, 0.13, axis='z', center=(-0.18, 1.10, 0.37), sections=8),
        cylinder(0.095, 0.13, axis='z', center=(0.18, 1.10, 0.37), sections=8),
    ])
    secondary = [
        box((0.50, 0.06, 0.34), center=(0, 1.32, -0.17)),
        box((0.30, 0.16, 0.26), center=(0, 1.70, -0.02)),
    ]
    return [
        Piece('GunnerReference_Crew', merge(crew), 'Crew'),
        Piece('GunnerReference_Gear', merge(secondary), 'Secondary'),
    ]


def build_lod1_local() -> dict[str, list[Piece]]:
    hull_base = np.array([
        [-1.40, -2.62], [1.40, -2.62], [1.54, -2.08], [1.54, 1.90],
        [1.18, 2.70], [-1.18, 2.70], [-1.54, 1.90], [-1.54, -2.08],
    ])
    hull_top = np.array([
        [-0.98, -1.76], [0.98, -1.76], [1.06, -1.20], [0.94, 0.86],
        [0.62, 1.56], [-0.62, 1.56], [-0.94, 0.86], [-1.06, -1.20],
    ])
    hull = [
        Piece('Hull_LOD1_Armor', layered_prism([hull_base, hull_top], [-0.66, 0.66]), 'Armor'),
        Piece('Hull_LOD1_Accent', box((1.28, 0.05, 0.18), center=(0, 0.69, 1.46)), 'Accent'),
    ]
    left = [Piece('LeftTrack_LOD1', box((0.56, 1.35, 5.35), center=(0, 0.00, 0)), 'Track')]
    right = [Piece('RightTrack_LOD1', box((0.56, 1.35, 5.35), center=(0, 0.00, 0)), 'Track')]

    turret_shell = layered_prism([
        radial_footprint(1.32, 1.10, z_shift=-0.08, sectors=10),
        radial_footprint(0.88, 0.67, z_shift=-0.16, sectors=10),
    ], [-0.28, 0.62])
    turret = [
        Piece('Turret_LOD1_Armor', merge([
            turret_shell,
            ellipsoid((1.36, 0.62, 0.62), center=(0, 0.02, 1.00), subdivisions=1),
            box((1.02, 0.10, 1.04), center=(0.78, 0.64, -0.78)),
        ]), 'Armor'),
        Piece('Turret_LOD1_Accent', box((0.62, 0.05, 0.10), center=(0.78, 0.72, -1.17)), 'Accent'),
    ]
    cannon = [
        Piece('Cannon_LOD1', merge([
            cylinder(0.22, 0.42, axis='z', center=(0, 0, 0.24), sections=8),
            tapered_cylinder_z(0.17, 0.12, 4.30, center=(0, 0, 2.40), sections=8),
            box((0.38, 0.16, 0.34), center=(0, 0, 4.58)),
        ]), 'Armor')
    ]
    minigun_base = [
        Piece('MinigunBase_LOD1', merge([
            cylinder(0.15, 0.72, axis='y', center=(0, 0.38, 0), sections=8),
            box((0.50, 0.28, 0.44), center=(0, 0.78, 0.12)),
        ]), 'Secondary')
    ]
    minigun_body = [Piece('MinigunBody_LOD1', box((0.42, 0.30, 0.70), center=(0, 0, 0.18)), 'Weapon')]
    minigun_barrels = [Piece('MinigunBarrels_LOD1', cylinder(0.14, 1.45, axis='z', center=(0, 0, 1.18), sections=8), 'Weapon')]
    return {
        'Hull': hull,
        'LeftTrack': left,
        'RightTrack': right,
        'Turret': turret,
        'Cannon': cannon,
        'MinigunBase': minigun_base,
        'MinigunBody': minigun_body,
        'MinigunBarrels': minigun_barrels,
    }


def palette_uv(name: str) -> tuple[float, float]:
    index = PALETTE_ORDER.index(name)
    return ((index + 0.5) / len(PALETTE_ORDER), 0.5)


def write_obj(path: Path, object_name: str, pieces: Sequence[Piece], mtl_reference=MTL_NAME) -> None:
    lines = [
        f'# {ASSET_NAME} — generated original low-poly asset',
        '# Coordinates: meters, +Y up, +Z forward',
        f'mtllib {mtl_reference}',
        f'o {object_name}',
        f'g {object_name}',
        'usemtl BastionPalette',
        's off',
    ]
    for palette_name in PALETTE_ORDER:
        u, v = palette_uv(palette_name)
        lines.append(f'vt {u:.8f} {v:.8f}')

    vertex_offset = 1
    normal_offset = 1
    face_records: list[tuple[np.ndarray, int, int]] = []
    for piece in pieces:
        mesh = clean_mesh(piece.mesh)
        lines.append(f'# piece {piece.name} palette={piece.palette}')
        for vertex in mesh.vertices:
            lines.append(f'v {vertex[0]:.8f} {vertex[1]:.8f} {vertex[2]:.8f}')
        for face_index, face in enumerate(mesh.faces):
            face_records.append((face + vertex_offset, PALETTE_ORDER.index(piece.palette) + 1, normal_offset))
            normal = mesh.face_normals[face_index]
            lines.append(f'vn {normal[0]:.8f} {normal[1]:.8f} {normal[2]:.8f}')
            normal_offset += 1
        vertex_offset += len(mesh.vertices)

    for face, uv_idx, normal_idx in face_records:
        a, b, c = [int(i) for i in face]
        lines.append(f'f {a}/{uv_idx}/{normal_idx} {b}/{uv_idx}/{normal_idx} {c}/{uv_idx}/{normal_idx}')

    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')


def write_mtl(path: Path) -> None:
    path.write_text(textwrap.dedent('''\
        # Single palette material. The Unity builder replaces this with a URP/Built-in compatible material.
        newmtl BastionPalette
        Ka 0.120000 0.120000 0.120000
        Kd 1.000000 1.000000 1.000000
        Ks 0.120000 0.120000 0.120000
        Ns 32.000000
        d 1.000000
        illum 2
        map_Kd ../Textures/Bastion_MT12_Palette.png
    '''), encoding='utf-8')


def create_textures() -> tuple[Image.Image, Image.Image]:
    width = SWATCH_WIDTH * len(PALETTE_ORDER)
    base = Image.new('RGBA', (width, TEXTURE_HEIGHT), (255, 255, 255, 255))
    emission = Image.new('RGBA', (width, TEXTURE_HEIGHT), (0, 0, 0, 255))
    draw = ImageDraw.Draw(base)
    emit_draw = ImageDraw.Draw(emission)
    for i, name in enumerate(PALETTE_ORDER):
        x0 = i * SWATCH_WIDTH
        x1 = (i + 1) * SWATCH_WIDTH - 1
        draw.rectangle((x0, 0, x1, TEXTURE_HEIGHT - 1), fill=PALETTE[name])
        if name == 'Optic':
            emit_draw.rectangle((x0, 0, x1, TEXTURE_HEIGHT - 1), fill=(80, 225, 255, 255))
    base.save(TEXTURE_DIR / 'Bastion_MT12_Palette.png', optimize=True)
    emission.save(TEXTURE_DIR / 'Bastion_MT12_Emission.png', optimize=True)
    return base, emission


def flatten_for_glb(pieces: Sequence[Piece], image: Image.Image) -> trimesh.Trimesh:
    vertices: list[np.ndarray] = []
    faces: list[list[int]] = []
    uvs: list[list[float]] = []
    cursor = 0
    for piece in pieces:
        mesh = clean_mesh(piece.mesh)
        uv = palette_uv(piece.palette)
        for face in mesh.faces:
            tri = mesh.vertices[face]
            vertices.extend(tri)
            uvs.extend([uv, uv, uv])
            faces.append([cursor, cursor + 1, cursor + 2])
            cursor += 3
    flat = trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=False)
    material = trimesh.visual.material.SimpleMaterial(image=image, name='BastionPalette')
    flat.visual = trimesh.visual.texture.TextureVisuals(uv=np.asarray(uvs), image=image, material=material)
    return flat


def export_glb(path: Path, nodes: Sequence[tuple[str, list[Piece], tuple[float, float, float], str | None]], image: Image.Image) -> None:
    scene = trimesh.Scene()
    scene.graph.update(frame_to='TankRoot', frame_from='world', matrix=np.eye(4))
    for node_name, pieces, translation, parent in nodes:
        mesh = flatten_for_glb(pieces, image)
        scene.add_geometry(
            mesh,
            node_name=node_name,
            geom_name=f'{node_name}_Mesh',
            parent_node_name=parent or 'TankRoot',
            transform=translation_matrix(translation),
        )
    path.write_bytes(scene.export(file_type='glb'))


def transform_pieces(pieces: Sequence[Piece], translation=(0.0, 0.0, 0.0), euler_deg=(0.0, 0.0, 0.0), prefix='') -> list[Piece]:
    return [
        Piece(prefix + piece.name, transformed(piece.mesh, translation=translation, euler_deg=euler_deg), piece.palette)
        for piece in pieces
    ]


PIVOTS = {
    'Hull': (0.0, 1.06, 0.0),
    'LeftTrack': (-1.58, 0.74, 0.0),
    'RightTrack': (1.58, 0.74, 0.0),
    'TurretYaw': (0.0, 1.82, -0.08),
    'CannonPitch_local': (0.0, 0.16, 1.00),
    'GunnerStation_local': (0.78, 0.64, -0.78),
    'GunnerYaw_local': (0.0, 0.18, 0.60),
    'MinigunPitch_local': (0.0, 0.88, 0.14),
}


def combine_all(parts: dict[str, list[Piece]]) -> list[Piece]:
    world: list[Piece] = []
    world.extend(transform_pieces(parts['Hull'], translation=PIVOTS['Hull'], prefix='Static_'))
    world.extend(transform_pieces(parts['LeftTrack'], translation=PIVOTS['LeftTrack'], prefix='Static_'))
    world.extend(transform_pieces(parts['RightTrack'], translation=PIVOTS['RightTrack'], prefix='Static_'))
    turret_world = np.asarray(PIVOTS['TurretYaw'])
    world.extend(transform_pieces(parts['Turret'], translation=turret_world, prefix='Static_'))
    cannon_world = turret_world + np.asarray(PIVOTS['CannonPitch_local'])
    world.extend(transform_pieces(parts['Cannon'], translation=cannon_world, prefix='Static_'))
    station_world = turret_world + np.asarray(PIVOTS['GunnerStation_local'])
    yaw_world = station_world + np.asarray(PIVOTS['GunnerYaw_local'])
    world.extend(transform_pieces(parts['MinigunBase'], translation=yaw_world, prefix='Static_'))
    pitch_world = yaw_world + np.asarray(PIVOTS['MinigunPitch_local'])
    world.extend(transform_pieces(parts['MinigunBody'], translation=pitch_world, prefix='Static_'))
    world.extend(transform_pieces(parts['MinigunBarrels'], translation=pitch_world, prefix='Static_'))
    return world


def station_anchor_world() -> np.ndarray:
    return np.asarray(PIVOTS['TurretYaw']) + np.asarray(PIVOTS['GunnerStation_local'])


def render_preview(pieces: Sequence[Piece], path: Path, view: str = 'perspective') -> None:
    scale_factor = 2
    width, height = 1600 * scale_factor, 900 * scale_factor

    top = np.array([225, 231, 231], dtype=float)
    bottom = np.array([245, 242, 233], dtype=float)
    gradient = np.linspace(top, bottom, height, dtype=np.uint8)[:, None, :]
    background = np.repeat(gradient, width, axis=1)
    image = Image.fromarray(background, mode='RGB')

    draw = ImageDraw.Draw(image, 'RGBA')
    if view == 'top':
        eye = np.array([0.01, 11.0, 0.01])
        target = np.array([0.0, 1.0, 0.35])
        camera_up = np.array([0.0, 0.0, 1.0])
        viewport = (150, 95, 1450, 820)
        label = 'TOP VIEW'
    elif view == 'side':
        eye = np.array([10.0, 3.0, 0.0])
        target = np.array([0.0, 1.45, 0.45])
        camera_up = np.array([0.0, 1.0, 0.0])
        viewport = (110, 105, 1490, 820)
        label = 'SIDE VIEW'
    elif view == 'gunner':
        eye = np.array([4.4, 4.2, -4.0])
        target = np.array([0.78, 2.80, -0.20])
        camera_up = np.array([0.0, 1.0, 0.0])
        viewport = (400, 80, 1530, 835)
        label = 'GUNNER STATION DETAIL'
    else:
        eye = np.array([7.2, 4.6, 8.2])
        target = np.array([0.0, 1.35, 0.55])
        camera_up = np.array([0.0, 1.0, 0.0])
        viewport = (430, 85, 1535, 835)
        label = 'MEDIUM TANK + MANNED ROTARY GUN'

    forward = target - eye
    forward /= np.linalg.norm(forward)
    right = np.cross(forward, camera_up)
    right /= np.linalg.norm(right)
    up = np.cross(right, forward)
    up /= np.linalg.norm(up)

    all_vertices = np.vstack([p.mesh.vertices for p in pieces])
    rel = all_vertices - eye[None, :]
    cam_x = rel @ right
    cam_y = rel @ up
    cam_z = rel @ forward
    perspective = view in ('perspective', 'gunner')
    if perspective:
        px = cam_x / np.maximum(cam_z, 1e-4)
        py = cam_y / np.maximum(cam_z, 1e-4)
    else:
        px, py = cam_x, cam_y

    vx0, vy0, vx1, vy1 = [v * scale_factor for v in viewport]
    margin = 20 * scale_factor
    span_x = max(float(px.max() - px.min()), 1e-6)
    span_y = max(float(py.max() - py.min()), 1e-6)
    fit_scale = min((vx1 - vx0 - 2 * margin) / span_x, (vy1 - vy0 - 2 * margin) / span_y)
    center_px = float((px.min() + px.max()) * 0.5)
    center_py = float((py.min() + py.max()) * 0.5)
    center_screen_x = (vx0 + vx1) * 0.5
    center_screen_y = (vy0 + vy1) * 0.5

    if perspective:
        shadow_box = (490 * scale_factor, 660 * scale_factor, 1510 * scale_factor, 860 * scale_factor)
        shadow = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow, 'RGBA')
        shadow_draw.ellipse(shadow_box, fill=(20, 26, 25, 55))
        shadow = shadow.filter(ImageFilter.GaussianBlur(24 * scale_factor))
        image = Image.alpha_composite(image.convert('RGBA'), shadow).convert('RGB')
        draw = ImageDraw.Draw(image, 'RGBA')

    light = np.array([-0.45, 0.82, 0.55], dtype=float)
    light /= np.linalg.norm(light)
    camera_dir = -forward
    triangles = []
    for piece in pieces:
        mesh = clean_mesh(piece.mesh)
        base = np.array(PALETTE[piece.palette][:3], dtype=float)
        rel_piece = mesh.vertices - eye[None, :]
        cx = rel_piece @ right
        cy = rel_piece @ up
        cz = rel_piece @ forward
        if perspective:
            qx = cx / np.maximum(cz, 1e-4)
            qy = cy / np.maximum(cz, 1e-4)
        else:
            qx, qy = cx, cy
        sx = center_screen_x + (qx - center_px) * fit_scale
        sy = center_screen_y - (qy - center_py) * fit_scale
        projected = np.column_stack([sx, sy])
        for face_idx, face in enumerate(mesh.faces):
            depth = float(np.mean(cz[face]))
            normal = mesh.face_normals[face_idx]
            diffuse = max(0.0, float(np.dot(normal, light)))
            rim = (1.0 - abs(float(np.dot(normal, camera_dir)))) ** 2
            intensity = np.clip(0.42 + 0.51 * diffuse + 0.09 * rim, 0.27, 1.08)
            rgb = tuple(np.clip(base * intensity, 0, 255).astype(np.uint8))
            points = [tuple(projected[i]) for i in face]
            triangles.append((depth, points, rgb))

    triangles.sort(key=lambda item: item[0], reverse=True)
    for _, points, rgb in triangles:
        draw.polygon(points, fill=(*rgb, 255))
        draw.line(points + [points[0]], fill=(24, 27, 26, 70), width=max(1, scale_factor))

    title_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 54 * scale_factor)
    sub_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 24 * scale_factor)
    label_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 19 * scale_factor)
    spec_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 20 * scale_factor)

    if view == 'perspective':
        draw.text((58 * scale_factor, 68 * scale_factor), 'BASTION MT-12 RIDER', font=title_font, fill=(23, 28, 27, 255))
        draw.text((61 * scale_factor, 140 * scale_factor), 'Unity / Meta Quest low-poly RTS medium tank', font=sub_font, fill=(66, 72, 69, 255))
        draw.rounded_rectangle((61 * scale_factor, 202 * scale_factor, 505 * scale_factor, 244 * scale_factor),
                               radius=12 * scale_factor, fill=(74, 66, 51, 225))
        draw.text((78 * scale_factor, 209 * scale_factor), label, font=label_font, fill=(243, 235, 215, 255))
        specs = [
            'Six-wheel medium-tank chassis',
            'Articulated main turret and cannon',
            'Boardable rear-right gunner platform',
            'Independent minigun yaw, pitch, and barrel spin',
            'Soldier snap + hand/foot IK anchors',
            'One shared palette material + LOD',
        ]
        y = 286 * scale_factor
        for spec in specs:
            draw.ellipse((66 * scale_factor, y + 8 * scale_factor, 76 * scale_factor, y + 18 * scale_factor), fill=(181, 71, 40, 255))
            draw.text((91 * scale_factor, y), spec, font=spec_font, fill=(55, 61, 58, 255))
            y += 45 * scale_factor
        draw.text((61 * scale_factor, 817 * scale_factor),
                  'Original RTS design • gunner reference mesh included as an optional scale guide',
                  font=spec_font, fill=(76, 80, 76, 235))
    elif view == 'gunner':
        draw.text((58 * scale_factor, 48 * scale_factor), 'BASTION MT-12 — GUNNER STATION', font=sub_font, fill=(33, 39, 37, 255))
        draw.rounded_rectangle((60 * scale_factor, 98 * scale_factor, 420 * scale_factor, 142 * scale_factor),
                               radius=10 * scale_factor, fill=(74, 66, 51, 225))
        draw.text((77 * scale_factor, 106 * scale_factor), 'SCALE DUMMY SHOWN', font=label_font, fill=(243, 235, 215, 255))
        details = [
            'Rear/right access ladder',
            'Standing deck and safety rail',
            'Twin hand grips',
            'Independent rotary gun mount',
            'Muzzle + occupant anchor hierarchy',
        ]
        y = 188 * scale_factor
        for detail in details:
            draw.text((67 * scale_factor, y), '• ' + detail, font=spec_font, fill=(55, 61, 58, 255))
            y += 45 * scale_factor
    else:
        draw.text((58 * scale_factor, 48 * scale_factor), f'BASTION MT-12 RIDER — {label}', font=sub_font, fill=(33, 39, 37, 255))

    image = image.resize((1600, 900), Image.Resampling.LANCZOS)
    image.save(path, optimize=True)


def write_controller_script() -> None:
    code = r'''using UnityEngine;

namespace BastionMediumTank
{
    [DisallowMultipleComponent]
    public sealed class BastionMT12Controller : MonoBehaviour
    {
        [Header("Main weapon articulation")]
        [SerializeField] private Transform turretYaw;
        [SerializeField] private Transform cannonPitch;
        [SerializeField] private Transform mainMuzzle;

        [Header("Traverse")]
        [SerializeField, Min(0f)] private float turretSpeedDegrees = 82f;
        [SerializeField, Min(0f)] private float cannonSpeedDegrees = 58f;
        [SerializeField] private float minimumElevation = -7f;
        [SerializeField] private float maximumElevation = 28f;

        private bool hasAimPoint;
        private Vector3 aimPoint;

        public Transform TurretYaw => turretYaw;
        public Transform CannonPitch => cannonPitch;
        public Transform MainMuzzle => mainMuzzle;

        private void Reset()
        {
            ResolveTransforms();
        }

        private void Awake()
        {
            ResolveTransforms();
        }

        private void LateUpdate()
        {
            if (hasAimPoint)
            {
                ApplyAim(aimPoint, Time.deltaTime, false);
            }
        }

        public void SetAimPoint(Vector3 worldPoint)
        {
            aimPoint = worldPoint;
            hasAimPoint = true;
        }

        public void ClearAimPoint()
        {
            hasAimPoint = false;
        }

        public void SnapAimAt(Vector3 worldPoint)
        {
            if (ResolveTransforms())
            {
                ApplyAim(worldPoint, 0f, true);
            }
        }

        private void ApplyAim(Vector3 worldPoint, float deltaTime, bool snap)
        {
            Vector3 yawLocalDirection = turretYaw.parent.InverseTransformDirection(worldPoint - turretYaw.position);
            yawLocalDirection.y = 0f;
            if (yawLocalDirection.sqrMagnitude > 0.0001f)
            {
                float targetYaw = Mathf.Atan2(yawLocalDirection.x, yawLocalDirection.z) * Mathf.Rad2Deg;
                float currentYaw = NormalizeAngle(turretYaw.localEulerAngles.y);
                float nextYaw = snap
                    ? targetYaw
                    : Mathf.MoveTowardsAngle(currentYaw, targetYaw, turretSpeedDegrees * deltaTime);
                turretYaw.localRotation = Quaternion.Euler(0f, nextYaw, 0f);
            }

            Vector3 pitchLocalDirection = turretYaw.InverseTransformDirection(worldPoint - cannonPitch.position);
            float elevation = Mathf.Atan2(pitchLocalDirection.y, Mathf.Max(0.0001f, pitchLocalDirection.z)) * Mathf.Rad2Deg;
            elevation = Mathf.Clamp(elevation, minimumElevation, maximumElevation);
            float targetPitch = -elevation;
            float currentPitch = NormalizeAngle(cannonPitch.localEulerAngles.x);
            float nextPitch = snap
                ? targetPitch
                : Mathf.MoveTowardsAngle(currentPitch, targetPitch, cannonSpeedDegrees * deltaTime);
            cannonPitch.localRotation = Quaternion.Euler(nextPitch, 0f, 0f);
        }

        private bool ResolveTransforms()
        {
            if (turretYaw == null)
            {
                turretYaw = transform.Find("TurretYaw");
            }
            if (cannonPitch == null && turretYaw != null)
            {
                cannonPitch = turretYaw.Find("CannonPitch");
            }
            if (mainMuzzle == null && cannonPitch != null)
            {
                mainMuzzle = cannonPitch.Find("MainMuzzle");
            }
            return turretYaw != null && cannonPitch != null;
        }

        private static float NormalizeAngle(float angle)
        {
            return angle > 180f ? angle - 360f : angle;
        }
    }
}
'''
    (SCRIPT_DIR / 'BastionMT12Controller.cs').write_text(code, encoding='utf-8')


def write_gunner_script() -> None:
    code = r'''using UnityEngine;

namespace BastionMediumTank
{
    [DisallowMultipleComponent]
    public sealed class BastionGunnerStation : MonoBehaviour
    {
        [Header("Weapon articulation")]
        [SerializeField] private Transform gunnerYaw;
        [SerializeField] private Transform minigunPitch;
        [SerializeField] private Transform barrelSpin;
        [SerializeField] private Transform muzzle;

        [Header("Crew anchors")]
        [SerializeField] private Transform occupantAnchor;
        [SerializeField] private Transform leftHandGrip;
        [SerializeField] private Transform rightHandGrip;
        [SerializeField] private Transform leftFootAnchor;
        [SerializeField] private Transform rightFootAnchor;
        [SerializeField] private Transform headLookAnchor;
        [SerializeField] private Transform boardingPoint;
        [SerializeField] private Transform dismountPoint;

        [Header("Traverse")]
        [SerializeField, Min(0f)] private float yawSpeedDegrees = 165f;
        [SerializeField, Min(0f)] private float pitchSpeedDegrees = 125f;
        [SerializeField] private float minimumElevation = -15f;
        [SerializeField] private float maximumElevation = 55f;

        [Header("Barrel spin")]
        [SerializeField, Min(0f)] private float maximumSpinDegreesPerSecond = 2400f;
        [SerializeField, Min(0f)] private float spinAccelerationDegreesPerSecond = 5000f;

        private Transform occupant;
        private Transform occupantOriginalParent;
        private bool hasAimPoint;
        private bool firing;
        private Vector3 aimPoint;
        private float currentSpinDegreesPerSecond;

        public bool IsOccupied => occupant != null;
        public Transform Occupant => occupant;
        public Transform OccupantAnchor => occupantAnchor;
        public Transform LeftHandGrip => leftHandGrip;
        public Transform RightHandGrip => rightHandGrip;
        public Transform LeftFootAnchor => leftFootAnchor;
        public Transform RightFootAnchor => rightFootAnchor;
        public Transform HeadLookAnchor => headLookAnchor;
        public Transform BoardingPoint => boardingPoint;
        public Transform DismountPoint => dismountPoint;
        public Transform Muzzle => muzzle;
        public bool IsFiring => firing;

        private void Reset()
        {
            ResolveTransforms();
        }

        private void Awake()
        {
            ResolveTransforms();
        }

        private void LateUpdate()
        {
            if (hasAimPoint)
            {
                ApplyAim(aimPoint, Time.deltaTime, false);
            }

            float targetSpin = firing ? maximumSpinDegreesPerSecond : 0f;
            currentSpinDegreesPerSecond = Mathf.MoveTowards(
                currentSpinDegreesPerSecond,
                targetSpin,
                spinAccelerationDegreesPerSecond * Time.deltaTime);

            if (barrelSpin != null && Mathf.Abs(currentSpinDegreesPerSecond) > 0.01f)
            {
                barrelSpin.Rotate(0f, 0f, currentSpinDegreesPerSecond * Time.deltaTime, Space.Self);
            }
        }

        public void SetAimPoint(Vector3 worldPoint)
        {
            aimPoint = worldPoint;
            hasAimPoint = true;
        }

        public void ClearAimPoint()
        {
            hasAimPoint = false;
        }

        public void SnapAimAt(Vector3 worldPoint)
        {
            if (ResolveTransforms())
            {
                ApplyAim(worldPoint, 0f, true);
            }
        }

        public void SetFiring(bool value)
        {
            firing = value;
        }

        public bool Mount(Transform actorRoot)
        {
            if (actorRoot == null || occupant != null || !ResolveTransforms() || occupantAnchor == null)
            {
                return false;
            }

            occupant = actorRoot;
            occupantOriginalParent = actorRoot.parent;
            actorRoot.SetParent(occupantAnchor, false);
            actorRoot.localPosition = Vector3.zero;
            actorRoot.localRotation = Quaternion.identity;
            return true;
        }

        public Transform Dismount()
        {
            if (occupant == null)
            {
                return null;
            }

            Transform released = occupant;
            released.SetParent(occupantOriginalParent, true);
            if (dismountPoint != null)
            {
                released.SetPositionAndRotation(dismountPoint.position, dismountPoint.rotation);
            }

            occupant = null;
            occupantOriginalParent = null;
            firing = false;
            return released;
        }

        private void ApplyAim(Vector3 worldPoint, float deltaTime, bool snap)
        {
            Vector3 yawLocalDirection = gunnerYaw.parent.InverseTransformDirection(worldPoint - gunnerYaw.position);
            yawLocalDirection.y = 0f;
            if (yawLocalDirection.sqrMagnitude > 0.0001f)
            {
                float targetYaw = Mathf.Atan2(yawLocalDirection.x, yawLocalDirection.z) * Mathf.Rad2Deg;
                float currentYaw = NormalizeAngle(gunnerYaw.localEulerAngles.y);
                float nextYaw = snap
                    ? targetYaw
                    : Mathf.MoveTowardsAngle(currentYaw, targetYaw, yawSpeedDegrees * deltaTime);
                gunnerYaw.localRotation = Quaternion.Euler(0f, nextYaw, 0f);
            }

            Vector3 pitchLocalDirection = gunnerYaw.InverseTransformDirection(worldPoint - minigunPitch.position);
            float elevation = Mathf.Atan2(pitchLocalDirection.y, Mathf.Max(0.0001f, pitchLocalDirection.z)) * Mathf.Rad2Deg;
            elevation = Mathf.Clamp(elevation, minimumElevation, maximumElevation);
            float targetPitch = -elevation;
            float currentPitch = NormalizeAngle(minigunPitch.localEulerAngles.x);
            float nextPitch = snap
                ? targetPitch
                : Mathf.MoveTowardsAngle(currentPitch, targetPitch, pitchSpeedDegrees * deltaTime);
            minigunPitch.localRotation = Quaternion.Euler(nextPitch, 0f, 0f);
        }

        private bool ResolveTransforms()
        {
            if (gunnerYaw == null)
            {
                gunnerYaw = transform.Find("GunnerYaw");
            }
            if (minigunPitch == null && gunnerYaw != null)
            {
                minigunPitch = gunnerYaw.Find("MinigunPitch");
            }
            if (barrelSpin == null && minigunPitch != null)
            {
                barrelSpin = minigunPitch.Find("BarrelSpin");
            }
            if (muzzle == null && barrelSpin != null)
            {
                muzzle = barrelSpin.Find("MinigunMuzzle");
            }
            if (occupantAnchor == null)
            {
                occupantAnchor = transform.Find("OccupantAnchor");
            }
            if (leftHandGrip == null)
            {
                leftHandGrip = transform.Find("LeftHandGrip");
            }
            if (rightHandGrip == null)
            {
                rightHandGrip = transform.Find("RightHandGrip");
            }
            if (leftFootAnchor == null)
            {
                leftFootAnchor = transform.Find("LeftFootAnchor");
            }
            if (rightFootAnchor == null)
            {
                rightFootAnchor = transform.Find("RightFootAnchor");
            }
            if (headLookAnchor == null)
            {
                headLookAnchor = transform.Find("HeadLookAnchor");
            }
            return gunnerYaw != null && minigunPitch != null && barrelSpin != null;
        }

        private static float NormalizeAngle(float angle)
        {
            return angle > 180f ? angle - 360f : angle;
        }
    }
}
'''
    (SCRIPT_DIR / 'BastionGunnerStation.cs').write_text(code, encoding='utf-8')


def write_importer_script() -> None:
    code = r'''using UnityEditor;
using UnityEngine;

namespace BastionMediumTank.Editor
{
    internal sealed class BastionMT12ImportPostprocessor : AssetPostprocessor
    {
        private const string MeshPath = "Assets/BastionMediumTank/Meshes/";
        private const string TexturePath = "Assets/BastionMediumTank/Textures/";

        private void OnPreprocessModel()
        {
            if (!assetPath.StartsWith(MeshPath, System.StringComparison.Ordinal))
            {
                return;
            }

            ModelImporter importer = (ModelImporter)assetImporter;
            importer.globalScale = 1f;
            importer.importAnimation = false;
            importer.importBlendShapes = false;
            importer.importCameras = false;
            importer.importLights = false;
            importer.isReadable = false;
            importer.meshCompression = ModelImporterMeshCompression.Medium;
            importer.normalImportMode = ModelImporterNormals.Import;
        }

        private void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith(TexturePath, System.StringComparison.Ordinal))
            {
                return;
            }

            TextureImporter importer = (TextureImporter)assetImporter;
            importer.textureType = TextureImporterType.Default;
            importer.sRGBTexture = true;
            importer.mipmapEnabled = false;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Point;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
        }
    }
}
'''
    (EDITOR_DIR / 'BastionMT12ImportPostprocessor.cs').write_text(code, encoding='utf-8')


def write_builder_script() -> None:
    code = r'''using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace BastionMediumTank.Editor
{
    internal static class BastionMT12PrefabBuilder
    {
        private const string Root = "Assets/BastionMediumTank";
        private const string Meshes = Root + "/Meshes";
        private const string Textures = Root + "/Textures";
        private const string Materials = Root + "/Materials";
        private const string Prefabs = Root + "/Prefabs";
        private const string PrefabPath = Prefabs + "/Bastion_MT12_Rider.prefab";
        private const string MaterialPath = Materials + "/Bastion_MT12_Palette.mat";

        private static readonly string[] RequiredModels =
        {
            Meshes + "/Bastion_MT12_Hull.obj",
            Meshes + "/Bastion_MT12_LeftTrack.obj",
            Meshes + "/Bastion_MT12_RightTrack.obj",
            Meshes + "/Bastion_MT12_Turret.obj",
            Meshes + "/Bastion_MT12_Cannon.obj",
            Meshes + "/Bastion_MT12_MinigunBase.obj",
            Meshes + "/Bastion_MT12_MinigunBody.obj",
            Meshes + "/Bastion_MT12_MinigunBarrels.obj",
            Meshes + "/Bastion_MT12_LOD1.obj"
        };

        [InitializeOnLoadMethod]
        private static void QueueAutomaticBuild()
        {
            EditorApplication.delayCall += () =>
            {
                if (AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath) == null && AssetsReady())
                {
                    Build(false);
                }
            };
        }

        [MenuItem("Tools/Bastion MT-12 Rider/Create or Rebuild Prefab")]
        private static void BuildFromMenu()
        {
            Build(true);
        }

        private static bool AssetsReady()
        {
            foreach (string path in RequiredModels)
            {
                if (AssetDatabase.LoadAssetAtPath<GameObject>(path) == null)
                {
                    return false;
                }
            }
            return AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_MT12_Palette.png") != null;
        }

        private static void Build(bool selectResult)
        {
            if (!AssetsReady())
            {
                Debug.LogWarning("Bastion MT-12 Rider: model imports are not ready. Re-run the prefab command after Unity finishes importing.");
                return;
            }

            EnsureFolder(Materials);
            EnsureFolder(Prefabs);
            Material material = CreateOrUpdateMaterial();

            GameObject root = new GameObject("Bastion_MT12_Rider");
            root.transform.position = Vector3.zero;
            root.transform.rotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;

            GameObject hull = InstantiateModel("Hull", RequiredModels[0], root.transform, new Vector3(0f, 1.06f, 0f), material);
            GameObject leftTrack = InstantiateModel("LeftTrack", RequiredModels[1], root.transform, new Vector3(-1.58f, 0.74f, 0f), material);
            GameObject rightTrack = InstantiateModel("RightTrack", RequiredModels[2], root.transform, new Vector3(1.58f, 0.74f, 0f), material);

            GameObject turretYaw = NewChild("TurretYaw", root.transform, new Vector3(0f, 1.82f, -0.08f));
            GameObject turretModel = InstantiateModel("TurretModel", RequiredModels[3], turretYaw.transform, Vector3.zero, material);

            GameObject cannonPitch = NewChild("CannonPitch", turretYaw.transform, new Vector3(0f, 0.16f, 1.00f));
            GameObject cannonModel = InstantiateModel("CannonModel", RequiredModels[4], cannonPitch.transform, Vector3.zero, material);
            Transform mainMuzzle = NewAnchor("MainMuzzle", cannonPitch.transform, new Vector3(0f, 0f, 4.74f));

            GameObject gunnerStationObject = NewChild("GunnerStation", turretYaw.transform, new Vector3(0.78f, 0.64f, -0.78f));
            Transform occupantAnchor = NewAnchor("OccupantAnchor", gunnerStationObject.transform, Vector3.zero);
            Transform leftFootAnchor = NewAnchor("LeftFootAnchor", gunnerStationObject.transform, new Vector3(-0.16f, 0.02f, -0.03f));
            Transform rightFootAnchor = NewAnchor("RightFootAnchor", gunnerStationObject.transform, new Vector3(0.16f, 0.02f, -0.03f));
            Transform leftHandGrip = NewAnchor("LeftHandGrip", gunnerStationObject.transform, new Vector3(-0.18f, 1.10f, 0.34f));
            Transform rightHandGrip = NewAnchor("RightHandGrip", gunnerStationObject.transform, new Vector3(0.18f, 1.10f, 0.34f));
            Transform headLookAnchor = NewAnchor("HeadLookAnchor", gunnerStationObject.transform, new Vector3(0f, 1.64f, 0.48f));

            GameObject gunnerYaw = NewChild("GunnerYaw", gunnerStationObject.transform, new Vector3(0f, 0.18f, 0.60f));
            GameObject minigunBase = InstantiateModel("MinigunBase", RequiredModels[5], gunnerYaw.transform, Vector3.zero, material);

            GameObject minigunPitch = NewChild("MinigunPitch", gunnerYaw.transform, new Vector3(0f, 0.88f, 0.14f));
            GameObject minigunBody = InstantiateModel("MinigunBody", RequiredModels[6], minigunPitch.transform, Vector3.zero, material);

            GameObject barrelSpin = NewChild("BarrelSpin", minigunPitch.transform, Vector3.zero);
            GameObject minigunBarrels = InstantiateModel("MinigunBarrels", RequiredModels[7], barrelSpin.transform, Vector3.zero, material);
            Transform minigunMuzzle = NewAnchor("MinigunMuzzle", barrelSpin.transform, new Vector3(0f, 0f, 1.84f));

            Transform boardingPoint = NewAnchor("GunnerBoardingPoint", root.transform, new Vector3(1.96f, 0.72f, -0.82f));
            boardingPoint.localRotation = Quaternion.Euler(0f, -90f, 0f);
            Transform dismountPoint = NewAnchor("GunnerDismountPoint", root.transform, new Vector3(2.28f, 0.02f, -0.82f));
            dismountPoint.localRotation = Quaternion.Euler(0f, -90f, 0f);

            GameObject boardingZone = NewChild("GunnerBoardingZone", root.transform, new Vector3(1.96f, 1.06f, -0.82f));
            BoxCollider boardingTrigger = boardingZone.AddComponent<BoxCollider>();
            boardingTrigger.size = new Vector3(0.90f, 2.10f, 1.30f);
            boardingTrigger.isTrigger = true;

            GameObject lod1 = InstantiateModel("LOD1", RequiredModels[8], root.transform, Vector3.zero, material);
            lod1.SetActive(true);

            ConfigureLODGroup(
                root,
                new[] { hull, leftTrack, rightTrack, turretModel, cannonModel, minigunBase, minigunBody, minigunBarrels },
                lod1);

            BoxCollider hullCollider = root.AddComponent<BoxCollider>();
            hullCollider.center = new Vector3(0f, 1.10f, -0.02f);
            hullCollider.size = new Vector3(3.82f, 2.30f, 5.90f);

            BastionMT12Controller tankController = root.AddComponent<BastionMT12Controller>();
            SerializedObject tankSerialized = new SerializedObject(tankController);
            tankSerialized.FindProperty("turretYaw").objectReferenceValue = turretYaw.transform;
            tankSerialized.FindProperty("cannonPitch").objectReferenceValue = cannonPitch.transform;
            tankSerialized.FindProperty("mainMuzzle").objectReferenceValue = mainMuzzle;
            tankSerialized.ApplyModifiedPropertiesWithoutUndo();

            BastionGunnerStation station = gunnerStationObject.AddComponent<BastionGunnerStation>();
            SerializedObject stationSerialized = new SerializedObject(station);
            stationSerialized.FindProperty("gunnerYaw").objectReferenceValue = gunnerYaw.transform;
            stationSerialized.FindProperty("minigunPitch").objectReferenceValue = minigunPitch.transform;
            stationSerialized.FindProperty("barrelSpin").objectReferenceValue = barrelSpin.transform;
            stationSerialized.FindProperty("muzzle").objectReferenceValue = minigunMuzzle;
            stationSerialized.FindProperty("occupantAnchor").objectReferenceValue = occupantAnchor;
            stationSerialized.FindProperty("leftHandGrip").objectReferenceValue = leftHandGrip;
            stationSerialized.FindProperty("rightHandGrip").objectReferenceValue = rightHandGrip;
            stationSerialized.FindProperty("leftFootAnchor").objectReferenceValue = leftFootAnchor;
            stationSerialized.FindProperty("rightFootAnchor").objectReferenceValue = rightFootAnchor;
            stationSerialized.FindProperty("headLookAnchor").objectReferenceValue = headLookAnchor;
            stationSerialized.FindProperty("boardingPoint").objectReferenceValue = boardingPoint;
            stationSerialized.FindProperty("dismountPoint").objectReferenceValue = dismountPoint;
            stationSerialized.ApplyModifiedPropertiesWithoutUndo();

            PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
            UnityEngine.Object.DestroyImmediate(root);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            if (selectResult && prefab != null)
            {
                Selection.activeObject = prefab;
                EditorGUIUtility.PingObject(prefab);
            }

            Debug.Log("Bastion MT-12 Rider: created " + PrefabPath);
        }

        private static GameObject NewChild(string name, Transform parent, Vector3 localPosition)
        {
            GameObject child = new GameObject(name);
            child.transform.SetParent(parent, false);
            child.transform.localPosition = localPosition;
            child.transform.localRotation = Quaternion.identity;
            child.transform.localScale = Vector3.one;
            return child;
        }

        private static Transform NewAnchor(string name, Transform parent, Vector3 localPosition)
        {
            return NewChild(name, parent, localPosition).transform;
        }

        private static GameObject InstantiateModel(string name, string path, Transform parent, Vector3 localPosition, Material material)
        {
            GameObject source = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(source);
            instance.name = name;
            instance.transform.SetParent(parent, false);
            instance.transform.localPosition = localPosition;
            instance.transform.localRotation = Quaternion.identity;
            instance.transform.localScale = Vector3.one;

            foreach (Renderer renderer in instance.GetComponentsInChildren<Renderer>(true))
            {
                int materialCount = Mathf.Max(1, renderer.sharedMaterials.Length);
                Material[] shared = new Material[materialCount];
                for (int i = 0; i < shared.Length; i++)
                {
                    shared[i] = material;
                }
                renderer.sharedMaterials = shared;
                renderer.shadowCastingMode = ShadowCastingMode.On;
                renderer.receiveShadows = true;
                renderer.lightProbeUsage = LightProbeUsage.BlendProbes;
            }
            return instance;
        }

        private static void ConfigureLODGroup(GameObject root, IEnumerable<GameObject> lod0Roots, GameObject lod1Root)
        {
            List<Renderer> lod0Renderers = new List<Renderer>();
            foreach (GameObject item in lod0Roots)
            {
                lod0Renderers.AddRange(item.GetComponentsInChildren<Renderer>(true));
            }

            Renderer[] lod1Renderers = lod1Root.GetComponentsInChildren<Renderer>(true);
            LODGroup group = root.AddComponent<LODGroup>();
            group.fadeMode = LODFadeMode.CrossFade;
            group.animateCrossFading = false;
            LOD high = new LOD(0.20f, lod0Renderers.ToArray());
            high.fadeTransitionWidth = 0.08f;
            LOD low = new LOD(0.05f, lod1Renderers);
            low.fadeTransitionWidth = 0.10f;
            LOD culled = new LOD(0.009f, Array.Empty<Renderer>());
            group.SetLODs(new[] { high, low, culled });
            group.RecalculateBounds();
        }

        private static Material CreateOrUpdateMaterial()
        {
            Material material = AssetDatabase.LoadAssetAtPath<Material>(MaterialPath);
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null)
            {
                shader = Shader.Find("Standard");
            }
            if (shader == null)
            {
                throw new InvalidOperationException("Bastion MT-12 Rider: neither URP/Lit nor Standard shader could be found.");
            }

            if (material == null)
            {
                material = new Material(shader) { name = "Bastion_MT12_Palette" };
                AssetDatabase.CreateAsset(material, MaterialPath);
            }
            else if (material.shader != shader)
            {
                material.shader = shader;
            }

            Texture2D palette = AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_MT12_Palette.png");
            Texture2D emission = AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_MT12_Emission.png");

            SetTextureIfPresent(material, "_BaseMap", palette);
            SetTextureIfPresent(material, "_MainTex", palette);
            SetColorIfPresent(material, "_BaseColor", Color.white);
            SetColorIfPresent(material, "_Color", Color.white);
            SetFloatIfPresent(material, "_Metallic", 0.16f);
            SetFloatIfPresent(material, "_Smoothness", 0.30f);
            SetFloatIfPresent(material, "_Glossiness", 0.30f);

            if (emission != null)
            {
                SetTextureIfPresent(material, "_EmissionMap", emission);
                SetColorIfPresent(material, "_EmissionColor", Color.white * 1.20f);
                material.EnableKeyword("_EMISSION");
            }

            material.enableInstancing = true;
            EditorUtility.SetDirty(material);
            return material;
        }

        private static void SetTextureIfPresent(Material material, string property, Texture texture)
        {
            if (material.HasProperty(property))
            {
                material.SetTexture(property, texture);
            }
        }

        private static void SetColorIfPresent(Material material, string property, Color value)
        {
            if (material.HasProperty(property))
            {
                material.SetColor(property, value);
            }
        }

        private static void SetFloatIfPresent(Material material, string property, float value)
        {
            if (material.HasProperty(property))
            {
                material.SetFloat(property, value);
            }
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path))
            {
                return;
            }

            string parent = Path.GetDirectoryName(path)?.Replace('\\', '/');
            string name = Path.GetFileName(path);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent))
            {
                EnsureFolder(parent);
            }
            AssetDatabase.CreateFolder(parent, name);
        }
    }
}
'''
    (EDITOR_DIR / 'BastionMT12PrefabBuilder.cs').write_text(code, encoding='utf-8')


def write_readme(stats: dict) -> None:
    readme = f'''# {ASSET_NAME} — Unity / Meta Quest tank asset

This is an original low-poly RTS medium tank with a deliberately chunky, high-readability silhouette. It includes a boardable rear-right standing platform and an independently articulated six-barrel rotary gun. The visual language is inspired by classic base-building RTS vehicles, without reproducing a specific game unit, faction logo, or texture.

## Import

1. Copy the included `Assets/BastionMediumTank` folder into your Unity project's `Assets` folder.
2. Let Unity finish importing and compiling.
3. The editor script creates `Assets/BastionMediumTank/Prefabs/Bastion_MT12_Rider.prefab` automatically.
4. If needed, run **Tools > Bastion MT-12 Rider > Create or Rebuild Prefab**.
5. Drag the prefab into the scene.

The OBJ files are used directly by Unity. Optional GLB exports are in `Extras` and require a glTF importer if you choose to use them.

## Vehicle hierarchy

```text
Bastion_MT12_Rider
├── Hull / LeftTrack / RightTrack
├── TurretYaw
│   ├── TurretModel
│   ├── CannonPitch
│   │   ├── CannonModel
│   │   └── MainMuzzle
│   └── GunnerStation
│       ├── OccupantAnchor + hand/foot/head anchors
│       └── GunnerYaw
│           ├── MinigunBase
│           └── MinigunPitch
│               ├── MinigunBody
│               └── BarrelSpin
│                   ├── MinigunBarrels
│                   └── MinigunMuzzle
├── GunnerBoardingPoint
├── GunnerDismountPoint
└── GunnerBoardingZone (trigger)
```

## Main weapon API

```csharp
BastionMT12Controller tank = GetComponent<BastionMT12Controller>();
tank.SetAimPoint(target.position);
// Fire from tank.MainMuzzle using your own projectile or raycast system.
```

## Gunner station API

```csharp
BastionGunnerStation station = GetComponentInChildren<BastionGunnerStation>();

// Snap a soldier root onto the platform. Your animation/IK system can use the exposed anchors.
station.Mount(soldier.transform);
station.SetAimPoint(target.position);
station.SetFiring(true); // spins the barrel cluster; actual damage is project-specific

// Later:
station.SetFiring(false);
station.Dismount();
```

`Mount` parents the supplied actor root to `OccupantAnchor` and resets its local pose. For a networked or physics-driven character, replace that behavior with your own possession/mount system and use the same anchors.

The station exposes:

- `OccupantAnchor`
- `LeftHandGrip` / `RightHandGrip`
- `LeftFootAnchor` / `RightFootAnchor`
- `HeadLookAnchor`
- `BoardingPoint` / `DismountPoint`
- `Muzzle`

`Meshes/Bastion_MT12_GunnerReference.obj` is a non-rigged 1.80 m scale guide. Place it under `OccupantAnchor` at local position/rotation zero to inspect alignment; it is not a game-ready soldier.

## Coordinate and scale conventions

- 1 Unity unit = 1 meter
- +Y = up
- +Z = forward / weapon direction
- Root origin = ground center
- Main turret pivot = `TurretYaw`
- Main gun elevation pivot = `TurretYaw/CannonPitch`
- Minigun pivots = `TurretYaw/GunnerStation/GunnerYaw/MinigunPitch`

## Technical profile

- LOD0 triangles: {stats['lod0_triangles']:,}
- LOD1 triangles: {stats['lod1_triangles']:,}
- LOD0 articulated model roots: {stats['articulated_renderers']}
- Shared materials: 1
- Palette textures: 2 × {stats['texture_width']}×{stats['texture_height']} RGBA PNG
- Approximate neutral-pose bounds: {stats['bounds_m'][0]:.2f} m wide × {stats['bounds_m'][1]:.2f} m high × {stats['bounds_m'][2]:.2f} m long
- Main collision: one BoxCollider
- Boarding detection: one trigger BoxCollider
- LOD culling included
- GPU instancing enabled on the generated material

## Quest-oriented notes

The tank uses flat-shaded low-poly geometry, one palette material, no transparency, no normal map, compact textures, a static distant LOD, and inexpensive colliders. The soldier, firing logic, projectiles, sounds, VFX, locomotion, damage, and networking remain project-specific. Profile the final simultaneous unit count on the target Quest headset.
'''
    (ASSET_ROOT / 'README.md').write_text(readme, encoding='utf-8')

    root_readme = f'''{ASSET_NAME} Unity Asset

QUICK START
1. Copy the Assets folder into the root of your Unity project.
2. Unity creates Assets/BastionMediumTank/Prefabs/Bastion_MT12_Rider.prefab.
3. See Assets/BastionMediumTank/README.md for the gunner mount API and hierarchy.
'''
    (OUTPUT_ROOT / 'README_FIRST.txt').write_text(root_readme, encoding='utf-8')


def write_notice() -> None:
    text = f'''{ASSET_NAME} asset notice

This package contains original geometry, textures, and source code generated for the recipient. No third-party game meshes, logos, faction marks, or copied textures are included. The design uses broad classic RTS and armored-vehicle visual conventions rather than reproducing a specific copyrighted unit.

No warranty is provided. Test shader compatibility, rig alignment, interaction logic, collision behavior, performance, and platform compliance in your own Unity project before shipping.
'''
    (ASSET_ROOT / 'ASSET_NOTICE.txt').write_text(text, encoding='utf-8')


def write_spec(stats: dict) -> None:
    (PREVIEW_DIR / 'Bastion_MT12_Rider_Spec.json').write_text(json.dumps(stats, indent=2), encoding='utf-8')


def zip_folder(source: Path, destination: Path) -> None:
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(source))


def validate_objs(paths: Sequence[Path]) -> dict[str, dict[str, int]]:
    report: dict[str, dict[str, int]] = {}
    for path in paths:
        loaded = trimesh.load(path, force='mesh', process=False)
        if not isinstance(loaded, trimesh.Trimesh):
            raise RuntimeError(f'{path.name} did not load as a mesh')
        if len(loaded.faces) == 0 or len(loaded.vertices) == 0:
            raise RuntimeError(f'{path.name} is empty')
        if not np.isfinite(loaded.vertices).all():
            raise RuntimeError(f'{path.name} contains non-finite vertices')
        report[path.name] = {'vertices': int(len(loaded.vertices)), 'triangles': int(len(loaded.faces))}
    return report


def main() -> None:
    if OUTPUT_ROOT.exists():
        shutil.rmtree(OUTPUT_ROOT)
    for directory in (MESH_DIR, TEXTURE_DIR, SCRIPT_DIR, EDITOR_DIR, EXTRAS_DIR, PREVIEW_DIR, SOURCE_DIR):
        directory.mkdir(parents=True, exist_ok=True)

    base_image, _ = create_textures()
    write_mtl(MESH_DIR / MTL_NAME)

    parts = {
        'Hull': build_hull(),
        'LeftTrack': build_track(-1),
        'RightTrack': build_track(1),
        'Turret': build_turret(),
        'Cannon': build_cannon(),
        'MinigunBase': build_minigun_base(),
        'MinigunBody': build_minigun_body(),
        'MinigunBarrels': build_minigun_barrels(),
    }

    obj_map = {
        'Hull': ('Bastion_MT12_Hull.obj', 'Bastion_MT12_Hull'),
        'LeftTrack': ('Bastion_MT12_LeftTrack.obj', 'Bastion_MT12_LeftTrack'),
        'RightTrack': ('Bastion_MT12_RightTrack.obj', 'Bastion_MT12_RightTrack'),
        'Turret': ('Bastion_MT12_Turret.obj', 'Bastion_MT12_Turret'),
        'Cannon': ('Bastion_MT12_Cannon.obj', 'Bastion_MT12_Cannon'),
        'MinigunBase': ('Bastion_MT12_MinigunBase.obj', 'Bastion_MT12_MinigunBase'),
        'MinigunBody': ('Bastion_MT12_MinigunBody.obj', 'Bastion_MT12_MinigunBody'),
        'MinigunBarrels': ('Bastion_MT12_MinigunBarrels.obj', 'Bastion_MT12_MinigunBarrels'),
    }
    for key, (filename, object_name) in obj_map.items():
        write_obj(MESH_DIR / filename, object_name, parts[key])

    gunner_reference = build_gunner_reference()
    write_obj(MESH_DIR / 'Bastion_MT12_GunnerReference.obj', 'Bastion_MT12_GunnerReference', gunner_reference)

    static_pieces = combine_all(parts)
    write_obj(MESH_DIR / 'Bastion_MT12_Static.obj', 'Bastion_MT12_Static', static_pieces)

    lod_local = build_lod1_local()
    lod_static = combine_all(lod_local)
    write_obj(MESH_DIR / 'Bastion_MT12_LOD1.obj', 'Bastion_MT12_LOD1', lod_static)

    export_glb(
        EXTRAS_DIR / 'Bastion_MT12_Articulated.glb',
        [
            ('Hull', parts['Hull'], PIVOTS['Hull'], None),
            ('LeftTrack', parts['LeftTrack'], PIVOTS['LeftTrack'], None),
            ('RightTrack', parts['RightTrack'], PIVOTS['RightTrack'], None),
            ('TurretYaw', parts['Turret'], PIVOTS['TurretYaw'], None),
            ('CannonPitch', parts['Cannon'], PIVOTS['CannonPitch_local'], 'TurretYaw'),
            ('GunnerStation', [Piece('EmptyStationMarker', box((0.001, 0.001, 0.001)), 'Secondary')], PIVOTS['GunnerStation_local'], 'TurretYaw'),
            ('GunnerYaw', parts['MinigunBase'], PIVOTS['GunnerYaw_local'], 'GunnerStation'),
            ('MinigunPitch', parts['MinigunBody'], PIVOTS['MinigunPitch_local'], 'GunnerYaw'),
            ('BarrelSpin', parts['MinigunBarrels'], (0.0, 0.0, 0.0), 'MinigunPitch'),
        ],
        base_image,
    )
    static_glb_mesh = flatten_for_glb(static_pieces, base_image)
    (EXTRAS_DIR / 'Bastion_MT12_Static.glb').write_bytes(static_glb_mesh.export(file_type='glb'))

    write_controller_script()
    write_gunner_script()
    write_importer_script()
    write_builder_script()
    write_notice()

    lod0_triangles = sum(len(piece.mesh.faces) for group in parts.values() for piece in group)
    lod1_triangles = sum(len(piece.mesh.faces) for piece in lod_static)
    all_vertices = np.vstack([piece.mesh.vertices for piece in static_pieces])
    mins = all_vertices.min(axis=0)
    maxs = all_vertices.max(axis=0)
    bounds = maxs - mins

    obj_paths = [MESH_DIR / filename for filename, _ in obj_map.values()]
    obj_paths.extend([
        MESH_DIR / 'Bastion_MT12_GunnerReference.obj',
        MESH_DIR / 'Bastion_MT12_Static.obj',
        MESH_DIR / 'Bastion_MT12_LOD1.obj',
    ])
    validation = validate_objs(obj_paths)

    stats = {
        'asset_name': ASSET_NAME,
        'coordinate_system': 'Y-up, Z-forward, meters',
        'lod0_triangles': int(lod0_triangles),
        'lod1_triangles': int(lod1_triangles),
        'articulated_renderers': 8,
        'materials': 1,
        'texture_width': SWATCH_WIDTH * len(PALETTE_ORDER),
        'texture_height': TEXTURE_HEIGHT,
        'bounds_m': [float(bounds[0]), float(bounds[1]), float(bounds[2])],
        'bounds_min': [float(v) for v in mins],
        'bounds_max': [float(v) for v in maxs],
        'pivot_positions': {key: [float(v) for v in value] for key, value in PIVOTS.items()},
        'gunner_anchors_local_to_station': {
            'OccupantAnchor': [0.0, 0.0, 0.0],
            'LeftFootAnchor': [-0.16, 0.02, -0.03],
            'RightFootAnchor': [0.16, 0.02, -0.03],
            'LeftHandGrip': [-0.18, 1.10, 0.34],
            'RightHandGrip': [0.18, 1.10, 0.34],
            'HeadLookAnchor': [0.0, 1.64, 0.48],
        },
        'validation': validation,
    }
    write_readme(stats)
    write_spec(stats)

    dummy_world = transform_pieces(gunner_reference, translation=station_anchor_world(), prefix='Preview_')
    preview_with_dummy = static_pieces + dummy_world
    render_preview(preview_with_dummy, PREVIEW_DIR / 'Bastion_MT12_Rider_Preview.png', view='perspective')
    render_preview(static_pieces, PREVIEW_DIR / 'Bastion_MT12_Rider_Side.png', view='side')
    render_preview(static_pieces, PREVIEW_DIR / 'Bastion_MT12_Rider_Top.png', view='top')
    render_preview(preview_with_dummy, PREVIEW_DIR / 'Bastion_MT12_Gunner_Detail.png', view='gunner')

    shutil.copy2(Path(__file__), SOURCE_DIR / 'generate_bastion_mt12.py')

    full_zip = Path('/mnt/data/Bastion_MT12_Rider_Unity_Asset.zip')
    zip_folder(OUTPUT_ROOT, full_zip)

    quick = Path('/mnt/data/Bastion_MT12_Rider_QuickImport')
    if quick.exists():
        shutil.rmtree(quick)
    (quick / 'Meshes').mkdir(parents=True)
    (quick / 'Textures').mkdir(parents=True)
    for filename in ('Bastion_MT12_Static.obj', MTL_NAME):
        shutil.copy2(MESH_DIR / filename, quick / 'Meshes' / filename)
    for filename in ('Bastion_MT12_Palette.png', 'Bastion_MT12_Emission.png'):
        shutil.copy2(TEXTURE_DIR / filename, quick / 'Textures' / filename)
    (quick / 'README.txt').write_text(
        'Drag the Meshes and Textures folders into Unity together. Use Bastion_MT12_Static.obj for a neutral-pose, non-articulated one-piece model. The full package contains the articulated turret, minigun, gunner anchors, scripts, LOD, and prefab builder.\n',
        encoding='utf-8',
    )
    quick_zip = Path('/mnt/data/Bastion_MT12_Rider_QuickImport.zip')
    zip_folder(quick, quick_zip)

    # Verify ZIP integrity and required contents.
    for zip_path in (full_zip, quick_zip):
        with zipfile.ZipFile(zip_path, 'r') as archive:
            corrupt = archive.testzip()
            if corrupt is not None:
                raise RuntimeError(f'Corrupt ZIP entry in {zip_path.name}: {corrupt}')

    print(json.dumps(stats, indent=2))


if __name__ == '__main__':
    main()
