from __future__ import annotations

import json
import math
import shutil
import sys
import sys
import textwrap
import zipfile
from pathlib import Path
from typing import Sequence

import numpy as np
from PIL import Image, ImageDraw
import trimesh

sys.path.insert(0, '/mnt/data')
import generate_bastion_mt12 as common

# Reuse the proven mesh/export utilities from the earlier Bastion tank generator.
Piece = common.Piece
box = common.box
cylinder = common.cylinder
cylinder_between = common.cylinder_between
ellipsoid = common.ellipsoid
extrude_ring_profile_x = common.extrude_ring_profile_x
layered_prism = common.layered_prism
merge = common.merge
tapered_cylinder_z = common.tapered_cylinder_z
transform_pieces = common.transform_pieces
clean_mesh = common.clean_mesh

OUTPUT_ROOT = Path('/mnt/data/Bastion_HT77_Mammoth_Unity_Package')
ASSET_ROOT = OUTPUT_ROOT / 'Assets' / 'BastionHeavyTank'
MESH_DIR = ASSET_ROOT / 'Meshes'
TEXTURE_DIR = ASSET_ROOT / 'Textures'
SCRIPT_DIR = ASSET_ROOT / 'Scripts'
EDITOR_DIR = ASSET_ROOT / 'Editor'
EXTRAS_DIR = ASSET_ROOT / 'Extras'
SOURCE_DIR = OUTPUT_ROOT / 'Source'
SPEC_DIR = OUTPUT_ROOT / 'Spec'

ASSET_NAME = 'Bastion HT-77 Mammoth'
ASSET_SLUG = 'Bastion_HT77_Mammoth'
MTL_NAME = 'Bastion_HT77.mtl'

PALETTE = {
    'Armor': (82, 91, 67, 255),
    'Secondary': (55, 61, 57, 255),
    'Track': (24, 27, 26, 255),
    'Weapon': (39, 43, 42, 255),
    'Accent': (178, 67, 34, 255),
    'Optic': (48, 113, 126, 255),
    'Missile': (151, 56, 30, 255),
}
PALETTE_ORDER = list(PALETTE)
SWATCH_WIDTH = 32
TEXTURE_HEIGHT = 32

# Configure imported common utilities to write this package's names and palette.
common.ASSET_NAME = ASSET_NAME
common.MTL_NAME = MTL_NAME
common.PALETTE = PALETTE
common.PALETTE_ORDER = PALETTE_ORDER
common.SWATCH_WIDTH = SWATCH_WIDTH
common.TEXTURE_HEIGHT = TEXTURE_HEIGHT


PIVOTS = {
    'Hull': (0.0, 1.18, 0.0),
    'LeftTrack': (-1.94, 0.84, 0.0),
    'RightTrack': (1.94, 0.84, 0.0),
    'TurretYaw': (0.0, 2.20, -0.12),
    'CannonPitch_local': (0.0, 0.08, 1.48),
    'MissileYaw_local': (1.06, 0.58, -0.62),
    'MissilePitch_local': (0.0, 0.62, 0.05),
}


def write_textures() -> Image.Image:
    width = SWATCH_WIDTH * len(PALETTE_ORDER)
    base = Image.new('RGBA', (width, TEXTURE_HEIGHT), (255, 255, 255, 255))
    emission = Image.new('RGBA', (width, TEXTURE_HEIGHT), (0, 0, 0, 255))
    base_draw = ImageDraw.Draw(base)
    emission_draw = ImageDraw.Draw(emission)
    for index, name in enumerate(PALETTE_ORDER):
        x0 = index * SWATCH_WIDTH
        x1 = (index + 1) * SWATCH_WIDTH - 1
        base_draw.rectangle((x0, 0, x1, TEXTURE_HEIGHT - 1), fill=PALETTE[name])
        if name == 'Optic':
            emission_draw.rectangle((x0, 0, x1, TEXTURE_HEIGHT - 1), fill=(72, 214, 255, 255))
    base.save(TEXTURE_DIR / 'Bastion_HT77_Palette.png', optimize=True)
    emission.save(TEXTURE_DIR / 'Bastion_HT77_Emission.png', optimize=True)
    return base


def write_mtl() -> None:
    (MESH_DIR / MTL_NAME).write_text(textwrap.dedent('''\
        # Single palette material. Unity replaces this with a URP/Built-in compatible material.
        newmtl BastionPalette
        Ka 0.120000 0.120000 0.120000
        Kd 1.000000 1.000000 1.000000
        Ks 0.140000 0.140000 0.140000
        Ns 36.000000
        d 1.000000
        illum 2
        map_Kd ../Textures/Bastion_HT77_Palette.png
    '''), encoding='utf-8')


def build_hull() -> list[Piece]:
    lower_bottom = np.array([
        [-1.74, -3.34], [1.74, -3.34], [2.04, -2.82], [2.10, 2.34],
        [1.72, 3.42], [-1.72, 3.42], [-2.10, 2.34], [-2.04, -2.82],
    ])
    lower_top = np.array([
        [-1.90, -3.24], [1.90, -3.24], [2.13, -2.63], [2.13, 2.42],
        [1.69, 3.56], [-1.69, 3.56], [-2.13, 2.42], [-2.13, -2.63],
    ])
    lower = layered_prism([lower_bottom, lower_top], [-0.80, -0.12])

    upper_base = np.array([
        [-1.76, -2.94], [1.76, -2.94], [1.92, -2.35], [1.90, 2.08],
        [1.48, 3.24], [-1.48, 3.24], [-1.90, 2.08], [-1.92, -2.35],
    ])
    upper_mid = np.array([
        [-1.51, -2.69], [1.51, -2.69], [1.63, -2.08], [1.56, 1.70],
        [1.16, 2.80], [-1.16, 2.80], [-1.56, 1.70], [-1.63, -2.08],
    ])
    upper_top = np.array([
        [-1.26, -2.22], [1.26, -2.22], [1.36, -1.67], [1.27, 1.24],
        [0.91, 2.20], [-0.91, 2.20], [-1.27, 1.24], [-1.36, -1.67],
    ])
    upper = layered_prism([upper_base, upper_mid, upper_top], [-0.10, 0.40, 0.86])

    armor: list[trimesh.Trimesh] = [lower, upper]

    # Thick segmented side skirts and full-length fenders.
    for side in (-1, 1):
        armor.append(box((0.32, 0.16, 6.46), center=(side * 2.15, 0.58, -0.02)))
        for z in (-2.52, -1.22, 0.08, 1.38, 2.58):
            armor.append(box((0.16, 0.66, 1.10), center=(side * 2.22, 0.23, z)))
        armor.extend([
            box((0.38, 0.17, 0.70), center=(side * 2.12, 0.38, 3.08), euler_deg=(-34, 0, 0)),
            box((0.38, 0.17, 0.72), center=(side * 2.12, 0.32, -3.04), euler_deg=(28, 0, 0)),
        ])

    # Layered frontal glacis, rear deck, and central reinforcement spine.
    armor.extend([
        box((2.64, 0.18, 1.44), center=(0, 0.81, 2.11), euler_deg=(-13, 0, 0)),
        box((2.98, 0.16, 0.68), center=(0, 0.47, 2.91), euler_deg=(-26, 0, 0)),
        box((1.12, 0.20, 2.34), center=(0, 0.86, 0.45)),
        box((2.86, 0.18, 1.34), center=(0, 0.84, -2.16)),
        box((1.72, 0.14, 0.34), center=(0, 0.12, 3.45), euler_deg=(-28, 0, 0)),
    ])

    secondary: list[trimesh.Trimesh] = []
    # Engine deck grilles.
    for x in np.linspace(-1.08, 1.08, 7):
        secondary.append(box((0.24, 0.065, 1.18), center=(float(x), 0.98, -2.15)))
    for x in (-1.46, 1.46):
        secondary.extend([
            box((0.52, 0.12, 0.76), center=(x, 0.89, -2.48)),
            cylinder(0.16, 0.96, axis='z', center=(x, 0.93, -1.86), sections=10),
        ])

    # Tow hooks and bumper blocks.
    for side in (-1, 1):
        secondary.extend([
            cylinder_between((side * 0.92, -0.36, 3.36), (side * 0.92, -0.02, 3.36), 0.055, 8),
            cylinder_between((side * 0.92, -0.02, 3.36), (side * 1.18, 0.03, 3.14), 0.055, 8),
            box((0.62, 0.26, 0.28), center=(side * 1.55, -0.26, 3.25)),
        ])
    secondary.extend([
        box((1.50, 0.18, 0.22), center=(0, -0.48, -3.42)),
        box((0.64, 0.18, 0.36), center=(0, 0.12, 3.38), euler_deg=(-20, 0, 0)),
    ])

    # Headlight housings and side utility boxes.
    for side in (-1, 1):
        secondary.extend([
            box((0.48, 0.23, 0.32), center=(side * 1.34, 0.52, 2.83), euler_deg=(-18, 0, 0)),
            box((0.42, 0.32, 0.60), center=(side * 1.84, 0.56, -1.36)),
            box((0.34, 0.24, 0.56), center=(side * 1.84, 0.62, 1.34)),
        ])

    accent: list[trimesh.Trimesh] = [
        box((1.32, 0.05, 0.16), center=(0, 0.98, 1.56)),
        box((1.20, 0.05, 0.14), center=(0, 0.99, -0.75)),
    ]
    for side in (-1, 1):
        accent.extend([
            box((0.045, 0.28, 1.12), center=(side * 2.32, 0.34, 0.66)),
            box((0.32, 0.10, 0.18), center=(side * 1.34, 0.68, 2.92), euler_deg=(-18, 0, 0)),
            box((0.42, 0.08, 0.14), center=(side * 1.83, 0.78, -1.18)),
        ])

    optics = [
        box((0.31, 0.08, 0.10), center=(-1.34, 0.60, 3.00), euler_deg=(-18, 0, 0)),
        box((0.31, 0.08, 0.10), center=(1.34, 0.60, 3.00), euler_deg=(-18, 0, 0)),
    ]

    return [
        Piece('Hull_Armor', merge(armor), 'Armor'),
        Piece('Hull_Secondary', merge(secondary), 'Secondary'),
        Piece('Hull_Accent', merge(accent), 'Accent'),
        Piece('Hull_Optics', merge(optics), 'Optic'),
    ]


def build_track(side: int) -> list[Piece]:
    if side not in (-1, 1):
        raise ValueError('side must be -1 or 1')

    outer = [
        (-0.82, -2.82), (-0.82, 2.70), (-0.70, 3.08), (-0.42, 3.34),
        (-0.08, 3.44), (0.31, 3.37), (0.62, 3.10), (0.82, 2.57),
        (0.84, -2.58), (0.67, -3.06), (0.36, -3.36), (-0.08, -3.44),
        (-0.48, -3.30), (-0.72, -3.06),
    ]
    inner = [
        (-0.56, -2.58), (-0.56, 2.48), (-0.46, 2.79), (-0.23, 3.01),
        (0.03, 3.07), (0.28, 2.99), (0.49, 2.76), (0.59, 2.37),
        (0.60, -2.35), (0.47, -2.77), (0.22, -3.02), (-0.05, -3.08),
        (-0.30, -2.98), (-0.49, -2.80),
    ]

    band: list[trimesh.Trimesh] = [extrude_ring_profile_x(outer, inner, thickness=0.70)]
    for z in np.linspace(-2.92, 2.86, 25):
        band.append(box((0.78, 0.11, 0.23), center=(0, -0.83, float(z))))
    for z in np.linspace(-2.38, 2.35, 20):
        band.append(box((0.78, 0.10, 0.23), center=(0, 0.84, float(z))))

    for z, y, angle in [
        (3.02, -0.68, -14), (3.22, -0.52, -30), (3.37, -0.27, -48),
        (3.39, 0.04, -66), (3.28, 0.36, -80), (3.06, 0.66, -88),
        (-3.02, -0.68, 14), (-3.22, -0.52, 30), (-3.37, -0.27, 48),
        (-3.39, 0.04, 66), (-3.27, 0.36, 80), (-3.04, 0.66, 88),
    ]:
        band.append(box((0.78, 0.11, 0.23), center=(0, y, z), euler_deg=(angle, 0, 0)))

    tires: list[trimesh.Trimesh] = []
    wheels: list[trimesh.Trimesh] = []
    hubs: list[trimesh.Trimesh] = []
    outward = side * 0.15
    hub_outward = side * 0.37

    road_positions = (-2.70, -1.94, -1.18, -0.42, 0.34, 1.10, 1.86, 2.62)
    for z in road_positions:
        tires.append(cylinder(0.47, 0.53, axis='x', center=(outward, -0.12, z), sections=14))
        wheels.append(cylinder(0.355, 0.58, axis='x', center=(outward + side * 0.025, -0.12, z), sections=14))
        hubs.append(cylinder(0.12, 0.65, axis='x', center=(hub_outward, -0.12, z), sections=12))

    for z, y, radius in ((-3.15, -0.02, 0.42), (3.15, -0.01, 0.42)):
        tires.append(cylinder(radius, 0.51, axis='x', center=(outward, y, z), sections=14))
        wheels.append(cylinder(radius * 0.72, 0.57, axis='x', center=(outward + side * 0.025, y, z), sections=12))
        hubs.append(cylinder(0.11, 0.64, axis='x', center=(hub_outward, y, z), sections=10))

    for z in (-2.25, -1.12, 0.0, 1.12, 2.25):
        tires.append(cylinder(0.17, 0.41, axis='x', center=(outward, 0.58, z), sections=10))

    name = 'LeftTrack' if side < 0 else 'RightTrack'
    return [
        Piece(f'{name}_Band', merge(band), 'Track'),
        Piece(f'{name}_Tires', merge(tires), 'Track'),
        Piece(f'{name}_Wheels', merge(wheels), 'Secondary'),
        Piece(f'{name}_Hubs', merge(hubs), 'Accent'),
    ]


def build_turret() -> list[Piece]:
    footprints = [
        np.array([[-1.58, -1.54], [1.58, -1.54], [1.80, -1.02], [1.82, 0.86], [1.45, 1.63], [-1.45, 1.63], [-1.82, 0.86], [-1.80, -1.02]]),
        np.array([[-1.70, -1.42], [1.70, -1.42], [1.88, -0.89], [1.88, 0.82], [1.48, 1.73], [-1.48, 1.73], [-1.88, 0.82], [-1.88, -0.89]]),
        np.array([[-1.47, -1.22], [1.47, -1.22], [1.64, -0.75], [1.64, 0.63], [1.28, 1.52], [-1.28, 1.52], [-1.64, 0.63], [-1.64, -0.75]]),
        np.array([[-1.12, -0.92], [1.12, -0.92], [1.24, -0.54], [1.24, 0.45], [0.98, 1.18], [-0.98, 1.18], [-1.24, 0.45], [-1.24, -0.54]]),
    ]
    shell = layered_prism(footprints, [-0.34, -0.10, 0.48, 0.80])

    armor: list[trimesh.Trimesh] = [
        shell,
        box((2.72, 0.42, 0.54), center=(0, 0.06, 1.50)),
        box((0.62, 0.66, 0.86), center=(-0.43, 0.04, 1.64)),
        box((0.62, 0.66, 0.86), center=(0.43, 0.04, 1.64)),
        box((0.40, 0.44, 1.16), center=(-1.62, 0.14, -0.04), euler_deg=(0, 0, -6)),
        box((0.40, 0.44, 1.16), center=(1.62, 0.14, -0.04), euler_deg=(0, 0, 6)),
        box((1.58, 0.24, 0.62), center=(0, 0.67, -1.18)),
    ]

    # Commander cupola and roof armor.
    armor.extend([
        cylinder(0.39, 0.20, axis='y', center=(-0.54, 0.92, -0.20), sections=12),
        cylinder(0.30, 0.17, axis='y', center=(-0.54, 1.07, -0.20), sections=12),
        box((0.92, 0.16, 0.66), center=(0.48, 0.88, -0.22)),
        box((0.62, 0.18, 0.46), center=(0.68, 1.00, 0.34)),
    ])

    secondary: list[trimesh.Trimesh] = [
        cylinder(0.18, 1.44, axis='x', center=(0, 0.30, -1.38), sections=12),
        cylinder(0.035, 1.32, axis='y', center=(-1.02, 1.45, -0.58), sections=7),
        box((0.30, 0.20, 0.24), center=(-0.05, 1.02, -0.02)),
        box((0.30, 0.18, 0.20), center=(0.78, 0.96, 0.40)),
    ]

    # Smoke launchers.
    for side in (-1, 1):
        for i, z in enumerate((0.12, 0.39, 0.66, 0.93)):
            launcher = cylinder(0.075, 0.32, axis='z', center=(side * (1.37 + 0.035 * i), 0.28 + 0.04 * i, z), sections=8)
            secondary.append(common.transformed(launcher, euler_deg=(-12, side * 10, 0)))

    accent = [
        box((0.58, 0.045, 0.11), center=(-0.54, 1.18, -0.20)),
        box((0.70, 0.05, 0.12), center=(0.48, 0.99, -0.22)),
        box((1.20, 0.05, 0.12), center=(0, 0.82, 0.98)),
    ]
    for side in (-1, 1):
        accent.append(box((0.045, 0.30, 0.88), center=(side * 1.91, 0.18, -0.02)))

    optics = [
        box((0.30, 0.13, 0.10), center=(-0.54, 1.12, 0.12)),
        box((0.24, 0.14, 0.10), center=(0.77, 1.03, 0.64)),
        box((0.22, 0.12, 0.08), center=(-1.52, 0.44, 0.86)),
        box((0.22, 0.12, 0.08), center=(1.52, 0.44, 0.86)),
    ]

    return [
        Piece('Turret_Armor', merge(armor), 'Armor'),
        Piece('Turret_Secondary', merge(secondary), 'Secondary'),
        Piece('Turret_Accent', merge(accent), 'Accent'),
        Piece('Turret_Optics', merge(optics), 'Optic'),
    ]


def build_twin_cannons() -> list[Piece]:
    armor: list[trimesh.Trimesh] = []
    weapon: list[trimesh.Trimesh] = []
    secondary: list[trimesh.Trimesh] = []
    accent: list[trimesh.Trimesh] = []

    for x in (-0.43, 0.43):
        armor.extend([
            cylinder(0.31, 0.52, axis='z', center=(x, 0, 0.26), sections=14),
            tapered_cylinder_z(0.24, 0.175, 1.10, center=(x, 0, 1.02), sections=14),
            cylinder(0.171, 3.45, axis='z', center=(x, 0, 3.24), sections=14),
            cylinder(0.22, 0.46, axis='z', center=(x, 0, 1.68), sections=14),
        ])
        weapon.extend([
            cylinder(0.245, 0.46, axis='z', center=(x, 0, 5.18), sections=12),
            box((0.57, 0.20, 0.38), center=(x, 0, 5.18)),
            box((0.20, 0.57, 0.38), center=(x, 0, 5.18)),
            cylinder(0.115, 0.10, axis='z', center=(x, 0, 5.47), sections=12),
        ])
        accent.extend([
            cylinder(0.226, 0.05, axis='z', center=(x, 0, 1.69), sections=14),
            cylinder(0.183, 0.045, axis='z', center=(x, 0, 3.94), sections=14),
        ])

    secondary.extend([
        box((1.35, 0.20, 0.34), center=(0, -0.22, 0.34)),
        box((1.10, 0.13, 0.22), center=(0, 0.28, 0.64)),
    ])

    return [
        Piece('TwinCannons_Armor', merge(armor), 'Armor'),
        Piece('TwinCannons_Weapon', merge(weapon), 'Weapon'),
        Piece('TwinCannons_Secondary', merge(secondary), 'Secondary'),
        Piece('TwinCannons_Accent', merge(accent), 'Accent'),
    ]


def build_missile_base() -> list[Piece]:
    armor = [
        cylinder(0.43, 0.24, axis='y', center=(0, 0.12, 0), sections=12),
        cylinder(0.33, 0.42, axis='y', center=(0, 0.44, 0), sections=12),
        box((1.02, 0.22, 0.70), center=(0, 0.68, 0.03)),
        box((0.18, 0.68, 0.72), center=(-0.48, 0.66, 0.03)),
        box((0.18, 0.68, 0.72), center=(0.48, 0.66, 0.03)),
    ]
    secondary = [
        cylinder(0.16, 1.12, axis='x', center=(0, 0.80, 0.04), sections=12),
        box((0.74, 0.16, 0.16), center=(0, 0.93, -0.20)),
    ]
    accent = [box((0.62, 0.045, 0.10), center=(0, 0.82, -0.34))]
    return [
        Piece('MissileBase_Armor', merge(armor), 'Armor'),
        Piece('MissileBase_Secondary', merge(secondary), 'Secondary'),
        Piece('MissileBase_Accent', merge(accent), 'Accent'),
    ]


def build_missile_pod() -> list[Piece]:
    armor = [
        box((1.66, 0.96, 1.30), center=(0, 0, 0.12)),
        box((1.80, 0.16, 1.44), center=(0, 0.50, 0.12)),
        box((1.80, 0.16, 1.44), center=(0, -0.50, 0.12)),
        box((0.16, 0.92, 1.44), center=(-0.90, 0, 0.12)),
        box((0.16, 0.92, 1.44), center=(0.90, 0, 0.12)),
        box((1.42, 0.16, 0.24), center=(0, 0, -0.64)),
    ]
    weapon: list[trimesh.Trimesh] = []
    missiles: list[trimesh.Trimesh] = []
    accent: list[trimesh.Trimesh] = []
    x_values = (-0.57, -0.19, 0.19, 0.57)
    y_values = (-0.23, 0.23)
    for y in y_values:
        for x in x_values:
            weapon.extend([
                cylinder(0.145, 0.20, axis='z', center=(x, y, 0.79), sections=12),
                cylinder(0.105, 0.12, axis='z', center=(x, y, 0.88), sections=12),
            ])
            missiles.append(cylinder(0.088, 0.08, axis='z', center=(x, y, 0.91), sections=10))
    accent.extend([
        box((1.42, 0.05, 0.10), center=(0, 0.57, 0.26)),
        box((1.42, 0.05, 0.10), center=(0, -0.57, 0.26)),
    ])
    return [
        Piece('MissilePod_Armor', merge(armor), 'Armor'),
        Piece('MissilePod_Tubes', merge(weapon), 'Weapon'),
        Piece('MissilePod_Missiles', merge(missiles), 'Missile'),
        Piece('MissilePod_Accent', merge(accent), 'Accent'),
    ]


def build_lod1_local() -> dict[str, list[Piece]]:
    hull_base = np.array([
        [-1.92, -3.26], [1.92, -3.26], [2.12, -2.62], [2.12, 2.40],
        [1.66, 3.50], [-1.66, 3.50], [-2.12, 2.40], [-2.12, -2.62],
    ])
    hull_top = np.array([
        [-1.30, -2.25], [1.30, -2.25], [1.40, -1.62], [1.30, 1.30],
        [0.92, 2.26], [-0.92, 2.26], [-1.30, 1.30], [-1.40, -1.62],
    ])
    hull = [
        Piece('Hull_LOD1_Armor', layered_prism([hull_base, hull_top], [-0.78, 0.86]), 'Armor'),
        Piece('Hull_LOD1_Accent', box((1.40, 0.05, 0.16), center=(0, 0.90, 1.52)), 'Accent'),
    ]
    left = [Piece('LeftTrack_LOD1', box((0.72, 1.66, 6.75), center=(0, 0, 0)), 'Track')]
    right = [Piece('RightTrack_LOD1', box((0.72, 1.66, 6.75), center=(0, 0, 0)), 'Track')]

    turret = [
        Piece('Turret_LOD1_Armor', merge([
            box((3.54, 1.06, 2.96), center=(0, 0.18, 0.02)),
            box((2.40, 0.38, 0.54), center=(0, 0.04, 1.48)),
            cylinder(0.32, 0.25, axis='y', center=(-0.55, 0.85, -0.18), sections=8),
        ]), 'Armor'),
        Piece('Turret_LOD1_Optic', box((0.28, 0.11, 0.08), center=(-0.55, 1.02, 0.12)), 'Optic'),
    ]

    cannon_parts: list[trimesh.Trimesh] = []
    for x in (-0.43, 0.43):
        cannon_parts.extend([
            cylinder(0.25, 0.55, axis='z', center=(x, 0, 0.28), sections=8),
            tapered_cylinder_z(0.18, 0.13, 4.82, center=(x, 0, 2.84), sections=8),
            box((0.44, 0.18, 0.34), center=(x, 0, 5.30)),
        ])
    cannon = [Piece('TwinCannons_LOD1', merge(cannon_parts), 'Armor')]

    missile_base = [Piece('MissileBase_LOD1', merge([
        cylinder(0.34, 0.76, axis='y', center=(0, 0.38, 0), sections=8),
        box((1.00, 0.30, 0.72), center=(0, 0.72, 0.02)),
    ]), 'Secondary')]
    missile_pod = [
        Piece('MissilePod_LOD1_Armor', box((1.72, 1.00, 1.35), center=(0, 0, 0.12)), 'Armor'),
        Piece('MissilePod_LOD1_Missiles', merge([
            cylinder(0.10, 0.10, axis='z', center=(x, y, 0.84), sections=8)
            for y in (-0.22, 0.22) for x in (-0.55, -0.18, 0.18, 0.55)
        ]), 'Missile'),
    ]
    return {
        'Hull': hull,
        'LeftTrack': left,
        'RightTrack': right,
        'Turret': turret,
        'TwinCannons': cannon,
        'MissileBase': missile_base,
        'MissilePod': missile_pod,
    }


def combine_all(parts: dict[str, list[Piece]]) -> list[Piece]:
    world: list[Piece] = []
    world.extend(transform_pieces(parts['Hull'], translation=PIVOTS['Hull'], prefix='Static_'))
    world.extend(transform_pieces(parts['LeftTrack'], translation=PIVOTS['LeftTrack'], prefix='Static_'))
    world.extend(transform_pieces(parts['RightTrack'], translation=PIVOTS['RightTrack'], prefix='Static_'))

    turret_world = np.asarray(PIVOTS['TurretYaw'])
    world.extend(transform_pieces(parts['Turret'], translation=turret_world, prefix='Static_'))

    cannon_world = turret_world + np.asarray(PIVOTS['CannonPitch_local'])
    world.extend(transform_pieces(parts['TwinCannons'], translation=cannon_world, prefix='Static_'))

    missile_yaw_world = turret_world + np.asarray(PIVOTS['MissileYaw_local'])
    world.extend(transform_pieces(parts['MissileBase'], translation=missile_yaw_world, prefix='Static_'))

    missile_pitch_world = missile_yaw_world + np.asarray(PIVOTS['MissilePitch_local'])
    world.extend(transform_pieces(parts['MissilePod'], translation=missile_pitch_world, prefix='Static_'))
    return world


def write_controller_script() -> None:
    code = r'''using UnityEngine;

namespace BastionHeavyTank
{
    [DisallowMultipleComponent]
    public sealed class BastionHT77Controller : MonoBehaviour
    {
        [Header("Main weapon articulation")]
        [SerializeField] private Transform turretYaw;
        [SerializeField] private Transform cannonPitch;
        [SerializeField] private Transform leftCannonMuzzle;
        [SerializeField] private Transform rightCannonMuzzle;

        [Header("Missile attachment articulation")]
        [SerializeField] private Transform missileYaw;
        [SerializeField] private Transform missilePitch;
        [SerializeField] private Transform[] missileMuzzles;

        [Header("Main weapon traverse")]
        [SerializeField, Min(0f)] private float turretSpeedDegrees = 42f;
        [SerializeField, Min(0f)] private float cannonSpeedDegrees = 34f;
        [SerializeField] private float minimumCannonElevation = -6f;
        [SerializeField] private float maximumCannonElevation = 24f;

        [Header("Missile traverse")]
        [SerializeField, Min(0f)] private float missileYawSpeedDegrees = 70f;
        [SerializeField, Min(0f)] private float missilePitchSpeedDegrees = 58f;
        [SerializeField] private float minimumMissileElevation = -5f;
        [SerializeField] private float maximumMissileElevation = 55f;

        private bool hasMainAimPoint;
        private bool hasMissileAimPoint;
        private Vector3 mainAimPoint;
        private Vector3 missileAimPoint;

        public Transform TurretYaw => turretYaw;
        public Transform CannonPitch => cannonPitch;
        public Transform LeftCannonMuzzle => leftCannonMuzzle;
        public Transform RightCannonMuzzle => rightCannonMuzzle;
        public Transform MissileYaw => missileYaw;
        public Transform MissilePitch => missilePitch;
        public Transform[] MissileMuzzles => missileMuzzles;

        private void Reset()
        {
            ResolveTransforms();
        }

        private void Awake()
        {
            ResolveTransforms();
        }

        private void LateUpdate()
        {
            if (hasMainAimPoint)
            {
                ApplyMainAim(mainAimPoint, Time.deltaTime, false);
            }
            if (hasMissileAimPoint)
            {
                ApplyMissileAim(missileAimPoint, Time.deltaTime, false);
            }
        }

        public void SetAimPoint(Vector3 worldPoint)
        {
            SetMainAimPoint(worldPoint);
            SetMissileAimPoint(worldPoint);
        }

        public void ClearAimPoint()
        {
            ClearMainAimPoint();
            ClearMissileAimPoint();
        }

        public void SetMainAimPoint(Vector3 worldPoint)
        {
            mainAimPoint = worldPoint;
            hasMainAimPoint = true;
        }

        public void ClearMainAimPoint()
        {
            hasMainAimPoint = false;
        }

        public void SetMissileAimPoint(Vector3 worldPoint)
        {
            missileAimPoint = worldPoint;
            hasMissileAimPoint = true;
        }

        public void ClearMissileAimPoint()
        {
            hasMissileAimPoint = false;
        }

        public void SnapAimAt(Vector3 worldPoint)
        {
            if (!ResolveTransforms())
            {
                return;
            }
            ApplyMainAim(worldPoint, 0f, true);
            ApplyMissileAim(worldPoint, 0f, true);
        }

        private void ApplyMainAim(Vector3 worldPoint, float deltaTime, bool snap)
        {
            Vector3 yawLocalDirection = turretYaw.parent.InverseTransformDirection(worldPoint - turretYaw.position);
            yawLocalDirection.y = 0f;
            if (yawLocalDirection.sqrMagnitude > 0.0001f)
            {
                float targetYaw = Mathf.Atan2(yawLocalDirection.x, yawLocalDirection.z) * Mathf.Rad2Deg;
                float currentYaw = NormalizeAngle(turretYaw.localEulerAngles.y);
                float nextYaw = snap ? targetYaw : Mathf.MoveTowardsAngle(currentYaw, targetYaw, turretSpeedDegrees * deltaTime);
                turretYaw.localRotation = Quaternion.Euler(0f, nextYaw, 0f);
            }

            Vector3 pitchLocalDirection = turretYaw.InverseTransformDirection(worldPoint - cannonPitch.position);
            float elevation = Mathf.Atan2(pitchLocalDirection.y, Mathf.Max(0.0001f, pitchLocalDirection.z)) * Mathf.Rad2Deg;
            elevation = Mathf.Clamp(elevation, minimumCannonElevation, maximumCannonElevation);
            float targetPitch = -elevation;
            float currentPitch = NormalizeAngle(cannonPitch.localEulerAngles.x);
            float nextPitch = snap ? targetPitch : Mathf.MoveTowardsAngle(currentPitch, targetPitch, cannonSpeedDegrees * deltaTime);
            cannonPitch.localRotation = Quaternion.Euler(nextPitch, 0f, 0f);
        }

        private void ApplyMissileAim(Vector3 worldPoint, float deltaTime, bool snap)
        {
            Vector3 yawLocalDirection = missileYaw.parent.InverseTransformDirection(worldPoint - missileYaw.position);
            yawLocalDirection.y = 0f;
            if (yawLocalDirection.sqrMagnitude > 0.0001f)
            {
                float targetYaw = Mathf.Atan2(yawLocalDirection.x, yawLocalDirection.z) * Mathf.Rad2Deg;
                float currentYaw = NormalizeAngle(missileYaw.localEulerAngles.y);
                float nextYaw = snap ? targetYaw : Mathf.MoveTowardsAngle(currentYaw, targetYaw, missileYawSpeedDegrees * deltaTime);
                missileYaw.localRotation = Quaternion.Euler(0f, nextYaw, 0f);
            }

            Vector3 pitchLocalDirection = missileYaw.InverseTransformDirection(worldPoint - missilePitch.position);
            float elevation = Mathf.Atan2(pitchLocalDirection.y, Mathf.Max(0.0001f, pitchLocalDirection.z)) * Mathf.Rad2Deg;
            elevation = Mathf.Clamp(elevation, minimumMissileElevation, maximumMissileElevation);
            float targetPitch = -elevation;
            float currentPitch = NormalizeAngle(missilePitch.localEulerAngles.x);
            float nextPitch = snap ? targetPitch : Mathf.MoveTowardsAngle(currentPitch, targetPitch, missilePitchSpeedDegrees * deltaTime);
            missilePitch.localRotation = Quaternion.Euler(nextPitch, 0f, 0f);
        }

        private bool ResolveTransforms()
        {
            if (turretYaw == null)
            {
                turretYaw = transform.Find("TurretYaw");
            }
            if (cannonPitch == null && turretYaw != null)
            {
                cannonPitch = turretYaw.Find("CannonPitch");
            }
            if (leftCannonMuzzle == null && cannonPitch != null)
            {
                leftCannonMuzzle = cannonPitch.Find("LeftCannonMuzzle");
            }
            if (rightCannonMuzzle == null && cannonPitch != null)
            {
                rightCannonMuzzle = cannonPitch.Find("RightCannonMuzzle");
            }
            if (missileYaw == null && turretYaw != null)
            {
                missileYaw = turretYaw.Find("MissileYaw");
            }
            if (missilePitch == null && missileYaw != null)
            {
                missilePitch = missileYaw.Find("MissilePitch");
            }
            if ((missileMuzzles == null || missileMuzzles.Length == 0) && missilePitch != null)
            {
                missileMuzzles = new Transform[8];
                for (int i = 0; i < missileMuzzles.Length; i++)
                {
                    missileMuzzles[i] = missilePitch.Find($"MissileMuzzle_{i + 1:00}");
                }
            }
            return turretYaw != null && cannonPitch != null && missileYaw != null && missilePitch != null;
        }

        private static float NormalizeAngle(float angle)
        {
            return angle > 180f ? angle - 360f : angle;
        }
    }
}
'''
    (SCRIPT_DIR / 'BastionHT77Controller.cs').write_text(code, encoding='utf-8')


def write_importer_script() -> None:
    code = r'''using UnityEditor;
using UnityEngine;

namespace BastionHeavyTank.Editor
{
    internal sealed class BastionHT77ImportPostprocessor : AssetPostprocessor
    {
        private const string MeshPath = "Assets/BastionHeavyTank/Meshes/";
        private const string TexturePath = "Assets/BastionHeavyTank/Textures/";

        private void OnPreprocessModel()
        {
            if (!assetPath.StartsWith(MeshPath, System.StringComparison.Ordinal))
            {
                return;
            }

            ModelImporter importer = (ModelImporter)assetImporter;
            importer.globalScale = 1f;
            importer.importAnimation = false;
            importer.importBlendShapes = false;
            importer.importCameras = false;
            importer.importLights = false;
            importer.isReadable = false;
            importer.meshCompression = ModelImporterMeshCompression.Medium;
            importer.normalImportMode = ModelImporterNormals.Import;
        }

        private void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith(TexturePath, System.StringComparison.Ordinal))
            {
                return;
            }

            TextureImporter importer = (TextureImporter)assetImporter;
            importer.textureType = TextureImporterType.Default;
            importer.sRGBTexture = true;
            importer.mipmapEnabled = false;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Point;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
        }
    }
}
'''
    (EDITOR_DIR / 'BastionHT77ImportPostprocessor.cs').write_text(code, encoding='utf-8')


def write_builder_script() -> None:
    code = r'''using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace BastionHeavyTank.Editor
{
    internal static class BastionHT77PrefabBuilder
    {
        private const string Root = "Assets/BastionHeavyTank";
        private const string Meshes = Root + "/Meshes";
        private const string Textures = Root + "/Textures";
        private const string Materials = Root + "/Materials";
        private const string Prefabs = Root + "/Prefabs";
        private const string PrefabPath = Prefabs + "/Bastion_HT77_Mammoth.prefab";
        private const string MaterialPath = Materials + "/Bastion_HT77_Palette.mat";

        private static readonly string[] RequiredModels =
        {
            Meshes + "/Bastion_HT77_Hull.obj",
            Meshes + "/Bastion_HT77_LeftTrack.obj",
            Meshes + "/Bastion_HT77_RightTrack.obj",
            Meshes + "/Bastion_HT77_Turret.obj",
            Meshes + "/Bastion_HT77_TwinCannons.obj",
            Meshes + "/Bastion_HT77_MissileBase.obj",
            Meshes + "/Bastion_HT77_MissilePod.obj",
            Meshes + "/Bastion_HT77_LOD1.obj"
        };

        [InitializeOnLoadMethod]
        private static void QueueAutomaticBuild()
        {
            EditorApplication.delayCall += () =>
            {
                if (AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath) == null && AssetsReady())
                {
                    Build(false);
                }
            };
        }

        [MenuItem("Tools/Bastion HT-77 Mammoth/Create or Rebuild Prefab")]
        private static void BuildFromMenu()
        {
            Build(true);
        }

        private static bool AssetsReady()
        {
            foreach (string path in RequiredModels)
            {
                if (AssetDatabase.LoadAssetAtPath<GameObject>(path) == null)
                {
                    return false;
                }
            }
            return AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_HT77_Palette.png") != null;
        }

        private static void Build(bool selectResult)
        {
            if (!AssetsReady())
            {
                Debug.LogWarning("Bastion HT-77 Mammoth: model imports are not ready. Re-run the prefab command after Unity finishes importing.");
                return;
            }

            EnsureFolder(Materials);
            EnsureFolder(Prefabs);
            Material material = CreateOrUpdateMaterial();

            GameObject root = new GameObject("Bastion_HT77_Mammoth");
            root.transform.position = Vector3.zero;
            root.transform.rotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;

            GameObject hull = InstantiateModel("Hull", RequiredModels[0], root.transform, new Vector3(0f, 1.18f, 0f), material);
            GameObject leftTrack = InstantiateModel("LeftTrack", RequiredModels[1], root.transform, new Vector3(-1.94f, 0.84f, 0f), material);
            GameObject rightTrack = InstantiateModel("RightTrack", RequiredModels[2], root.transform, new Vector3(1.94f, 0.84f, 0f), material);

            GameObject turretYaw = NewChild("TurretYaw", root.transform, new Vector3(0f, 2.20f, -0.12f));
            GameObject turretModel = InstantiateModel("TurretModel", RequiredModels[3], turretYaw.transform, Vector3.zero, material);

            GameObject cannonPitch = NewChild("CannonPitch", turretYaw.transform, new Vector3(0f, 0.08f, 1.48f));
            GameObject cannonModel = InstantiateModel("TwinCannons", RequiredModels[4], cannonPitch.transform, Vector3.zero, material);
            Transform leftMuzzle = NewAnchor("LeftCannonMuzzle", cannonPitch.transform, new Vector3(-0.43f, 0f, 5.55f));
            Transform rightMuzzle = NewAnchor("RightCannonMuzzle", cannonPitch.transform, new Vector3(0.43f, 0f, 5.55f));

            GameObject missileYaw = NewChild("MissileYaw", turretYaw.transform, new Vector3(1.06f, 0.58f, -0.62f));
            GameObject missileBase = InstantiateModel("MissileBase", RequiredModels[5], missileYaw.transform, Vector3.zero, material);
            GameObject missilePitch = NewChild("MissilePitch", missileYaw.transform, new Vector3(0f, 0.62f, 0.05f));
            GameObject missilePod = InstantiateModel("MissilePod", RequiredModels[6], missilePitch.transform, Vector3.zero, material);

            Transform[] missileMuzzles = new Transform[8];
            float[] xs = { -0.57f, -0.19f, 0.19f, 0.57f };
            int muzzleIndex = 0;
            foreach (float y in new[] { -0.23f, 0.23f })
            {
                foreach (float x in xs)
                {
                    missileMuzzles[muzzleIndex] = NewAnchor($"MissileMuzzle_{muzzleIndex + 1:00}", missilePitch.transform, new Vector3(x, y, 0.98f));
                    muzzleIndex++;
                }
            }

            GameObject lod1 = InstantiateModel("LOD1", RequiredModels[7], root.transform, Vector3.zero, material);
            lod1.SetActive(true);

            ConfigureLODGroup(
                root,
                new[] { hull, leftTrack, rightTrack, turretModel, cannonModel, missileBase, missilePod },
                lod1);

            BoxCollider hullCollider = root.AddComponent<BoxCollider>();
            hullCollider.center = new Vector3(0f, 1.32f, 0.04f);
            hullCollider.size = new Vector3(4.75f, 2.70f, 7.25f);

            BastionHT77Controller controller = root.AddComponent<BastionHT77Controller>();
            SerializedObject serialized = new SerializedObject(controller);
            serialized.FindProperty("turretYaw").objectReferenceValue = turretYaw.transform;
            serialized.FindProperty("cannonPitch").objectReferenceValue = cannonPitch.transform;
            serialized.FindProperty("leftCannonMuzzle").objectReferenceValue = leftMuzzle;
            serialized.FindProperty("rightCannonMuzzle").objectReferenceValue = rightMuzzle;
            serialized.FindProperty("missileYaw").objectReferenceValue = missileYaw.transform;
            serialized.FindProperty("missilePitch").objectReferenceValue = missilePitch.transform;
            SerializedProperty muzzleArray = serialized.FindProperty("missileMuzzles");
            muzzleArray.arraySize = missileMuzzles.Length;
            for (int i = 0; i < missileMuzzles.Length; i++)
            {
                muzzleArray.GetArrayElementAtIndex(i).objectReferenceValue = missileMuzzles[i];
            }
            serialized.ApplyModifiedPropertiesWithoutUndo();

            PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
            UnityEngine.Object.DestroyImmediate(root);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            if (selectResult && prefab != null)
            {
                Selection.activeObject = prefab;
                EditorGUIUtility.PingObject(prefab);
            }

            Debug.Log("Bastion HT-77 Mammoth: created " + PrefabPath);
        }

        private static GameObject NewChild(string name, Transform parent, Vector3 localPosition)
        {
            GameObject child = new GameObject(name);
            child.transform.SetParent(parent, false);
            child.transform.localPosition = localPosition;
            child.transform.localRotation = Quaternion.identity;
            child.transform.localScale = Vector3.one;
            return child;
        }

        private static Transform NewAnchor(string name, Transform parent, Vector3 localPosition)
        {
            return NewChild(name, parent, localPosition).transform;
        }

        private static GameObject InstantiateModel(string name, string path, Transform parent, Vector3 localPosition, Material material)
        {
            GameObject source = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(source);
            instance.name = name;
            instance.transform.SetParent(parent, false);
            instance.transform.localPosition = localPosition;
            instance.transform.localRotation = Quaternion.identity;
            instance.transform.localScale = Vector3.one;

            foreach (Renderer renderer in instance.GetComponentsInChildren<Renderer>(true))
            {
                int materialCount = Mathf.Max(1, renderer.sharedMaterials.Length);
                Material[] shared = new Material[materialCount];
                for (int i = 0; i < shared.Length; i++)
                {
                    shared[i] = material;
                }
                renderer.sharedMaterials = shared;
                renderer.shadowCastingMode = ShadowCastingMode.On;
                renderer.receiveShadows = true;
                renderer.lightProbeUsage = LightProbeUsage.BlendProbes;
            }
            return instance;
        }

        private static void ConfigureLODGroup(GameObject root, IEnumerable<GameObject> lod0Roots, GameObject lod1Root)
        {
            List<Renderer> lod0Renderers = new List<Renderer>();
            foreach (GameObject item in lod0Roots)
            {
                lod0Renderers.AddRange(item.GetComponentsInChildren<Renderer>(true));
            }

            Renderer[] lod1Renderers = lod1Root.GetComponentsInChildren<Renderer>(true);
            LODGroup group = root.AddComponent<LODGroup>();
            group.fadeMode = LODFadeMode.CrossFade;
            group.animateCrossFading = false;
            LOD high = new LOD(0.18f, lod0Renderers.ToArray());
            high.fadeTransitionWidth = 0.08f;
            LOD low = new LOD(0.045f, lod1Renderers);
            low.fadeTransitionWidth = 0.10f;
            LOD culled = new LOD(0.007f, Array.Empty<Renderer>());
            group.SetLODs(new[] { high, low, culled });
            group.RecalculateBounds();
        }

        private static Material CreateOrUpdateMaterial()
        {
            Material material = AssetDatabase.LoadAssetAtPath<Material>(MaterialPath);
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null)
            {
                shader = Shader.Find("Standard");
            }
            if (shader == null)
            {
                throw new InvalidOperationException("Bastion HT-77 Mammoth: neither URP/Lit nor Standard shader could be found.");
            }

            if (material == null)
            {
                material = new Material(shader) { name = "Bastion_HT77_Palette" };
                AssetDatabase.CreateAsset(material, MaterialPath);
            }
            else if (material.shader != shader)
            {
                material.shader = shader;
            }

            Texture2D palette = AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_HT77_Palette.png");
            Texture2D emission = AssetDatabase.LoadAssetAtPath<Texture2D>(Textures + "/Bastion_HT77_Emission.png");

            SetTextureIfPresent(material, "_BaseMap", palette);
            SetTextureIfPresent(material, "_MainTex", palette);
            SetColorIfPresent(material, "_BaseColor", Color.white);
            SetColorIfPresent(material, "_Color", Color.white);
            SetFloatIfPresent(material, "_Metallic", 0.18f);
            SetFloatIfPresent(material, "_Smoothness", 0.29f);
            SetFloatIfPresent(material, "_Glossiness", 0.29f);

            if (emission != null)
            {
                SetTextureIfPresent(material, "_EmissionMap", emission);
                SetColorIfPresent(material, "_EmissionColor", Color.white * 1.15f);
                material.EnableKeyword("_EMISSION");
            }

            material.enableInstancing = true;
            EditorUtility.SetDirty(material);
            return material;
        }

        private static void SetTextureIfPresent(Material material, string property, Texture texture)
        {
            if (material.HasProperty(property)) material.SetTexture(property, texture);
        }

        private static void SetColorIfPresent(Material material, string property, Color value)
        {
            if (material.HasProperty(property)) material.SetColor(property, value);
        }

        private static void SetFloatIfPresent(Material material, string property, float value)
        {
            if (material.HasProperty(property)) material.SetFloat(property, value);
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path)?.Replace('\\', '/');
            string name = Path.GetFileName(path);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent))
            {
                EnsureFolder(parent);
            }
            AssetDatabase.CreateFolder(parent, name);
        }
    }
}
'''
    (EDITOR_DIR / 'BastionHT77PrefabBuilder.cs').write_text(code, encoding='utf-8')


def write_readme(stats: dict) -> None:
    readme = f'''# {ASSET_NAME} — Unity / Meta Quest heavy tank asset

This package contains an original low-poly RTS super-heavy tank with twin main cannons and an articulated eight-tube missile attachment. It follows the same Bastion asset conventions as the earlier light and medium tanks: OBJ source meshes imported directly by Unity, a generated prefab, one shared palette material, a static distant LOD, simple collision, and runtime articulation scripts.

The design uses broad classic base-building RTS conventions. It is not an exact copy of a specific Command & Conquer vehicle and contains no copied meshes, textures, logos, or faction marks.

## Import

1. Copy the included `Assets/BastionHeavyTank` folder into the root of your Unity project.
2. Let Unity finish importing and compiling.
3. The editor script creates `Assets/BastionHeavyTank/Prefabs/Bastion_HT77_Mammoth.prefab` automatically.
4. If needed, run **Tools > Bastion HT-77 Mammoth > Create or Rebuild Prefab**.
5. Drag the prefab into your scene.

The optional GLB files in `Extras` require a glTF importer. Unity uses the included OBJ files directly.

## Prefab hierarchy

```text
Bastion_HT77_Mammoth
├── Hull
├── LeftTrack
├── RightTrack
├── TurretYaw
│   ├── TurretModel
│   ├── CannonPitch
│   │   ├── TwinCannons
│   │   ├── LeftCannonMuzzle
│   │   └── RightCannonMuzzle
│   └── MissileYaw
│       ├── MissileBase
│       └── MissilePitch
│           ├── MissilePod
│           └── MissileMuzzle_01 ... MissileMuzzle_08
└── LOD1
```

## Runtime aiming API

```csharp
BastionHT77Controller tank = GetComponent<BastionHT77Controller>();

// Aim both weapon systems at the same target.
tank.SetAimPoint(target.position);

// Or assign separate targets.
tank.SetMainAimPoint(armorTarget.position);
tank.SetMissileAimPoint(airOrVehicleTarget.position);

// Spawn projectiles from the exposed muzzle transforms.
Transform leftGun = tank.LeftCannonMuzzle;
Transform rightGun = tank.RightCannonMuzzle;
Transform firstMissile = tank.MissileMuzzles[0];
```

The component handles only articulation. Projectile spawning, salvos, recoil, muzzle flashes, damage, sound, locomotion, networking, and target selection remain project-specific.

## Coordinate and scale conventions

- 1 Unity unit = 1 meter
- +Y = up
- +Z = forward / weapon direction
- Root origin = ground center
- Twin cannons share one elevation pivot
- Missile attachment has independent yaw and pitch pivots

## Technical profile

- LOD0 triangles: {stats['lod0_triangles']:,}
- LOD1 triangles: {stats['lod1_triangles']:,}
- Articulated LOD0 renderer roots: {stats['articulated_renderers']}
- Shared materials: 1
- Palette textures: 2 × {stats['texture_width']}×{stats['texture_height']} RGBA PNG
- Approximate neutral-pose bounds: {stats['bounds_m'][0]:.2f} m wide × {stats['bounds_m'][1]:.2f} m high × {stats['bounds_m'][2]:.2f} m long
- Main collision: one BoxCollider
- LOD culling included
- GPU instancing enabled on the generated material

## Quest-oriented notes

The asset uses flat-shaded low-poly geometry, one compact palette material, no transparency, no normal map, a simplified LOD1, and an inexpensive collider. Profile the final scene and simultaneous vehicle count on the target Quest headset.
'''
    (ASSET_ROOT / 'README.md').write_text(readme, encoding='utf-8')

    (OUTPUT_ROOT / 'README_FIRST.txt').write_text(
        f'''{ASSET_NAME} Unity Asset\n\nQUICK START\n1. Copy the Assets folder into the root of your Unity project.\n2. Unity creates Assets/BastionHeavyTank/Prefabs/Bastion_HT77_Mammoth.prefab.\n3. See Assets/BastionHeavyTank/README.md for hierarchy and aiming API.\n''',
        encoding='utf-8',
    )


def write_notice() -> None:
    (ASSET_ROOT / 'ASSET_NOTICE.txt').write_text(
        f'''{ASSET_NAME} asset notice\n\nThis package contains original generated geometry, textures, and source code. No third-party game meshes, logos, faction marks, or copied textures are included. The vehicle uses general heavy-tank and classic RTS visual conventions rather than reproducing a specific copyrighted unit.\n\nNo warranty is provided. Test shader compatibility, projectile alignment, collision behavior, performance, and platform compliance in your own Unity project before shipping.\n''',
        encoding='utf-8',
    )


def zip_folder(source: Path, destination: Path) -> None:
    if destination.exists():
        destination.unlink()
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(source))


def validate_objs(paths: Sequence[Path]) -> dict[str, dict[str, int]]:
    report: dict[str, dict[str, int]] = {}
    for path in paths:
        loaded = trimesh.load(path, force='mesh', process=False)
        if not isinstance(loaded, trimesh.Trimesh):
            raise RuntimeError(f'{path.name} did not load as a mesh')
        if len(loaded.faces) == 0 or len(loaded.vertices) == 0:
            raise RuntimeError(f'{path.name} is empty')
        if not np.isfinite(loaded.vertices).all():
            raise RuntimeError(f'{path.name} contains non-finite vertices')
        report[path.name] = {'vertices': int(len(loaded.vertices)), 'triangles': int(len(loaded.faces))}
    return report


def main() -> None:
    if OUTPUT_ROOT.exists():
        shutil.rmtree(OUTPUT_ROOT)
    for directory in (MESH_DIR, TEXTURE_DIR, SCRIPT_DIR, EDITOR_DIR, EXTRAS_DIR, SOURCE_DIR, SPEC_DIR):
        directory.mkdir(parents=True, exist_ok=True)

    base_image = write_textures()
    write_mtl()

    parts = {
        'Hull': build_hull(),
        'LeftTrack': build_track(-1),
        'RightTrack': build_track(1),
        'Turret': build_turret(),
        'TwinCannons': build_twin_cannons(),
        'MissileBase': build_missile_base(),
        'MissilePod': build_missile_pod(),
    }

    obj_map = {
        'Hull': ('Bastion_HT77_Hull.obj', 'Bastion_HT77_Hull'),
        'LeftTrack': ('Bastion_HT77_LeftTrack.obj', 'Bastion_HT77_LeftTrack'),
        'RightTrack': ('Bastion_HT77_RightTrack.obj', 'Bastion_HT77_RightTrack'),
        'Turret': ('Bastion_HT77_Turret.obj', 'Bastion_HT77_Turret'),
        'TwinCannons': ('Bastion_HT77_TwinCannons.obj', 'Bastion_HT77_TwinCannons'),
        'MissileBase': ('Bastion_HT77_MissileBase.obj', 'Bastion_HT77_MissileBase'),
        'MissilePod': ('Bastion_HT77_MissilePod.obj', 'Bastion_HT77_MissilePod'),
    }
    for key, (filename, object_name) in obj_map.items():
        common.write_obj(MESH_DIR / filename, object_name, parts[key], mtl_reference=MTL_NAME)

    static_pieces = combine_all(parts)
    common.write_obj(MESH_DIR / 'Bastion_HT77_Static.obj', 'Bastion_HT77_Static', static_pieces, mtl_reference=MTL_NAME)

    lod_local = build_lod1_local()
    lod_static = combine_all(lod_local)
    common.write_obj(MESH_DIR / 'Bastion_HT77_LOD1.obj', 'Bastion_HT77_LOD1', lod_static, mtl_reference=MTL_NAME)

    common.export_glb(
        EXTRAS_DIR / 'Bastion_HT77_Articulated.glb',
        [
            ('Hull', parts['Hull'], PIVOTS['Hull'], None),
            ('LeftTrack', parts['LeftTrack'], PIVOTS['LeftTrack'], None),
            ('RightTrack', parts['RightTrack'], PIVOTS['RightTrack'], None),
            ('TurretYaw', parts['Turret'], PIVOTS['TurretYaw'], None),
            ('CannonPitch', parts['TwinCannons'], PIVOTS['CannonPitch_local'], 'TurretYaw'),
            ('MissileYaw', parts['MissileBase'], PIVOTS['MissileYaw_local'], 'TurretYaw'),
            ('MissilePitch', parts['MissilePod'], PIVOTS['MissilePitch_local'], 'MissileYaw'),
        ],
        base_image,
    )
    static_glb = common.flatten_for_glb(static_pieces, base_image)
    (EXTRAS_DIR / 'Bastion_HT77_Static.glb').write_bytes(static_glb.export(file_type='glb'))

    write_controller_script()
    write_importer_script()
    write_builder_script()
    write_notice()

    lod0_triangles = sum(len(piece.mesh.faces) for group in parts.values() for piece in group)
    lod1_triangles = sum(len(piece.mesh.faces) for piece in lod_static)
    all_vertices = np.vstack([piece.mesh.vertices for piece in static_pieces])
    mins = all_vertices.min(axis=0)
    maxs = all_vertices.max(axis=0)
    bounds = maxs - mins

    obj_paths = [MESH_DIR / filename for filename, _ in obj_map.values()]
    obj_paths.extend([MESH_DIR / 'Bastion_HT77_Static.obj', MESH_DIR / 'Bastion_HT77_LOD1.obj'])
    validation = validate_objs(obj_paths)

    stats = {
        'asset_name': ASSET_NAME,
        'coordinate_system': 'Y-up, Z-forward, meters',
        'lod0_triangles': int(lod0_triangles),
        'lod1_triangles': int(lod1_triangles),
        'articulated_renderers': 7,
        'materials': 1,
        'texture_width': SWATCH_WIDTH * len(PALETTE_ORDER),
        'texture_height': TEXTURE_HEIGHT,
        'bounds_m': [float(bounds[0]), float(bounds[1]), float(bounds[2])],
        'bounds_min': [float(v) for v in mins],
        'bounds_max': [float(v) for v in maxs],
        'pivot_positions': {key: [float(v) for v in value] for key, value in PIVOTS.items()},
        'main_muzzles_local_to_cannon_pitch': {
            'LeftCannonMuzzle': [-0.43, 0.0, 5.55],
            'RightCannonMuzzle': [0.43, 0.0, 5.55],
        },
        'missile_muzzles_local_to_missile_pitch': [
            [float(x), float(y), 0.98] for y in (-0.23, 0.23) for x in (-0.57, -0.19, 0.19, 0.57)
        ],
        'validation': validation,
    }
    write_readme(stats)
    (SPEC_DIR / 'Bastion_HT77_Spec.json').write_text(json.dumps(stats, indent=2), encoding='utf-8')

    shutil.copy2(Path(__file__), SOURCE_DIR / 'generate_bastion_ht77.py')
    shutil.copy2(Path('/mnt/data/generate_bastion_mt12.py'), SOURCE_DIR / 'bastion_mesh_common.py')

    full_zip = Path('/mnt/data/Bastion_HT77_Mammoth_Unity_Asset.zip')
    zip_folder(OUTPUT_ROOT, full_zip)

    quick = Path('/mnt/data/Bastion_HT77_Mammoth_QuickImport')
    if quick.exists():
        shutil.rmtree(quick)
    (quick / 'Meshes').mkdir(parents=True)
    (quick / 'Textures').mkdir(parents=True)
    for filename in ('Bastion_HT77_Static.obj', MTL_NAME):
        shutil.copy2(MESH_DIR / filename, quick / 'Meshes' / filename)
    for filename in ('Bastion_HT77_Palette.png', 'Bastion_HT77_Emission.png'):
        shutil.copy2(TEXTURE_DIR / filename, quick / 'Textures' / filename)
    (quick / 'README.txt').write_text(
        'Drag the Meshes and Textures folders into Unity together. Use Bastion_HT77_Static.obj for a neutral-pose, non-articulated one-piece model. The full package contains the articulated twin cannons, missile attachment, muzzle anchors, runtime controller, LOD, and automatic prefab builder.\n',
        encoding='utf-8',
    )
    quick_zip = Path('/mnt/data/Bastion_HT77_Mammoth_QuickImport.zip')
    zip_folder(quick, quick_zip)

    for zip_path in (full_zip, quick_zip):
        with zipfile.ZipFile(zip_path, 'r') as archive:
            corrupt = archive.testzip()
            if corrupt is not None:
                raise RuntimeError(f'Corrupt ZIP entry in {zip_path.name}: {corrupt}')

    print(json.dumps(stats, indent=2))


if __name__ == '__main__':
    main()
