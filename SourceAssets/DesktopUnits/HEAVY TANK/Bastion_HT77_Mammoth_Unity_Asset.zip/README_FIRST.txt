Bastion HT-77 Mammoth Unity Asset

QUICK START
1. Copy the Assets folder into the root of your Unity project.
2. Unity creates Assets/BastionHeavyTank/Prefabs/Bastion_HT77_Mammoth.prefab.
3. See Assets/BastionHeavyTank/README.md for hierarchy and aiming API.
