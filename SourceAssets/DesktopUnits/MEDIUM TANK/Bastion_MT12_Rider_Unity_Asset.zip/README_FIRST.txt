Bastion MT-12 Rider Unity Asset

QUICK START
1. Copy the Assets folder into the root of your Unity project.
2. Unity creates Assets/BastionMediumTank/Prefabs/Bastion_MT12_Rider.prefab.
3. See Assets/BastionMediumTank/README.md for the gunner mount API and hierarchy.
